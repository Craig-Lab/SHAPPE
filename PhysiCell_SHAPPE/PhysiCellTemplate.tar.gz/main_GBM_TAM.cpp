/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2022, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <cmath>
#include <math.h>
#include <omp.h>
#include <fstream>
#include <algorithm>
#include <vector>

#include "./core/PhysiCell.h"
#include "./modules/PhysiCell_standard_modules.h" 

// put custom code modules here! 

#include "./custom_modules/common.h"

#include "./custom_modules/custom_GBM_TAM.h" 
#include "./custom_modules/localRegions.h"
#include "./custom_modules/RepulsiveRegion.h"
	
using namespace BioFVM;
using namespace PhysiCell;

int numCellsCreated;
std::vector<int> cellcounts = {0,0,0,0,0,0};
std::vector<int> deadcells = {0,0,0,0,0,0,0};
std::vector<int> pers_time_stop_all = {0,0,0,0,0,0,0,0,0};
std::vector<int> pers_time_go_all = {0,0,0,0,0,0,0,0,0};
std::vector<double> attached_cells = {0.0,0.0,0.0,0.0};
double current_tumour_radius;
bool plot_voxels = false;
double void_average_CC;
double void_prob;
std::vector<std::vector<double>> cancer_targetDistances_distributions;
std::vector<std::vector<double>> M0_targetDistances_distributions;
std::vector<std::vector<double>> M1_targetDistances_distributions;
std::vector<std::vector<double>> M2_targetDistances_distributions;
std::vector<std::vector<double>> CD8_targetDistances_distributions;
double tumour_baseline_proliferation_rate;
double cd8_death_rate;
double local_regions_radius

// Declare a vector of local regions
std::vector<localRegions> TMELocalRegions;

// Declare a vector for repulsive regions
std::vector<RepulsiveRegion> TMERepulsiveRegions;

int main( int argc, char* argv[] )
{
	
	numCellsCreated = 0;
	local_regions_radius = 100;

	// load and parse settings file(s)
	
	bool XML_status = false; 
	char copy_command [1024]; 
	if( argc > 1 )
	{
		XML_status = load_PhysiCell_config_file( argv[1] ); 
		sprintf( copy_command , "cp %s %s" , argv[1] , PhysiCell_settings.folder.c_str() ); 
	}
	else
	{
		XML_status = load_PhysiCell_config_file( "./config/PhysiCell_settings.xml" );
		sprintf( copy_command , "cp ./config/PhysiCell_settings.xml %s" , PhysiCell_settings.folder.c_str() ); 
	}
	if( !XML_status )
	{ exit(-1); }
	
	// copy config file to output directry 
	system( copy_command ); 
	
	// OpenMP setup
	omp_set_num_threads(PhysiCell_settings.omp_num_threads);
	
	// time setup 
	std::string time_units = "min"; 

	/* Microenvironment setup */ 
	
	setup_microenvironment(); // modify this in the custom code 

	int number_of_TMZ_updates = 1;

	double last_time_updated = 0; // keep tabs of the last time the radius was increased
	double number_of_times_updated = 1; // the number of times the radius has been increased
	double beta = parameters.doubles("beta");
	double kV = parameters.doubles("kV");
	double tumour_radius_initial = parameters.doubles("tumour_radius_initial");
	current_tumour_radius = tumour_radius_initial;
	double time_to_radius_increase = newTimeToRadiusIncrease(current_tumour_radius,last_time_updated);//newTimeToRadiusIncrease(tumour_radius_initial,beta,kV);
	void_prob = parameters.doubles("void_probability");
	void_average_CC = parameters.doubles("void_carrying_capacity");
	tumour_baseline_proliferation_rate = parameters.doubles("GBM_cell_proliferation_rate");
	cd8_death_rate = parameters.doubles("CD8_death_rate");
	/* PhysiCell setup */ 
 	
	// set mechanics voxel size, and match the data structure to BioFVM
	double mechanics_voxel_size = 4.0 * parameters.doubles("GBM_radius");
	Cell_Container* cell_container = create_cell_container_for_microenvironment( microenvironment, mechanics_voxel_size );
	

	initialiseLocalRegions();

	create_cell_types();
	if(parameters.bools("Oriented_Movement")) {
		loadTargetDistancesDistributions();
	}
	setup_tissue();

	/* Users typically stop modifying here. END USERMODS */ 
	
	// set MultiCellDS save options 

	set_save_biofvm_mesh_as_matlab( true ); 
	set_save_biofvm_data_as_matlab( true ); 
	set_save_biofvm_cell_data( true ); 
	set_save_biofvm_cell_data_as_custom_matlab( true );

	// save a simulation snapshot 
	
	char filename[1024];
	sprintf( filename , "%s/initial" , PhysiCell_settings.folder.c_str() ); 
	save_PhysiCell_to_MultiCellDS_v2( filename , microenvironment , PhysiCell_globals.current_time ); 
	//save_general_info(cellcounts, deadcells);
	
	// save a quick SVG cross section through z = 0, after setting its 
	// length bar to 200 microns 

	PhysiCell_SVG_options.length_bar = 200; 

	// for simplicity, set a pathology coloring function 
	
	std::vector<std::string> (*cell_coloring_function)(Cell*) = my_coloring_function;
	std::string (*substrate_coloring_function)(double, double, double) = paint_by_density_percentage;

	sprintf( filename , "%s/initial.svg" , PhysiCell_settings.folder.c_str() ); 
	SVG_plot( filename , microenvironment, 0.0 , PhysiCell_globals.current_time, cell_coloring_function, substrate_coloring_function);
	
	sprintf( filename , "%s/legend.svg" , PhysiCell_settings.folder.c_str() ); 
	create_plot_legend( filename , cell_coloring_function ); 
	
	display_citations(); 
	
	// set the performance timers 

	BioFVM::RUNTIME_TIC();
	BioFVM::TIC();
	
	std::ofstream report_file;
	if( PhysiCell_settings.enable_legacy_saves == true )
	{	
		sprintf( filename , "%s/simulation_report.txt" , PhysiCell_settings.folder.c_str() ); 
		
		report_file.open(filename); 	// create the data log file 
		report_file<<"simulated time\tnum cells\tnum division\tnum death\twall time"<<std::endl;
	}
	

	// Load void regions
	double randomInitialisation = parameters.doubles("random_initialisation");
	if(randomInitialisation<1) {

		std::string url_void = parameters.strings("url_voids");
		loadRepulsiveRegions();
	}
	// main loop 
	
	try 
	{		
		while( PhysiCell_globals.current_time < PhysiCell_settings.max_time + 0.1*diffusion_dt )
		{
			// save data if it's time. 
			if( fabs( PhysiCell_globals.current_time - PhysiCell_globals.next_full_save_time ) < 0.01 * diffusion_dt )
			{
				//display_simulation_status( std::cout ); 
				if( PhysiCell_settings.enable_legacy_saves == true )
				{	
					log_output( PhysiCell_globals.current_time , PhysiCell_globals.full_output_index, microenvironment, report_file);
				}
				
				if( PhysiCell_settings.enable_full_saves == true )
				{	
					sprintf( filename , "%s/output%08u" , PhysiCell_settings.folder.c_str(),  PhysiCell_globals.full_output_index ); 
					
					//save_PhysiCell_to_MultiCellDS_v2( filename , microenvironment , PhysiCell_globals.current_time ); 
					save_cell_info(filename);
					save_general_info(cellcounts, deadcells);
				}
				
				PhysiCell_globals.full_output_index++; 
				PhysiCell_globals.next_full_save_time += PhysiCell_settings.full_save_interval;
			}
			
			// save SVG plot if it's time
			if( fabs( PhysiCell_globals.current_time - PhysiCell_globals.next_SVG_save_time  ) < 0.01 * diffusion_dt )
			{
				if( PhysiCell_settings.enable_SVG_saves == true )
				{	
					sprintf( filename , "%s/snapshot%08u.svg" , PhysiCell_settings.folder.c_str() , PhysiCell_globals.SVG_output_index );
					SVG_plot( filename , microenvironment, 0.0 , PhysiCell_globals.current_time, cell_coloring_function, substrate_coloring_function);

					PhysiCell_globals.SVG_output_index++; 
					PhysiCell_globals.next_SVG_save_time  += PhysiCell_settings.SVG_save_interval;
				}
			}

			// update the microenvironment
			microenvironment.simulate_diffusion_decay( diffusion_dt );

			static int tmz_index = microenvironment.find_density_index( "TMZ");
			static int oxygen_index = microenvironment.find_density_index( "oxygen");
			static int wall_index = microenvironment.find_density_index( "wall");
			
	
			if( PhysiCell_globals.current_time > last_time_updated + time_to_radius_increase )
			{
				
				//std::cout<<tumour_radius_initial+10*number_of_times_updated<<" "<<number_of_times_updated<<" "<<tumour_radius_initial<<std::endl;
				for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
				{	
					std::vector<double> ECMdense = microenvironment.mesh.voxels[n].center; 
					if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]<(tumour_radius_initial+10*number_of_times_updated)*(tumour_radius_initial+10*number_of_times_updated) 
						&& ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(tumour_radius_initial+10*(number_of_times_updated-1))*(tumour_radius_initial+10*(number_of_times_updated-1)) )	
					{	
						microenvironment(n)[wall_index] = 3.5;
					}
					
					
				}
				last_time_updated = PhysiCell_globals.current_time;
				current_tumour_radius = current_tumour_radius+10;
				time_to_radius_increase = newTimeToRadiusIncrease(current_tumour_radius,last_time_updated);//newTimeToRadiusIncrease(current_tumour_radius,beta,kV);
				number_of_times_updated += 1;

				//Recruit stroma cells
				stroma_recruitment(current_tumour_radius-10,current_tumour_radius);

			}
			
			static int TMZ_index = microenvironment.find_density_index( "TMZ");
			int PKPD_time_grid = 10;
	
			if( PhysiCell_globals.current_time > PKPD_time_grid*number_of_TMZ_updates && PhysiCell_globals.current_time<=7200)
			{
				double density_in_voxels = CSF_conc_to_density( number_of_TMZ_updates );
				for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
				{
					
					std::vector<double> loc_vector = microenvironment.mesh.voxels[n].center; 
					if(loc_vector[0]*loc_vector[0]+loc_vector[1]*loc_vector[1]>(current_tumour_radius-10)*(current_tumour_radius-10))	
					{	
						microenvironment(n)[TMZ_index] = density_in_voxels;//microenvironment(n)[TMZ_index]+density_in_voxels;
					}

					// microenvironment(n)[TMZ_index] = density_in_voxels;

					//std::vector<double> loc_vector = microenvironment.mesh.voxels[n].center; 
					//if( loc_vector[0]*loc_vector[0]+loc_vector[1]*loc_vector[1]>(current_tumour_radius-10)*(current_tumour_radius-10))	
					//{	
					//	microenvironment(n)[TMZ_index] = density_in_voxels;
					//}
				}
				number_of_TMZ_updates +=1;
			}
			
			// run PhysiCell 
			((Cell_Container *)microenvironment.agent_container)->update_all_cells( PhysiCell_globals.current_time );
			
			/*
			  Custom add-ons could potentially go here. 
			*/
			
			PhysiCell_globals.current_time += diffusion_dt;
		}
		
		if( PhysiCell_settings.enable_legacy_saves == true )
		{			
			log_output(PhysiCell_globals.current_time, PhysiCell_globals.full_output_index, microenvironment, report_file);
			report_file.close();
		}
	}
	catch( const std::exception& e )
	{ // reference to the base of a polymorphic object
		//std::cout << "Exception has occured." <<std::endl; // information from length_error printed
		std::cout << e.what(); // information from length_error printed
	}
	
	// save a final simulation snapshot 
	
	sprintf( filename , "%s/final" , PhysiCell_settings.folder.c_str() ); 
	save_PhysiCell_to_MultiCellDS_v2( filename , microenvironment , PhysiCell_globals.current_time ); 
	//save_general_info(cellcounts, deadcells);
	
	sprintf( filename , "%s/final.svg" , PhysiCell_settings.folder.c_str() );
	SVG_plot(filename, microenvironment, 0.0, PhysiCell_globals.current_time, cell_coloring_function, substrate_coloring_function);

	// timer 
	
	std::cout << std::endl << "Total simulation runtime: " << std::endl; 
	BioFVM::display_stopwatch_value( std::cout , BioFVM::runtime_stopwatch_value() ); 

	return 0; 
}

double CSF_vals(int indexing_CSF_Vec)
{
	
	std::streampos size;
	char * memblock;
	//std::ifstream file ("CSF_TMZ.bin", std::ios::in|std::ios::binary|std::ios::ate); //.dat
	std::ifstream file ("TMZ.bin", std::ios::in|std::ios::binary|std::ios::ate); //.dat
	size = file.tellg();
	
	memblock = new char [size];
	file.seekg (0, std::ios::beg);
	file.read (memblock, size);
	file.close();

	double* double_values = (double*)memblock;//reinterpret as doubles
	
	return double_values[indexing_CSF_Vec];	
}

double CSF_conc_to_density(double time)
{	
	//we don't give the TMZ treatment
	if( !parameters.bools("TMZ_tx")) {
		return 0;
	} else {
		int indexing_CSF_Vec = time-1;
		double CSF_value = CSF_vals(indexing_CSF_Vec);
		double density_in_voxels = CSF_value;//*1e3/1e3; // converting miligram to microgram and mililiter to microliter
			
		return density_in_voxels;
	}
}

double newTimeToRadiusIncrease(double R, double b, double k) {
	// double tempNumerator = log((1/k)*((4/3)*M_PI*pow(R,3)));
	// double tempDenominator = log((1/k)*((4/3)*M_PI*pow(R+10,3)));
	// double tempTime = (1/b)*log(tempNumerator/tempDenominator);

	double tempfrac = (R+10)/R;
	double tempNumerator = (49.6*24*60)*log(pow(tempfrac,3));
	double tempDenominator = log(2);
	double tempTime = tempNumerator/tempDenominator;
	return tempTime;
}

double newTimeToRadiusIncrease(double R, double t1) {
	double A = 197.55/17.7;
	double B = 1/(A-1);
	double C = 2/(A*B);
	double medianDoublingTime = 71424.0;
	double r = (1/medianDoublingTime)*log(C/(1-(2/A)));
	double D = exp(r*t1)/(1+B*exp(r*t1));
	double t2 = (1/r)*log((D*pow((R+10)/R,3))/(1-B*D*pow((R+10)/R,3)));
	return t2-t1;
}

void initializeTAMRegionsRadius() {
	double Rtot = current_tumour_radius+10;
	double totalArea = M_PI*pow(Rtot,2);
	double regionArea = totalArea/10;
	int Nregion = 10;

	for(int nR=0;nR < Nregion;nR++) {
		double previous_r = TAMregionsRadius[nR];
		double next_r = sqrt((regionArea+(M_PI*pow(previous_r,2)))/M_PI);
		TAMregionsRadius.push_back(next_r);
	}
}

void initialiseLocalRegions() {
	if(!TMELocalRegions.empty()){
		TMELocalRegions.clear();
	}
	double Rtot = current_tumour_radius;
	double num_regions = round(current_tumour_radius/local_regions_radius);
	double Rdiff = Rtot/num_regions;
	double innerRadius = 0;
	double outerRadius = std::min(innerRadius+Rdiff,Rtot);
	double area = M_PI*pow(Rdiff,2);
	while(innerRadius<Rtot) {
		if(innerRadius==0) {
			localRegions newRegion = localRegions(innerRadius,outerRadius,0,2*M_PI);
			TMELocalRegions.push_back(newRegion);
		} else {
			// How many angles do you divide this annulus in?
			double fullAnnulusArea = M_PI*(pow(outerRadius,2)-pow(innerRadius,2));
			double nAngularRegions = round(fullAnnulusArea/area);
			double angleStep = 2*M_PI/nAngularRegions;
			double startAngle = 0;
			for(int i=0;i<nAngularRegions;i++) {
				localRegions newRegion = localRegions(innerRadius,outerRadius,startAngle,startAngle+angleStep);
				TMELocalRegions.push_back(newRegion);
				startAngle = startAngle+angleStep;
			}
		}
		innerRadius = innerRadius+Rdiff;
		outerRadius = std::min(innerRadius+Rdiff,Rtot);
	}
}

void save_general_info(std::vector<int> cellcounts , std::vector<int> deadcells) {
	
	std::ofstream myfile; // added "std::"
	char cellcounts_file[1024];
	sprintf( cellcounts_file , "%s/cellcounts.csv" , PhysiCell_settings.folder.c_str()); 
    //myfile.open("cellcounts.csv");
	myfile.open(cellcounts_file, std::ios::out | std::ios::app);
	
    for (int i = 0; i < cellcounts.size(); i++) { 
        myfile << cellcounts.at(i) << ",";
    } 
	myfile << std::endl;
    myfile.close(); 

	char deadcells_file[1024];
	sprintf( deadcells_file , "%s/deadcells.csv" , PhysiCell_settings.folder.c_str()); 
    //myfile.open("cellcounts.csv");
	myfile.open(deadcells_file, std::ios::out | std::ios::app);
    for (int i = 0; i < deadcells.size(); i++) { 
        myfile << deadcells.at(i) << ",";
    } 
	myfile << std::endl;
    myfile.close(); 

	char pers_time_go_file[1024];
	sprintf( pers_time_go_file , "%s/pers_time_go.csv" , PhysiCell_settings.folder.c_str()); 
	myfile.open(pers_time_go_file, std::ios::out | std::ios::app);
    for (int i = 0; i < pers_time_go_all.size(); i++) { 
        myfile << pers_time_go_all.at(i) << ",";
    } 
	myfile << std::endl;
    myfile.close(); 

	char pers_time_stop_file[1024];
	sprintf( pers_time_stop_file , "%s/pers_time_stop.csv" , PhysiCell_settings.folder.c_str()); 
	myfile.open(pers_time_stop_file, std::ios::out | std::ios::app);
    for (int i = 0; i < pers_time_stop_all.size(); i++) { 
        myfile << pers_time_stop_all.at(i) << ",";
    } 
	myfile << std::endl;
    myfile.close(); 

	char m2m1_tamregions_file[1024];
	sprintf( m2m1_tamregions_file , "%s/tam_regions_m2m1ratio.csv" , PhysiCell_settings.folder.c_str()); 
    //myfile.open("cellcounts.csv");
	myfile.open(m2m1_tamregions_file, std::ios::out | std::ios::app);

	for(int nr=0; nr<TMELocalRegions.size(); nr++) {
		int M1 = TMELocalRegions[nr].number_of_cells[4];
		int M2 =TMELocalRegions[nr].number_of_cells[5];
		if(M1+M2>0) {
			double ratio = (double)M2/(M1+M2);
			myfile << ratio;
		} else {
			myfile << "NaN";
		}
		if(nr!=(TMELocalRegions.size()-1)) {
			myfile << ",";
		}
	}

	myfile << std::endl;
    myfile.close(); 

}

std::vector<std::vector<double>> loadCSV(const std::string& filename)
{
    std::vector<std::vector<double>> matrix;
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("Could not open file");
    }

    std::string line;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        std::vector<double> row;

        while (std::getline(ss, value, ',')) {
            row.push_back(std::stod(value));
        }

        matrix.push_back(row);
    }

    return matrix;
}

loadRepulsiveRegions(const std::string& filename)
{
    std::vector<std::vector<double>> matrix;
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("Could not open file");
    }

    std::string line;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        std::vector<double> row;

        while (std::getline(ss, value, ',')) {
            row.push_back(std::stod(value));
        }

		RepulsiveRegion reg = RepulsiveRegion(row[0],row[1],row[2],void_prob,void_average_CC);
		TMERepulsiveRegions.push_back(reg);

    }

}

void loadTargetDistancesDistributions( void ) {
	std::string targetDistancesFolder = parameters.strings("target_distances_folder");
	cancer_targetDistances_distributions = loadCSV(targetDistancesFolder+"/cancerTargetDistributions.csv");
	M0_targetDistances_distributions = loadCSV(targetDistancesFolder+"/M0TargetDistributions.csv");
	M1_targetDistances_distributions = loadCSV(targetDistancesFolder+"/M1TargetDistributions.csv");
	M2_targetDistances_distributions = loadCSV(targetDistancesFolder+"/M2TargetDistributions.csv");
	CD8_targetDistances_distributions = loadCSV(targetDistancesFolder+"/CD8TargetDistributions.csv");
}
