#!/bin/bash

make glioblastomaTargetingTAMs
make
./GBMTAM