#!/bin/bash

make reset
make clean
make data-cleanup