% Author: Blanche Mongeon

close all
clearvars

%% colors

reds = [hex2rgb('#fdedeb');
        hex2rgb('#fac8ca');
        hex2rgb('#f7a39d');
        hex2rgb('#f47e75');
        hex2rgb('#f15a4e');
        hex2rgb('#ee3527');
        hex2rgb('#d31f11');
        hex2rgb('#b11a0e');
        hex2rgb('#8a140b');
        hex2rgb('#620e08');
        hex2rgb('#3b0905');
        hex2rgb('#140302')];

oranges = [hex2rgb('#fff4ea');
        hex2rgb('#ffdfbf');
        hex2rgb('#ffca95');
        hex2rgb('#ffb56a');
        hex2rgb('#ff9f40');
        hex2rgb('#ff8a15');
        hex2rgb('#f47a00');
        hex2rgb('#bf6000');
        hex2rgb('#954a00');
        hex2rgb('#6a3500');
        hex2rgb('#402000');
        hex2rgb('#150b00')];

light_blues = [hex2rgb('#eef9fa');
        hex2rgb('#cdeef1');
        hex2rgb('#ace2e8');
        hex2rgb('#8bd6de');
        hex2rgb('#6acbd5');
        hex2rgb('#48bfcc');
        hex2rgb('#62c8d3');
        hex2rgb('#2a8b95');
        hex2rgb('#216c74');
        hex2rgb('#174d53');
        hex2rgb('#0e2e32');
        hex2rgb('#050f11')];

blues = [hex2rgb('#eafaff');
        hex2rgb('#bff1ff');
        hex2rgb('#95e8ff');
        hex2rgb('#6adeff');
        hex2rgb('#40d5ff');
        hex2rgb('#15cbff');
        hex2rgb('#007191');
        hex2rgb('#0095bf');
        hex2rgb('#007495');
        hex2rgb('#00536a');
        hex2rgb('#003240');
        hex2rgb('#001115')];

magentas = [hex2rgb('#ffeafd');
        hex2rgb('#ffbff9');
        hex2rgb('#ff95f5');
        hex2rgb('#ff6af1');
        hex2rgb('#ff40ed');
        hex2rgb('#ff15e9');
        hex2rgb('#800074');
        hex2rgb('#bf00ad');
        hex2rgb('#950087');
        hex2rgb('#6a0060');
        hex2rgb('#40003a');
        hex2rgb('#150013')];

color_red = reds(7,:);
color_orange = oranges(7,:);
color_lightblue = light_blues(7,:);
color_blue = blues(7,:);
color_magenta = magentas(7,:);

type_CD8 = 1;
type_GBM = 2;
type_Stroma = 3;
type_TAM = 4;

type_oxygen = 1;
type_TMZ = 2;
type_wall = 3;
type_chemokine = 4;

plot_linewidth = 1.5;
axis_linewidth = 2;
axis_fontsize = 13;
legend_fontsize = 11;

%%

matlab_folder = cd("..");
main_folder = cd("outputMatlab/");
output_folder = cd(matlab_folder);
cd(main_folder)
cd('../data/CSV/')
data_folder = cd(matlab_folder);

%% Constants and options
time_start = 0;
time_end = 72000;%10080;%40320
time_interval = 60;
nOutput = floor(1+(time_end-time_start)./time_interval);
time = [0:nOutput-1].*(time_interval/60);

optionsNoTreatment.color_area = oranges(2,:);
optionsNoTreatment.color_line = color_orange;
optionsNoTreatment.alpha = 0.5;
optionsNoTreatment.line_width = plot_linewidth;
optionsNoTreatment.error = 'std';
optionsNoTreatment.time = time./24;
optionsNoTreatment.linestyle = '-';
optionsNoTreatmentHomogeneous = optionsNoTreatment;
optionsNoTreatmentHeterogeneous = optionsNoTreatment;
optionsNoTreatmentHeterogeneous.color_line = color_magenta;
optionsNoTreatmentHeterogeneous.color_area = magentas(2,:);
%optionsNoTreatmentHeterogeneous.linestyle = ':';

optionsTMZ = optionsNoTreatment;
optionsTMZ.color_area = reds(2,:);
optionsTMZ.color_line = color_red;
optionsTMZHomogeneous = optionsTMZ;
optionsTMZHeterogeneous = optionsTMZHomogeneous;
optionsTMZHeterogeneous.color_line = color_blue;
optionsTMZHeterogeneous.color_area = blues(2,:);
%optionsTMZHeterogeneous.linestyle = ':';

%% Tumour reduction comparison with data
tumour_reductionFinal = zeros(0);
tumour_reductions = zeros(0,2);
%Load all data files
cd(data_folder)
Zhang2010v1 = readmatrix('Zhang2010v1.csv');
Zhang2010v1(:,1) = Zhang2010v1(:,1)-6;
Zhang2010v1((Zhang2010v1(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Zhang2010v1(end,end);
Zhang2010v1(:,end) = Zhang2010v1(:,end)./Zhang2010v1(:,2);
tumour_reductions(end+1,:) = cat(2,Zhang2010v1(:,1),Zhang2010v1(:,end));

Zhang2010v2 = readmatrix('Zhang2010v2.csv');
Zhang2010v2(:,1) = Zhang2010v2(:,1)-6;
Zhang2010v2((Zhang2010v2(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Zhang2010v2(end,end);
Zhang2010v2(:,end) = Zhang2010v2(:,end)./Zhang2010v2(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Zhang2010v2(:,1),Zhang2010v2(:,end)));

Yamini2004 = readmatrix('Yamini2004.csv');
Yamini2004((Yamini2004(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Yamini2004(end,end);
Yamini2004(:,end) = Yamini2004(:,end)./Yamini2004(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Yamini2004(:,1),Yamini2004(:,end)));

Torres2011v1 = readmatrix('Torres2011v1.csv');
Torres2011v1(:,1) = Torres2011v1(:,1)-1;
Torres2011v1((Torres2011v1(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Torres2011v1(end,end);
Torres2011v1(:,end) = Torres2011v1(:,end)./Torres2011v1(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Torres2011v1(:,1),Torres2011v1(:,end)));

Torres2011v2 = readmatrix('Torres2011v2.csv');
Torres2011v2(:,1) = Torres2011v2(:,1)-1;
Torres2011v2((Torres2011v2(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Torres2011v2(end,end);
Torres2011v2(:,end) = Torres2011v2(:,end)./Torres2011v2(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Torres2011v2(:,1),Torres2011v2(:,end)));

%Torres2011v3 = readmatrix('Torres2011v3.csv');
%Torres2011v3(:,1) = Torres2011v3(:,1)-1;
%tumour_reductionFinal(end+1) = Torres2011v3(end,end);
%tumour_reductions = cat(1,tumour_reductions,cat(2,Torres2011v3(:,1),Torres2011v3(:,end)));

Son2006 = readmatrix('Son2006.csv');
Son2006(:,1) = Son2006(:,1)-7;
Son2006((Son2006(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Son2006(end,end);
Son2006(:,end) = Son2006(:,end)./Son2006(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Son2006(:,1),Son2006(:,end)));

Robinson2010_100 = readmatrix('Robinson2010_100.csv');
Robinson2010_100(:,1) = Robinson2010_100(:,1)-21;
Robinson2010_100((Robinson2010_100(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Robinson2010_100(end,end);
Robinson2010_100(:,end) = Robinson2010_100(:,end)./Robinson2010_100(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Robinson2010_100(:,1),Robinson2010_100(:,end)));

Robinson2010_200 = readmatrix('Robinson2010_200.csv');
Robinson2010_200(:,1) = Robinson2010_200(:,1)-21;
Robinson2010_200((Robinson2010_200(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Robinson2010_200(end,end);
Robinson2010_200(:,end) = Robinson2010_200(:,end)./Robinson2010_200(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Robinson2010_200(:,1),Robinson2010_200(:,end)));

Pedretti2010Intracranial = readmatrix('Pedretti2010Intracranial.csv');
Pedretti2010Intracranial(:,1) = Pedretti2010Intracranial(:,1)-12;
Pedretti2010Intracranial((Pedretti2010Intracranial(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Pedretti2010Intracranial(end,end);
Pedretti2010Intracranial(:,end) = Pedretti2010Intracranial(:,end)./Pedretti2010Intracranial(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Pedretti2010Intracranial(:,1),Pedretti2010Intracranial(:,end)));

Pedretti2010_subcutaneous = readmatrix('Pedretti2010_subcutaneous.csv');
Pedretti2010_subcutaneous(:,1) = Pedretti2010_subcutaneous(:,1)-12;
Pedretti2010_subcutaneous((Pedretti2010_subcutaneous(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Pedretti2010_subcutaneous(end,end);
Pedretti2010_subcutaneous(:,end) = Pedretti2010_subcutaneous(:,end)./Pedretti2010_subcutaneous(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Pedretti2010_subcutaneous(:,1),Pedretti2010_subcutaneous(:,end)));

Park2011 = readmatrix('Park2011.csv');
Park2011((Park2011(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Park2011(end,end);
Park2011(:,end) = Park2011(:,end)./Park2011(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Park2011(:,1),Park2011(:,end)));

Natsume2008_U251SP = readmatrix('Natsume2008_U251SP.csv');
Natsume2008_U251SP((Natsume2008_U251SP(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Natsume2008_U251SP(end,end);
Natsume2008_U251SP(:,end) = Natsume2008_U251SP(:,end)./Natsume2008_U251SP(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Natsume2008_U251SP(:,1),Natsume2008_U251SP(:,end)));

%Natsume2008_T98 = readmatrix('Natsume2008_T98.csv');
%tumour_reductionFinal(end+1) = Natsume2008_T98(end,end-1);
%tumour_reductionFinal(end+1) = Natsume2008_T98(end,end);
%tumour_reductions = cat(1,tumour_reductions,cat(2,Natsume2008_T98(:,1),Natsume2008_T98(:,end-1)));
%tumour_reductions = cat(1,tumour_reductions,cat(2,Natsume2008_T98(:,1),Natsume2008_T98(:,end)));

Miknyoczki2007 = readmatrix('Miknyoczki2007.csv');
Miknyoczki2007(:,1) = Miknyoczki2007(:,1)-1;
Miknyoczki2007((Miknyoczki2007(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Miknyoczki2007(end,end);
Miknyoczki2007(:,end) = Miknyoczki2007(:,end)./Miknyoczki2007(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Miknyoczki2007(:,1),Miknyoczki2007(:,end)));

Li2006 = readmatrix('Li2006.csv');
Li2006(:,1) = Li2006(:,1)-33;
Li2006((Li2006(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Li2006(end,end);
Li2006(:,end) = Li2006(:,end)./Li2006(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Li2006(:,1),Li2006(:,end)));

Kang2006 = readmatrix('Kang2006.csv');
Kang2006(:,1) = Kang2006(:,1)-8;
Kang2006((Kang2006(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Kang2006(end,end);
Kang2006(:,end) = Kang2006(:,end)./Kang2006(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Kang2006(:,1),Kang2006(:,end)));

Johns2003_experiment1 = readmatrix('Johns2003_experiment1.csv');
Johns2003_experiment1(:,1) = Johns2003_experiment1(:,1)-8;
Johns2003_experiment1((Johns2003_experiment1(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Johns2003_experiment1(end,end);
Johns2003_experiment1(:,end) = Johns2003_experiment1(:,end)./Johns2003_experiment1(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Johns2003_experiment1(:,1),Johns2003_experiment1(:,end)));

Johns2003_experiment2 = readmatrix('Johns2003_experiment2.csv');
Johns2003_experiment2(:,1) = Johns2003_experiment2(:,1)-13;
Johns2003_experiment2((Johns2003_experiment2(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Johns2003_experiment2(end,end);
Johns2003_experiment2(:,end) = Johns2003_experiment2(:,end)./Johns2003_experiment2(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Johns2003_experiment2(:,1),Johns2003_experiment2(:,end)));

Jin2011 = readmatrix('Jin2011.csv');
Jin2011(:,1) = Jin2011(:,1)-21;
Jin2011((Jin2011(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Jin2011(end,end);
Jin2011(:,end) = Jin2011(:,end)./Jin2011(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Jin2011(:,1),Jin2011(:,end)));

Iwado2007 = readmatrix('Iwado2007.csv');
Iwado2007(:,1) = Iwado2007(:,1)-1;
Iwado2007((Iwado2007(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Iwado2007(end,end);
Iwado2007(:,end) = Iwado2007(:,end)./Iwado2007(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Iwado2007(:,1),Iwado2007(:,end)));

Holzmuller2011 = readmatrix('Holzmuller2011.csv');
Holzmuller2011(:,1) = Holzmuller2011(:,1)-1;
Holzmuller2011((Holzmuller2011(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Holzmuller2011(end,end);
Holzmuller2011(:,end) = Holzmuller2011(:,end)./Holzmuller2011(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Holzmuller2011(:,1),Holzmuller2011(:,end)));

Gupta2006 = readmatrix('Gupta2006.csv');
Gupta2006(:,1) = Gupta2006(:,1)-21;
Gupta2006((Gupta2006(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = Gupta2006(end,end);
Gupta2006(:,end) = Gupta2006(:,end)./Gupta2006(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,Gupta2006(:,1),Gupta2006(:,end)));

deOliviera2009 = readmatrix('deOliviera2009.csv');
deOliviera2009(:,1) = deOliviera2009(:,1)-10;
deOliviera2009((deOliviera2009(:,2)==0),2) = 1; %to prevent division by 0
tumour_reductionFinal(end+1) = deOliviera2009(end,end);
deOliviera2009(:,end) = deOliviera2009(:,end)./deOliviera2009(:,2);
tumour_reductions = cat(1,tumour_reductions,cat(2,deOliviera2009(:,1),deOliviera2009(:,end)));

cd(matlab_folder)

%% plot Tumour reductions from experimental data

fig = figure;
bar(tumour_reductionFinal,'FaceColor',light_blues(8,:),'EdgeColor','none')
xlabel('Experiments')
ylabel({'Tumour reduction','(% of control)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gca,'XTick',[1:size(tumour_reductionFinal,2)])
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 15.75, 5.59])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Retrieve data from ABM simulations

px_name = "Diagnostic";
configurations = ["homogeneous"];%,"heterogeneous"];
Nconfigurations = length(configurations);
treatments = ["None"];%["None","TMZ"];
Ntreatments = length(treatments);
Nreplicate = 2; %number of replicate per case scenario
%%%%% Tumour cells information
patient.tumour = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.attached_tumour = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.local_cell_density = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.prolifRates = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.apoptosisRates = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.baselineProlifRates = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.netProlifRates = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.initialTumourCells = zeros(Nconfigurations,Ntreatments,Nreplicate,1);
patient.proliferativeTumourCells = zeros(Nconfigurations,Ntreatments,Nreplicate,1);
%%%%% CD8+ T cell information
patient.cd8 = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.attached_cd8 = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.cd8cytotoxicity_discrete = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.cd8cytotoxicity_cumulative = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.cd8_activation_levels = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.cd8_ki67pos = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
%%%%% TAM information
patient.residentTAMs = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.M1TAMs = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.M2TAMs = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.ActivatedTAMs = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
patient.M2M1ratio = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
%%%%% TMZ Intratumoral Concentration
patient.tmz = zeros(Nconfigurations,Ntreatments,Nreplicate,nOutput);
%%%%% To clean up invalid data 
to_remove = zeros(0,4);
for nC=1:Nconfigurations
    current_configuration = configurations(nC);
    for nT=1:Ntreatments
        current_treatment = treatments(nT);
        for k=0:(Nreplicate-1)
            cd(strcat(output_folder,'/',px_name,'/',current_treatment,'/rep',num2str(k)))%cd(strcat(output_folder,'/',px_name,'/',current_configuration,'/',current_treatment,'/rep',num2str(k)))
            filename_template = strcat(px_name,current_treatment,'_rep',num2str(k),'_');%strcat(px_name,'_',current_configuration,'_',current_treatment,'_rep',num2str(k),'_');
            %%%%% Tumour cells information
            load(strcat(filename_template,'tumourCells.mat'))
            load(strcat(filename_template,'attachedtumourCells.mat'))
            load(strcat(filename_template,'local_density_tumour.mat'))
            load(strcat(filename_template,'prolifRates.mat'))
            load(strcat(filename_template,'apoptosisRates.mat'))
            load(strcat(filename_template,'baselineProlifRates.mat'))
            load(strcat(filename_template,'netprolifRates.mat'))
            load(strcat(filename_template,'proliferative_cells'))
            %%%%% CD8+ T cell information
            load(strcat(filename_template,'CD8cells.mat'))
            load(strcat(filename_template,'attachedCD8cells.mat'))
            load(strcat(filename_template,'cancerCellsKilledByCd8_discrete.mat'))
            load(strcat(filename_template,'cancerCellsKilledByCd8_cumulative.mat'))
            load(strcat(filename_template,'activation_levels.mat'))
            load(strcat(filename_template,'ki67pos.mat'))
            %%%%% TAM information
            load(strcat(filename_template,'residentTAMs.mat'))
            load(strcat(filename_template,'M1TAMs.mat'))
            load(strcat(filename_template,'M2TAMs.mat'))
            load(strcat(filename_template,'allActivatedTAMs.mat'))
            %%%%% TMZ Intratumoral Concentration
            load(strcat(filename_template,'TMZ.mat'))
            %In case simulation has stopped in the middle:
            current_n_outputs = length(cancerCellsKilledByCd8_discrete);
            disp(strcat(current_configuration,' ',current_treatment,' replicate ',num2str(k),' has ',num2str(current_n_outputs),' outputs.'))
            if(current_n_outputs<nOutput)
                to_remove(end+1,:) = [nC,nT,k+1,current_n_outputs];
            end
            %%%%% Fill Tumour cells information
            patient.tumour(nC,nT,k+1,1:current_n_outputs) = tumourCells(1,1:current_n_outputs)./tumourCells(1);
            patient.attached_tumour(nC,nT,k+1,1:current_n_outputs) = attachedtumourCells(1,1:current_n_outputs);
            patient.local_cell_density(nC,nT,k+1,1:current_n_outputs) = local_density_tumour(1,1:current_n_outputs);
            patient.prolifRates(nC,nT,k+1,1:current_n_outputs) = prolifRates(1,1:current_n_outputs);
            patient.apoptosisRates(nC,nT,k+1,1:current_n_outputs) = apoptosisRates(1,1:current_n_outputs);
            patient.baselineProlifRates(nC,nT,k+1,1:current_n_outputs) = baselineProlifRates(1,1:current_n_outputs);
            patient.netProlifRates(nC,nT,k+1,1:current_n_outputs) = netprolifRates(1,1:current_n_outputs);
            patient.initialTumourCells(nC,nT,k+1,1) = tumourCells(1);
            patient.proliferativeTumourCells(nC,nT,k+1,1:current_n_outputs) = proliferative_cells(1,1:current_n_outputs);
            %%%%% Fill CD8+ T cell information
            patient.cd8(nC,nT,k+1,1:current_n_outputs) = CD8cells(1,1:current_n_outputs)./CD8cells(1);
            patient.initialCD8Cells(nC,nT,k+1,1) = CD8cells(1);
            patient.attached_cd8(nC,nT,k+1,1:current_n_outputs) = attachedCD8cells(1,1:current_n_outputs);
            patient.cd8_activation_levels(nC,nT,k+1,1:current_n_outputs) = activation_levels(1,1:current_n_outputs);
            patient.cd8cytotoxicity_discrete(nC,nT,k+1,1:current_n_outputs) = cancerCellsKilledByCd8_discrete(1,1:current_n_outputs);
            patient.cd8cytotoxicity_cumulative(nC,nT,k+1,1:current_n_outputs) = cancerCellsKilledByCd8_cumulative(1,1:current_n_outputs);
            patient.cd8_ki67pos(nC,nT,k+1,1:current_n_outputs) = ki67pos(1,1:current_n_outputs);

            %%%%% Fill TAM information
            patient.residentTAMs(nC,nT,k+1,1:current_n_outputs) = residentTAMs(1,1:current_n_outputs)./residentTAMs(1);
            patient.M1TAMs(nC,nT,k+1,1:current_n_outputs) = M1TAMs(1,1:current_n_outputs)./M1TAMs(1);
            patient.M2TAMs(nC,nT,k+1,1:current_n_outputs) = M2TAMs(1,1:current_n_outputs)./M2TAMs(1);
            patient.ActivatedTAMs(nC,nT,k+1,1:current_n_outputs) = allActivatedTAMs(1,1:current_n_outputs)./allActivatedTAMs(1);
            patient.M2M1ratio(nC,nT,k+1,1:current_n_outputs) = M2TAMs(1,1:current_n_outputs)./M1TAMs(1,1:current_n_outputs);

            %%%%% Fill TMZ information
            patient.tmz(nC,nT,k+1,1:current_n_outputs) = TMZ(1,1:current_n_outputs);
            
        end
    end
end

%% Insert NaN for invalid time points 

for nn=1:size(to_remove,1)
    nC = to_remove(nn,1);
    nT = to_remove(nn,2);
    nR = to_remove(nn,3);
    current_n_outputs = to_remove(nn,4);
    %%%%% Clean Tumour cells information
    patient.tumour(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.attached_tumour(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.local_cell_density(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.prolifRates(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.apoptosisRates(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.baselineProlifRates(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.netProlifRates(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.proliferativeTumourCells(nC,nT,nR,(current_n_outputs+1):end) = NaN;

    %%%%% Clean CD8+ T cell information
    patient.cd8(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.attached_cd8(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.cd8_activation_levels(nC,nT,nR,(current_n_outputs+1):end)= NaN;
    patient.cd8cytotoxicity_discrete(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.cd8cytotoxicity_cumulative(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.cd8_ki67pos(nC,nT,nR,(current_n_outputs+1):end) = NaN;

    %%%%% Clean TAM information
    patient.residentTAMs(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.M1TAMs(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.M2TAMs(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.ActivatedTAMs(nC,nT,nR,(current_n_outputs+1):end) = NaN;
    patient.M2M1ratio(nC,nT,nR,(current_n_outputs+1):end) = NaN;

    %%%%% Clean TMZ information
    patient.tmz(nC,nT,nR,(current_n_outputs+1):end) = NaN;
end

patient42 = patient;
cd(matlab_folder)

%% Get average tumour reduction

homogeneous_avg_tumour_notx = mean(reshape(squeeze(patient42.tumour(1,1,:,:)),[Nreplicate,nOutput]),1,"omitnan");
% homogeneous_avg_tumour_tmz = mean(reshape(squeeze(patient42.tumour(1,2,:,:)),[Nreplicate,nOutput]),1,"omitnan");
% tumour_reduction_model_homogeneous = 100.*(1-homogeneous_avg_tumour_tmz./homogeneous_avg_tumour_notx);
% 
% heterogeneous_avg_tumour_notx = mean(reshape(squeeze(patient42.tumour(2,1,:,:)),[Nreplicate,nOutput]),1,"omitnan");
% heterogeneous_avg_tumour_tmz = mean(reshape(squeeze(patient42.tumour(2,2,:,:)),[Nreplicate,nOutput]),1,"omitnan");
% tumour_reduction_model_heterogeneous = 100.*(1-heterogeneous_avg_tumour_tmz./heterogeneous_avg_tumour_notx);

%% Find vector to normalize model tumour reduction predictions
adjustTumour_Reduction = ones(1,length(time./24));
time_vect = time./24; % (in days)
dose = 150*(1.7/60); %in mg/kg
for nT=2:length(adjustTumour_Reduction)
    if(time_vect(nT)<=1)
        adjustTumour_Reduction(nT) = dose;
    elseif(time_vect(nT)<=2)
        adjustTumour_Reduction(nT) = 2*dose;
    elseif(time_vect(nT)<=3)
        adjustTumour_Reduction(nT) = 3*dose;
    elseif(time_vect(nT)<=4)
        adjustTumour_Reduction(nT) = 4*dose;
    else
        adjustTumour_Reduction(nT) = 5*dose;
    end
end

%% Keep mean and standard deviation for data
unique_times = unique(tumour_reductions(:,1));
tumourReductions_avg = zeros(length(unique_times),1);
tumourReductions_std = zeros(length(unique_times),1);
for i=1:length(unique_times)
    tm = unique_times(i);
    indTR = find(tumour_reductions(:,1)==tm);
    TR = tumour_reductions(indTR,2);
    tumourReductions_avg(i,1) = mean(TR);
    if(length(TR)>1)
        tumourReductions_std(i,1) = std(TR);
    else
        tumourReductions_std(i,1) = 0;
    end
end

%% Plot predicted tumour reduction
fig = figure;
hold on
plot(time./24,tumour_reduction_model_homogeneous,'LineWidth',plot_linewidth,'Color',color_red)
plot(time./24,tumour_reduction_model_heterogeneous,'LineWidth',plot_linewidth,'Color',color_blue)
xlabel('Time (days)')
ylabel({'Tumour reduction','(%)'})
legend({'Homogeneous','Heterogeneous'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 6.05, 4.34])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Plot normalized tumour reduction: data vs prediction
fig = figure;
hold on
%scatter(tumour_reductions(:,1),tumour_reductions(:,2),40,light_blues(8,:),"filled")
errorbar(unique_times,tumourReductions_avg,tumourReductions_std,'LineWidth',2,'Color',light_blues(8,:))
plot(time./24,tumour_reduction_model_homogeneous./adjustTumour_Reduction,'LineWidth',plot_linewidth,'Color',color_red)
plot(time./24,tumour_reduction_model_heterogeneous./adjustTumour_Reduction,'LineWidth',plot_linewidth,'Color',color_orange)
%plot([tumour_reductions(:,1); tumour_reductions(:,1)], [Mx; Mn], '--k')
legend({'Data','Model - Homogeneous','Model - Heterogeneous'})
xlim([time(1)./24,time(end)./24])
xlabel('Time after first TMZ dose (days)')
ylabel({'Normalized tumour','reduction'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 15.75, 5.59])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Tumour evolution

h_fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
xline(0,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(1,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(2,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(3,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(4,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
legend({'','Configuration aléatoire - Sans traitement','','Configuration personnalisée - Sans traitement','','Configuration aléatoire - TMZ','','Configuration personnalisée - TMZ','','','','',''})
xlabel('Temps (jours)')
ylabel({'Cellules tumorales','(% de la valeur initiale)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 11.81, 10.57])% [0, 0, 5, 5])
set(h_fig,'Units','Inches');
pos = get(h_fig,'Position');
set(h_fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(h_fig)

%% Find doubling time

td = time(find(homogeneous_avg_tumour_notx>=2,1,'first'))./24
oldbeta = 0.00073549;
newbeta = oldbeta/(49.6/td);

%% Tumour Evolution - Close up on days 0-7
h_fig2 = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tumour(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
xline(0,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(1,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(2,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(3,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xline(4,'LineWidth',plot_linewidth,'LineStyle',':','Color',[128 128 128]./255)
xlim([0 7])
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 6.05, 3.76])
set(h_fig2,'Units','Inches');
pos = get(h_fig2,'Position');
set(h_fig2,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(h_fig2)

%% Proliferative tumour cells

fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.proliferativeTumourCells(1,1,:,:)),[Nreplicate,nOutput])./ ...
    (reshape(squeeze(patient42.tumour(1,1,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialTumourCells(1,1,:))), ...
    optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.proliferativeTumourCells(2,1,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.tumour(2,1,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialTumourCells(2,1,:))), ...
%     optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.proliferativeTumourCells(1,2,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.tumour(1,2,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialTumourCells(1,2,:))), ...
%     optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.proliferativeTumourCells(2,2,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.tumour(2,2,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialTumourCells(2,2,:))), ...
%     optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('Proliferative Tumour Cells (%)')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
%set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Local cell density of tumour cells
maximum_density = 12.2553;
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.local_cell_density(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.local_cell_density(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.local_cell_density(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.local_cell_density(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
yline(maximum_density,'LineWidth',plot_linewidth,'Color','black')
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('Average local cell density')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% CD8+ T cells
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Temps (jours)')
ylabel({'Cellules T CD8+','(% de la valeur initiale)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 11.81, 10.57])%[0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)
%% Intratumoral TMZ concentrations
fig = figure;
hold on
yyaxis left
plot_areaerrorbar(100.*reshape(squeeze(patient42.tmz(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tmz(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tmz(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.tmz(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
yl = ylim;
ylabel({'TMZ Intratumoral','concentration (mg/ml)'})
yyaxis right
inf_limit = yl(1).*10^(6)./194.151;
sup_limit = yl(2).*10^(6)./194.151;
ylim([inf_limit sup_limit])
ylabel({'TMZ Intratumoral','concentration (\mu M)'})
xlabel('Time (days)')
%xlim([0 7])
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Resident TAMs
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.residentTAMs(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.residentTAMs(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.residentTAMs(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.residentTAMs(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel({'Resident TAMs','(% of initial value)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% M1 TAMs
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.M1TAMs(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M1TAMs(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M1TAMs(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M1TAMs(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('M1 TAMs (% of initial value)')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5,5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% M2 TAMs
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.M2TAMs(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M2TAMs(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M2TAMs(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.M2TAMs(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('M2 TAMs (% of initial value)')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Activated TAMs
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.ActivatedTAMs(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.ActivatedTAMs(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.ActivatedTAMs(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(100.*reshape(squeeze(patient42.ActivatedTAMs(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel({'Activated TAMs','(% of initial value)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% M2:M1 ratio
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.M2M1ratio(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.M2M1ratio(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.M2M1ratio(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.M2M1ratio(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('M2:M1 ratio')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5 ,5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Proliferation rates
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('Proliferation rate')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Proliferate rates - Close up on days 0-7
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.prolifRates(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlim([0 7])
xlabel('Time (days)')
ylabel('Proliferation rate')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 7.26, 7.26])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Baseline Proliferation rates
baselineRate = 1.038.*10^(-4);
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.baselineProlifRates(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.baselineProlifRates(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.baselineProlifRates(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.baselineProlifRates(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('Baseline')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Net Proliferation Rates
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.netProlifRates(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.netProlifRates(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.netProlifRates(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.netProlifRates(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
%yline(0,'LineWidth',plot_linewidth,'Color','black')
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Temps (jours)')
ylabel({'Taux net de','prolifération (1/min)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 16.94, 6.4])%[0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Cancer cells killed by CD8+ T cells - Discrete
fig = figure;
hold on
plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8cytotoxicity_discrete(1,1,:,:)),[Nreplicate,nOutput])./ ...
    (squeeze(patient42.initialTumourCells(1,1,:)).*reshape(squeeze(patient42.tumour(1,1,:,:)),[Nreplicate,nOutput])), ...
    optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8cytotoxicity_discrete(2,1,:,:)),[Nreplicate,nOutput])./ ...
    (squeeze(patient42.initialTumourCells(2,1,:)).*reshape(squeeze(patient42.tumour(2,1,:,:)),[Nreplicate,nOutput])), ...
    optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8cytotoxicity_discrete(1,2,:,:)),[Nreplicate,nOutput])./ ...
    (squeeze(patient42.initialTumourCells(1,2,:)).*reshape(squeeze(patient42.tumour(1,2,:,:)),[Nreplicate,nOutput])), ...
    optionsTMZHomogeneous,time./24)
plot_areaerrorbar(100.*reshape(squeeze(patient42.cd8cytotoxicity_discrete(2,2,:,:)),[Nreplicate,nOutput])./ ...
    (squeeze(patient42.initialTumourCells(2,2,:)).*reshape(squeeze(patient42.tumour(2,2,:,:)),[Nreplicate,nOutput])), ...
    optionsTMZHeterogeneous,time./24)
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Time (days)')
ylabel('Cancer cells')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Cancer cells killed by CD8+ T cells - Cumulative
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Temps (jours)')
ylabel({'','Cellules tumorales (#)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 16.94, 6.4])%[0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Cancer cells killed by CD8+ T cells - Cumulative - Close up on days 0 to 10
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(1,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(2,1,:,:)),[Nreplicate,nOutput]),optionsNoTreatmentHeterogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(1,2,:,:)),[Nreplicate,nOutput]),optionsTMZHomogeneous,time./24)
plot_areaerrorbar(reshape(squeeze(patient42.cd8cytotoxicity_cumulative(2,2,:,:)),[Nreplicate,nOutput]),optionsTMZHeterogeneous,time./24)
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlim([0 10])
xticks([])
yticks([0 2000])
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 5.79, 2.08])%[0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Ki67+ CD8+ T cells
fig = figure;
hold on
plot_areaerrorbar(reshape(squeeze(patient42.cd8_ki67pos(1,1,:,:)),[Nreplicate,nOutput])./ ...
    (reshape(squeeze(patient42.cd8(1,1,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialCD8Cells(1,1,:))) ...
    ,optionsNoTreatmentHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8_ki67pos(2,1,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.cd8(2,1,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialCD8Cells(2,1,:))), ...
%     optionsNoTreatmentHeterogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8_ki67pos(1,2,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.cd8(1,2,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialCD8Cells(1,2,:))), ...
%     optionsTMZHomogeneous,time./24)
% plot_areaerrorbar(reshape(squeeze(patient42.cd8_ki67pos(2,2,:,:)),[Nreplicate,nOutput])./ ...
%     (reshape(squeeze(patient42.cd8(2,2,:,:)),[Nreplicate,nOutput]).*squeeze(patient42.initialCD8Cells(2,2,:))), ...
%     optionsTMZHeterogeneous,time./24)
%legend({'','No treatment - Homogeneous','','No treatment - Heterogeneous','','TMZ - Homogeneous','','TMZ - Heterogeneous'})
xlabel('Temps (jours)')
ylabel({'','Ki67+ CD8+ T cells (#)'})
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 16.94, 6.4])%[0, 0, 5, 5])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Get TMZ CSF concentration profile

%cd('~/Documents/GBMs/ProjectTargetingTAMs/CodeTargetingTAMs')
cd('~/Documents/GBMs/ProjectABMODE/ODEmodel')
set_patients;
set_treatment;
p.initialcondition = [p.M10,p.M20,p.M00,p.G0,p.TkiPos0,p.TkiNeg0,p.Dd0,p.A10,p.A20,p.A30];
[sol,pAfter] = solver_ode(p);%solver_gbm(p);
cycle1Start = p.AdministrationTimesTMZ(1);%p.AdministrationTimesTMZ(43);
nDays = 7;
nTimePointsTMZ = (nDays*24*60/10)+1;
timeTMZ = linspace(cycle1Start,cycle1Start+nDays*24*60,nTimePointsTMZ);
allpop = deval(sol,timeTMZ);
TMZ = allpop(10,:)./p.Vp;
cd(main_folder)

convertTimeToDays = 60*24;

%Plot CSF concentrations
fig = figure;
yyaxis left
plot((timeTMZ-timeTMZ(1))./convertTimeToDays,TMZ,'LineWidth',plot_linewidth,'Color',color_orange)
ylabel({'TMZ CSF','concentration (mg/ml)'})
yl = ylim;
yyaxis right
inf_limit = yl(1).*10^(6)./194.151;
sup_limit = yl(2).*10^(6)./194.151;
ylim([inf_limit sup_limit])
ylabel({'TMZ CSF','concentration (\mu M)'})
xlabel('Time (days)')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

% Modulating IC50
Emax_vABM = 0.35984/(24*60);%0.3/(24*60);
IC50_vABM = 0.0011;
h_vABM = 1.8521;%0.5682;
Emax = 0.3/(24*60);
IC50 = 0.0011;
h = 0.5682;

%Effective effect
TMZ_effective_concentration = tmz_tmz_avg.*p.Vp;
TMZ_effective_effect = Emax_vABM.*((TMZ_effective_concentration.^h_vABM)./((TMZ_effective_concentration.^h_vABM)+(IC50_vABM.^h_vABM)));

%Effect with ODE parameter values
TMZ_effect_CSF_vODE = Emax.*((TMZ.^h)./((TMZ.^h)+(IC50.^h)));
TMZ_effect_intratumoral_vODE = Emax.*((tmz_tmz_avg.^h)./((tmz_tmz_avg.^h)+(IC50.^h)));

new_IC50 = [IC50.*0.1 IC50.*0.01 IC50.*0.001];

%Calculate efficacy for new IC50 values with intratumoral concentrations
TMZ_effect_intratumoral_new_IC50 = zeros(length(new_IC50),size(tmz_tmz_avg,2));
for nD=1:length(new_IC50)
    TMZ_effect_intratumoral_new_IC50(nD,:) = Emax.*((tmz_tmz_avg.^h)./((tmz_tmz_avg.^h)+(new_IC50(nD).^h)));%(1./(72*60)).*(tmz_tmz_avg./(tmz_tmz_avg+new_IC50(nD)));
end
TMZ_effect_intratumoral_new_IC50(:,tmz_tmz_avg<10^-16) = 0;

colors = distinguishable_colors(length(new_IC50)+2);

%Figure with intratumoral concentrations
fig = figure;
hold on
plot((time-time(1))./24,TMZ_effective_effect.*100,'LineWidth',plot_linewidth,'Color',colors(1,:))
plot((time-time(1))./24,TMZ_effect_intratumoral_vODE.*100,'LineWidth',plot_linewidth,'Color',colors(2,:))
for nD=1:size(TMZ_effect_intratumoral_new_IC50,1)
    plot((time-time(1))./24,TMZ_effect_intratumoral_new_IC50(nD,:).*100,'LineWidth',plot_linewidth,'Color',colors(nD+2,:))
end
legend({'Effective Effect','Current','IC50=0.1\cdot IC50','IC50=0.01\cdot IC50','IC50=0.001\cdot IC50'})
%xlim([0 7])
ylabel({'TMZ Inhibitory Effect','(% per minute)'})
xlabel('Time (days)')
title('Intratumoral')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
%set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Finding CD8(t2) with TAM-targeting ODE model

cd('~/Documents/GBMs/ProjectTargetingTAMs/CodeTargetingTAMs')
clear p
set_patients;
%Set no treatment
p.treatmentBoolean = 0;
p.treatmentRT = 0;
p.treatmentTMZ = 0;
p.treatmentICI = 0;
G0= p.volDiagnosis;
[sol,p] = solver_gbm(p);
timeODE = linspace(0,200,10000);
allpop = deval(sol,timeODE);
indexDiagnosisTime = find(allpop(3,:)>=G0,1,'first');
indexDoublingTime = find(allpop(3,:)>=2*G0,1,'first');
CD8atDoublingTime = allpop(4,indexDoublingTime)./allpop(4,indexDiagnosisTime);
cd(matlab_folder)

figure
yyaxis left
plot(timeODE,allpop(3,:)./allpop(3,indexDiagnosisTime),'LineWidth',plot_linewidth,'Color',color_red)
ylabel('Cancer cells (10^6 cells)')
yyaxis right
plot(timeODE,allpop(4,:)./allpop(4,indexDiagnosisTime),'LineWidth',plot_linewidth,'Color',color_orange)
ylabel('CD8+ T cells (10^6 cells)')
xlabel('Time (days)')
xline(timeODE(indexDoublingTime),'LineWidth',plot_linewidth,'Color',color_blue)
xline(timeODE(indexDiagnosisTime),'LineWidth',plot_linewidth,'Color',color_magenta,'LineStyle',':')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)

