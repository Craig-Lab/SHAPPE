%% Plotting two cells that are attached
cd(output_folder)
info_attachedCells = csvread('cellcounts.csv');
cd(matlab_folder)

attachedCell1 = info_attachedCells(2);
attachedCell2 = info_attachedCells(3);
time_attachment = info_attachedCells(4);

positionCell1 = zeros(2,nOutput);
positionCell2 = zeros(2,nOutput);

cstart = [245 226 136]./255;
cend = [211 56 46]./255;
colours = [cstart; cend];
breakpoints = [1; nOutput];
colours = interp1( breakpoints, colours, [1:nOutput] );

for k=1:nOutput
    k
    output_number = strcat('00000000',num2str(k-1));
    output_number = output_number(length(output_number)-8+1:end);
    filename = strcat('output',output_number,'.xml');
    MCDS = read_MultiCellDS_xml(filename,output_folder);
    cell_id = MCDS.discrete_cells.custom.cell_id;
    indCell1 = find(cell_id==attachedCell1);
    indCell2 = find(cell_id==attachedCell2);

    positionCell1(1,k) = MCDS.discrete_cells.state.position(indCell1,1);
    positionCell1(2,k) = MCDS.discrete_cells.state.position(indCell1,2);

    positionCell2(1,k) = MCDS.discrete_cells.state.position(indCell2,1);
    positionCell2(2,k) = MCDS.discrete_cells.state.position(indCell2,2);
end

figure
hold on
scatter(positionCell1(1,:),positionCell1(2,:),50,colours,'filled')
scatter(positionCell2(1,:),positionCell2(2,:),50,colours,'filled','d')
plot(positionCell1(1,:),positionCell1(2,:))
plot(positionCell2(1,:),positionCell2(2,:),'LineStyle',':')

%% save bin file
fileID = fopen('TMZ_rodent.bin','w');
fwrite(fileID,TMZ,'double');
fclose(fileID);

%% open bin file
cd(main_folder)
fileID = fopen('TMZ.bin','r');
current_TMZ = fread(fileID,'double');
fclose(fileID);
cd(matlab_folder)
figure
plot(timeTMZ./(60*24),current_TMZ)

%% Converting TMZ mg/ml concentrations to muM
mg_ml_con = 0.0011;
muM_con = 5;
mg_ml_to_muM = true;
muM_to_mg_ml = false;
if(muM_to_mg_ml)
    res = muM_con*194.151/10^6;
else
    res = mg_ml_con*10^6/(194.151);
end
disp(res)

%% Get TMZ CSF concentration profile

%cd('~/Documents/GBMs/ProjectTargetingTAMs/CodeTargetingTAMs')
cd('~/Documents/GBMs/ProjectABMODE/ODEmodel')
set_patients;
set_treatment;
p.initialcondition = [p.M10,p.M20,p.M00,p.G0,p.TkiPos0,p.TkiNeg0,p.Dd0,p.A10,p.A20,p.A30];
[sol,pAfter] = solver_ode(p);%solver_gbm(p);
cycle1Start = p.AdministrationTimesTMZ(1);%p.AdministrationTimesTMZ(43);
nDays = 7;
nTimePointsTMZ = (nDays*24*60/10)+1;
timeTMZ = linspace(cycle1Start,cycle1Start+nDays*24*60,nTimePointsTMZ);
allpop = deval(sol,timeTMZ);
TMZ = allpop(10,:)./p.Vp;
cd(main_folder)

convertTimeToDays = 60*24;

%Plot CSF concentrations
fig = figure;
yyaxis left
plot((timeTMZ-timeTMZ(1))./convertTimeToDays,TMZ,'LineWidth',plot_linewidth,'Color',color_orange)
ylabel({'TMZ CSF','concentration (mg/ml)'})
yl = ylim;
yyaxis right
inf_limit = yl(1).*10^(6)./194.151;
sup_limit = yl(2).*10^(6)./194.151;
ylim([inf_limit sup_limit])
ylabel({'TMZ CSF','concentration (\mu M)'})
xlabel('Time (days)')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

Emax_vABM = 0.35984/(24*60);%0.3/(24*60);
IC50_vABM = 0.0011;
h_vABM = 1.8521;%0.5682;
Emax_vODE = 0.3/(24*60);
IC50_vODE = 0.0011;
h_vODE = 0.5682;

%Effective effect
TMZ_effective_concentration = tmz_tmz_avg.*p.Vp;
TMZ_effective_effect = Emax_vABM.*((TMZ_effective_concentration.^h_vABM)./((TMZ_effective_concentration.^h_vABM)+(IC50_vABM.^h_vABM)));

%Effect with current ABM parameter values
TMZ_effect_CSF_vABM = Emax_vABM.*((TMZ.^h_vABM)./((TMZ.^h_vABM)+(IC50_vABM.^h_vABM)));
TMZ_effect_intratumoral_vABM = Emax_vABM.*((tmz_tmz_avg.^h_vABM)./((tmz_tmz_avg.^h_vABM)+(IC50_vABM.^h_vABM)));

%Effect with ODE parameter values
TMZ_effect_CSF_vODE = Emax_vODE.*((TMZ.^h_vODE)./((TMZ.^h_vODE)+(IC50_vODE.^h_vODE)));
TMZ_effect_intratumoral_vODE = Emax_vODE.*((tmz_tmz_avg.^h_vODE)./((tmz_tmz_avg.^h_vODE)+(IC50_vODE.^h_vODE)));

%Calculate efficacy for new IC50 values with CSF concentrations
new_IC50 = [0.00097 0.077 0.1262 0.2176 0.0049 0.1755 0.0447 0.003 0.0757 0.1206 0.0162];
%TMZ_effect_CSF_new_IC50 = ((TMZ+IC50)./TMZ).*(1-(1-(TMZ./(TMZ+IC50))).^(1/4320));
TMZ_effect_CSF_new_IC50 = zeros(length(new_IC50),size(TMZ,2));
for nD=1:length(new_IC50)
    TMZ_effect_CSF_new_IC50(nD,:) = (1./(72*60)).*(TMZ./(TMZ+new_IC50(nD)));
end

%Calculate efficacy for new IC50 values with intratumoral concentrations
%TMZ_effect_intratumoral_new_IC50 = ((tmz_tmz_avg+IC50)./tmz_tmz_avg).*(1-(1-(tmz_tmz_avg./(tmz_tmz_avg+IC50))).^(1/4320));
TMZ_effect_intratumoral_new_IC50 = zeros(length(new_IC50),size(tmz_tmz_avg,2));
for nD=1:length(new_IC50)
    TMZ_effect_intratumoral_new_IC50(nD,:) = (1./(72*60)).*(tmz_tmz_avg./(tmz_tmz_avg+new_IC50(nD)));
end
TMZ_effect_CSF_new_IC50(:,TMZ<10^-16) = 0;
TMZ_effect_intratumoral_new_IC50(:,tmz_tmz_avg<10^-16) = 0;

colors = distinguishable_colors(length(new_IC50)+3);

%Compare current ABM parameters and ODE model parameters
fig = figure;
hold on 
plot(tmz_tmz_avg,TMZ_effect_intratumoral_vABM,'LineWidth',plot_linewidth,'Color',colors(2,:))
plot(tmz_tmz_avg,TMZ_effect_intratumoral_vODE,'LineWidth',plot_linewidth,'Color',colors(3,:))
legend({'Current','ODE model parameters'})
%xlim([0 7])
ylabel({'TMZ Inhibitory Effect','(% per day)'})
xlabel('Time (days)')
title('CSF')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
%set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%Figure with CSF concentrations
fig = figure;
hold on
plot((time-time(1))./24,TMZ_effective_effect.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(1,:))
plot((timeTMZ-timeTMZ(1))./(24*60),TMZ_effect_CSF_vABM.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(2,:))
plot((timeTMZ-timeTMZ(1))./(24*60),TMZ_effect_CSF_vODE.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(3,:))
for nD=1:size(TMZ_effect_CSF_new_IC50,1)
    plot((timeTMZ-timeTMZ(1))./(24*60),TMZ_effect_CSF_new_IC50(nD,:).*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(nD+3,:))
end
legend({'Effective Effect','Current','ODE model parameters','Lo Dico','Lin2012','Pandey2019','Pédeboscq2008','Qian2012',...
    'Ramachandran2015','Ryu2012','Tian2015','Yin2014','Zhu2019','Saha2020'})
%xlim([0 7])
ylabel({'TMZ Inhibitory Effect','(% per day)'})
xlabel('Time (days)')
title('CSF')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
%set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%Figure with intratumoral concentrations
fig = figure;
hold on
plot((time-time(1))./24,TMZ_effective_effect.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(1,:))
plot((time-time(1))./24,TMZ_effect_intratumoral_vABM.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(2,:))
plot((time-time(1))./24,TMZ_effect_intratumoral_vODE.*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(3,:))
for nD=1:size(TMZ_effect_intratumoral_new_IC50,1)
    plot((time-time(1))./24,TMZ_effect_intratumoral_new_IC50(nD,:).*100.*24.*60,'LineWidth',plot_linewidth,'Color',colors(nD+3,:))
end
legend({'Effective Effect','Current','ODE model parameters','Lo Dico','Lin2012','Pandey2019','Pédeboscq2008','Qian2012',...
    'Ramachandran2015','Ryu2012','Tian2015','Yin2014','Zhu2019','Saha2020'})
%xlim([0 7])
ylabel({'TMZ Inhibitory Effect','(% per day)'})
xlabel('Time (days)')
title('Intratumoral')
set(gca,'FontSize',axis_fontsize,'LineWidth',axis_linewidth)
set(gcf,'Units','Centimeters')
%set(gcf, 'Position',  [0, 0, 7.09, 5.7])
set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
printFig(fig)

%% Hooke's law algorithm for cancer cells

cd(folder_data)
load('s_cancer_march18th.mat')
load('dc_cancer_march18th.mat')
s = s_cancer;
dc = dc_cancer;
cd(folder_csvFolder)
randomConfiguration = readmatrix("cellsPatient42_10000.csv");
cd(folder_matlab)

cellPlacement_cancer = randomConfiguration(randomConfiguration(:,end)==type_GBM,:);
N_GBM = size(cellPlacement_cancer,1);
if(size(cellPlacement_cancer,2)>3)
    cellPlacement_cancer(:,3) = [];
end
lambda = 0.01/0.133;
endCriterion = 1.1875*N_GBM;%

continueTime = true;
counter = 0;
maxIterations = 1000;
sum_displacements = zeros(1,maxIterations);
while(continueTime)
    disp(counter)
    displacements = zeros(N_GBM,2);
    %Update every cell
    for nC=1:N_GBM
        current_type = cellPlacement_cancer(nC,end);
        current_x = cellPlacement_cancer(nC,1);
        current_y = cellPlacement_cancer(nC,2);
        current_pos= [current_x,current_y];
        nearest_cells = getCellNearestNeighbors(nC,cellPlacement_cancer,type_GBM,type_CD8,type_Stroma,type_M0,type_M1,type_M2);
        displacement_vector(1,1) = nearest_cells(indCancer,1)-current_x;
        displacement_vector(1,2) = nearest_cells(indCancer,2)-current_y;
        temp = displacement_vector(1,:);
        current_min = norm(temp);
        desired_min_distance = s(nC,1);
        cell_displacement = temp.*(current_min-desired_min_distance)./current_min;
        cell_displacement = cell_displacement-(current_pos./norm(current_pos)).*(norm(current_pos)-dc(nC,1));
        cell_displacement = lambda.*cell_displacement;
        %Verify if you exit domain
        temp_x = cell_displacement(1,1)+current_x;
        temp_y = cell_displacement(1,2)+current_y;
        cellRadiusPosition = sqrt(temp_x.^2+temp_y.^2);
        if(cellRadiusPosition>(1.4.*R))
            cell_displacement = cell_displacement-cellPlacement_cancer(nC,1:2).*2.*R.*(1./norm(cellPlacement_cancer(nC,1:2)));
        end
        %Set new displacement
        displacements(nC,:) = cell_displacement;
    end

    %Check if we have final configuration
    displacements_size = sqrt(displacements(:,1).^2+displacements(:,2).^2);
    sum_displacements(1,counter+1) = sum(displacements_size);
    if(sum(displacements_size)<=endCriterion)
        disp('Cell positions converged.')
        continueTime = false;
    elseif((counter+1)>=10 && (mean(abs(diff(sum_displacements(1,(counter-8):(counter+1))))./lambda)./length(N_GBM))<=0.2)
        disp('Cell positions converged - Criterion 2.')
        continueTime = false;
    else
        %Update positions
        cellPlacement_cancer(:,1:2) = cellPlacement_cancer(:,1:2)+displacements(:,:);
    end
    counter = counter+1;
    if(counter>=maxIterations)
        disp('You have reached maxIterations.')
        continueTime = false;
    end
    if(any(any(isnan(cellPlacement_cancer))))
        disp('There is a NaN!')
        continueTime = false;
    end
end