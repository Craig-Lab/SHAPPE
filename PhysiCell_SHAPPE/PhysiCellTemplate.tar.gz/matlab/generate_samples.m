cell_radius = 10.75;
R = 100;
N = floor((0.70.*pi*R^2)/(pi*cell_radius^2));
cells = zeros(0,4);
i = 0;
cells(i+1,:) = [0,0,0,2];
i = i+1;

while(i<N)
    theta=2*pi*rand;
    r=sqrt(rand);
    x=(R*r)*cos(theta);
    y=(R*r)*sin(theta);
    tempCell = [x,y,0,2];
    accept = check_intersection(cells,tempCell);
    if(accept)
        cells(i+1,:) = tempCell;
        i = i+1
    end
end

function accept = check_intersection(cells,new_cell)
    accept=true;
    for j=1:size(cells,1)
        tested_cell = cells(j,:);
        distance_between_centers = sqrt((new_cell(1)-tested_cell(1)).^2+(new_cell(2)-tested_cell(2)).^2);
        if(distance_between_centers<=2*10.75)
            accept = false;
            break
        end
    end
end