matlab_folder = cd('..');
outputInformation = readmatrix('outputInformation.csv');
patientNumber = outputInformation(end,1);
treatmentNumber = outputInformation(end,2);
replicateNumber = outputInformation(end,3);
listNumber = outputInformation(end,4);
%treatmentNumber = 1;
%replicateNumber = 0;

patients = ["Diagnostic"];%["patient96","patient102","patient146"];%["Diagnostic_Convergence"];%
treatments = ["None"];

main_folder = cd('outputMatlab/');
outputMatlabFolder = cd('../output/');%cd('../output_TMZ/');%
cellsCreated = readmatrix('cellcounts.csv');
deadCells = readmatrix('deadcells.csv');
results_folder = cd(matlab_folder);

%constants
time_start = 0;
time_end = 72000;%
time_interval = 60;
nOutput = floor(1+(time_end-time_start)./time_interval);
time = [0:nOutput-1].*(time_interval/60);
type_CD8 = 1;
type_GBM = 2;
type_Stroma = 3;
type_TAM = 4;
type_oxygen = 1;
type_TMZ = 2;
type_wall = 3;
type_chemokine = 4;

%CD8 cytotoxicity
cancerCellsKilledByCd8_cumulative = deadCells(:,3)';
cancerCellsKilledByCd8_discrete = cancerCellsKilledByCd8_cumulative;
for nT=2:size(cancerCellsKilledByCd8_cumulative,2)
    cancerCellsKilledByCd8_discrete(1,nT) = cancerCellsKilledByCd8_cumulative(1,nT)-cancerCellsKilledByCd8_cumulative(1,nT-1);
end

nOutput = length(cancerCellsKilledByCd8_discrete);

%CD8+ T cells
CD8cells = zeros(1,nOutput);
attachedCD8cells = zeros(1,nOutput);
activation_levels = zeros(1,nOutput);
ki67pos = zeros(1,nOutput);

%Cancer cells
tumourCells = zeros(1,nOutput);
prolifRates = zeros(1,nOutput);
netprolifRates = zeros(1,nOutput);
baselineProlifRates = zeros(1,nOutput);
apoptosisRates = zeros(1,nOutput);
attachedtumourCells = zeros(1,nOutput);
local_density_tumour = zeros(1,nOutput);
proliferative_cells = zeros(1,nOutput);

%TAMs
residentTAMs = zeros(1,nOutput);
M1TAMs = zeros(1,nOutput);
M2TAMs = zeros(1,nOutput);
allActivatedTAMs = zeros(1,nOutput);

%Stroma Cell
stromaCells = zeros(1,nOutput);

positions_size = nOutput;  %number of elements
positions(positions_size) = struct();

disp(size(cancerCellsKilledByCd8_cumulative))

disp(size(cancerCellsKilledByCd8_discrete))

disp(results_folder)

for k=1:10%nOutput
    output_number = strcat('00000000',num2str(k-1));
    output_number = output_number(length(output_number)-8+1:end);
    filename = strcat('output',output_number,'_cells.mat');
    full_file_path = strcat(results_folder,'/',filename);
    file_exists = isfile(full_file_path);
    if(file_exists)
        disp(strcat(full_file_path,' exists!'))
        %MCDS = read_MultiCellDS_xml(filename,results_folder);
        load(strcat(results_folder,'/',filename))
        indDead = find(cells(7,:)==100);
        indCD8 = setdiff(find(cells(6,:)==type_CD8),indDead);
        indTumour = setdiff(find(cells(6,:)==type_GBM),indDead);
        indTAMs = setdiff(find(cells(6,:)==type_TAM),indDead);
        indStroma = setdiff(find(cells(6,:)==type_Stroma),indDead);
    
        %CD8+ T cell analysis
        %%%%%Number of CD8+ T cells
        CD8cells(1,k) = length(indCD8);
        %%%%%CD8+ T cells attached to a tumour cell
        indAttached = find(cells(142,:)==1);
        indCD8Attached = intersect(indCD8,indAttached);
        attachedCD8cells(1,k) = length(indCD8Attached);
        %%%%%Activation levels
        activation_levels(1,k) = mean(cells(145,indCD8));
        %%%%%Number of Ki67+ CD8+ T cells
        indKi67 = find(cells(152,:)==1);
        indCD8Ki67pos = intersect(indCD8,indKi67);
        ki67pos(1,k) = length(indCD8Ki67pos);
        
        %Tumour cells
        %%%%%find indexes of dead tumour cells
        indDeadTumourCells = find(cells(146,:)==1);
        indTumour = setdiff(indTumour,indDeadTumourCells);
        %%%%%number of tumour cells alive
        tumourCells(1,k) = length(indTumour);
        %%%%%number of tumour cells attached to a cd8+ t cell
        indAttachedTumourCells = find(cells(142,:)==1);
        indAttachedTumourCells = intersect(indTumour,indAttachedTumourCells);
        attachedtumourCells(1,k) = length(indAttachedTumourCells);
        %%%%%Baseline proliferation rates
        baselineProlif = cells(137,indTumour);
        %%%%%Actual proliferation rates
        proliferation = cells(135,indTumour);
        prolifRates(1,k) = mean(proliferation);
        baselineProlifRates(1,k) = mean(baselineProlif);
        %%%%%TMZ-induced apoptosis rate
        apoptosis = cells(149,indTumour);
        apoptosisRates(1,k) = mean(apoptosis);
        %%%%%Net proliferation rate
        net_prolif = cells(136,indTumour);
        netprolifRates(1,k) = mean(net_prolif);
        %%%%%Local density
        lc_density = cells(138,indTumour);
        local_density_tumour(1,k) = mean(lc_density);
        %%%%%Number of proliferative cancer cells
        num_proliferative = length(find(proliferation>0));
        proliferative_cells(1,k) = num_proliferative;
    
        %TAMs
        TAMphenotype = cells(147,indTAMs);
        indM1TAMs = intersect(find(cells(147,:)==1),indTAMs);
        indM2TAMs = intersect(find(cells(147,:)==2),indTAMs);
        nResident = length(find(TAMphenotype==0));
        nM1 = length(find(TAMphenotype==1));
        nM2 = length(find(TAMphenotype==2));
        allActivatedTAMs(1,k) = nM1+nM2;
        residentTAMs(1,k) = nResident;
        M1TAMs(1,k) = nM1;
        M2TAMs(1,k) = nM2;
    
        %Stroma cells
        %%%%%Number of stroma cells
        stromaCells(1,k) = length(indStroma);
    
        % %TMZ
        % TMZdensity = MCDS.continuum_variables(type_TMZ).data;
        % x = MCDS.discrete_cells.state.position(:,1);
        % indAlive = setdiff([1:size(x,1)],indDead);
        % x = x(indAlive);
        % y = MCDS.discrete_cells.state.position(indAlive,2);
        % tumourRegionRadius = max(sqrt(x.^2+y.^2));
        % W = ceil(2*tumourRegionRadius./20);
        % T = size(TMZdensity,1);
        % if(mod((T-W),2)==1) 
        %     W = W+1;
        % end
        % %%%%%Get TMZ density in tumour region
        % try
        %     TMZdensity = TMZdensity((((T-W)/2)+1):(T-((T-W)/2)),(((T-W)/2)+1):(T-((T-W)/2)));
        % catch
        %     TMZdensity = TMZdensity;
        % end
        % TMZ(1,k) = mean(TMZdensity,"all");
    
        %%%%%Save (x,y) positions of cells, their ID and their type
        cellID = cells(134,:);
        cellID = cellID';
        types = zeros(length(cellID),1);
        types(indCD8,1) = 1;
        types(indTumour,1) = 2;
        types(indStroma,1) = 3;
        types(indTAMs,1) = 4;
        types(indM1TAMs,1) = 5;
        types(indM2TAMs,1) = 6;
        pos_x = cells(2,:)';
        pos_y = cells(3,:)';
        pos = [cellID,pos_x,pos_y,types];
        positions(k).pos = pos;
    else
        %break out of for loop
        k=nOutput+1;
        cancerCellsKilledByCd8_cumulative(1,end) = [];
        cancerCellsKilledByCd8_discrete(1,end) = [];
    end
end