get_metrics <- function(data1,data2) {
  #Initialize result matrix
  results_patient = matrix(NA, nrow=6, ncol=4)
  celltypes = c("Cancer","CD8","Stroma","M1","M2","M0")
  distancetypes = c("Cancer","CD8","Stroma","M1","M2","M0","X","Y")
  #Outer loops: celltypes
  for (nC in 1:length(celltypes)) {
    overlapIndexDistances = 0
    NcellsData1 = length(na.omit(data1[,(nC-1)*8+1]))
    NcellsData2 = length(na.omit(data2[,(nC-1)*8+1]))
    if(NcellsData1>4 & NcellsData2 >4) {
      #Inner loop: DDOC 
      for (nD in 1:length(celltypes)) {
        current_distribution_name = paste(celltypes[nC],"_",distancetypes[nD],sep="")
        current_data1_dist = na.omit(data1[,current_distribution_name])
        current_data2_dist = na.omit(data2[,current_distribution_name])
        overlapIndexDistances = overlapIndexDistances+overlap(list(x=current_data1_dist,y=current_data2_dist),plot=FALSE)$OV
      }
      results_patient[nC,1] = overlapIndexDistances/length(celltypes) #average
      
      #XOC and YOC
      overlapX = overlap(list(x=na.omit(data1[,paste(celltypes[nC],"_",distancetypes[7],sep="")]),y=na.omit(data2[,paste(celltypes[nC],"_",distancetypes[7],sep="")])),plot=FALSE)$OV
      overlapY = overlap(list(x=na.omit(data1[,paste(celltypes[nC],"_",distancetypes[8],sep="")]),y=na.omit(data2[,paste(celltypes[nC],"_",distancetypes[8],sep="")])),plot=FALSE)$OV
      results_patient[nC,2] = overlapX
      results_patient[nC,3] = overlapY
      
      #CAC
      ## 1st data set
      celltype_distributions_data1 = na.omit(data1[,((nC-1)*8+1):((nC-1)*8+8)])
      #### Spearman correlation coefficients
      corelations_data1 = rcorr(as.matrix(celltype_distributions_data1),type="spearman")[[1]]
      PvalData1 = rcorr(as.matrix(celltype_distributions_data1),type="spearman")[[3]]
      corelations_data1[which(is.na(corelations_data1))] = 0
      ## 2nd data set
      celltype_distributions_data2 = na.omit(data2[,((nC-1)*8+1):((nC-1)*8+8)])
      #### Spearman correlation coefficients
      corelations_data2 = rcorr(as.matrix(celltype_distributions_data2),type="spearman")[[1]]
      PvalRandom = rcorr(as.matrix(celltype_distributions_data2),type="spearman")[[3]]
      corelations_data2[which(is.na(corelations_data2))] = 0
      na_index_random = which(is.na(corelations_data2))
      
      test_sign_random = corelations_data1*corelations_data2
      wrong_sign_index_random = which(test_sign_random<0)
      CAC = 1-abs((corelations_data1-corelations_data2))
      CAC[wrong_sign_index_random] = 0
      
      #only keep upper triangle
      kept_correlations = which(upper.tri(CAC,diag=F))
      CAC = CAC[kept_correlations]
      CAC = sum(CAC)/length(kept_correlations)#(dim(corelations_random)[1]^2)
      results_patient[nC,4] = CAC
    }
  }
  return (results_patient)
}