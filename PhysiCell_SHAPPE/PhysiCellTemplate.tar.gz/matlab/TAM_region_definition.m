clearvars;
%%
Nregion = 10;
totalRadius = 994.92;
totalArea = pi.*(totalRadius.^2);
regionArea = totalArea./10;
R = zeros(1,Nregion+1);

for nR=1:Nregion
    previous_r = R(nR);
    next_r = sqrt((regionArea+(pi.*(previous_r).^2))./pi);
    R(nR+1) = next_r;
end