
matlab_folder = cd('..');
outputInformation = readmatrix('outputInformation.csv');
patientNumber = outputInformation(end,1)
treatmentNumber = outputInformation(end,2)
replicateNumber = outputInformation(end,3)
%treatmentNumber = 1;
%replicateNumber = 0;

patients = ["Diagnostic_test"];%["patient96","patient102","patient146"];%["Diagnostic_Convergence"];%
treatments = ["None"];

main_folder = cd('outputMatlab/');
outputMatlabFolder = cd('../output/');%cd('../output_TMZ/');%
cellsCreated = readmatrix('cellcounts.csv');
deadCells = readmatrix('deadcells.csv');
results_folder = cd(matlab_folder);

%constants
time_start = 0;
time_end = 120;%
time_interval = 60;
nOutput = floor(1+(time_end-time_start)./time_interval);
time = [0:nOutput-1].*(time_interval/60);
type_CD8 = 1;
type_GBM = 2;
type_Stroma = 3;
type_TAM = 4;
type_oxygen = 1;
type_TMZ = 2;
type_wall = 3;
type_chemokine = 4;

%CD8 cytotoxicity
cancerCellsKilledByCd8_cumulative = deadCells(:,3)';
cancerCellsKilledByCd8_discrete = cancerCellsKilledByCd8_cumulative;
for nT=2:size(cancerCellsKilledByCd8_cumulative,2)
    cancerCellsKilledByCd8_discrete(1,nT) = cancerCellsKilledByCd8_cumulative(1,nT)-cancerCellsKilledByCd8_cumulative(1,nT-1);
end

nOutput = length(cancerCellsKilledByCd8_discrete)

%CD8+ T cells
CD8cells = zeros(1,nOutput);
attachedCD8cells = zeros(1,nOutput);
activation_levels = zeros(1,nOutput);
ki67pos = zeros(1,nOutput);

%Cancer cells
tumourCells = zeros(1,nOutput);
prolifRates = zeros(1,nOutput);
netprolifRates = zeros(1,nOutput);
baselineProlifRates = zeros(1,nOutput);
apoptosisRates = zeros(1,nOutput);
attachedtumourCells = zeros(1,nOutput);
local_density_tumour = zeros(1,nOutput);
proliferative_cells = zeros(1,nOutput);

%TAMs
residentTAMs = zeros(1,nOutput);
M1TAMs = zeros(1,nOutput);
M2TAMs = zeros(1,nOutput);
allActivatedTAMs = zeros(1,nOutput);

%Stroma Cell
stromaCells = zeros(1,nOutput);

positions_size = nOutput;  %number of elements
positions(positions_size) = struct();

%TMZ concentration
TMZ = zeros(1,nOutput);

%read data
for k=1:nOutput
    output_number = strcat('00000000',num2str(k-1));
    output_number = output_number(length(output_number)-8+1:end);
    filename = strcat('output',output_number,'.xml');
    
    file_exists = isfile(strcat(results_folder,'/',filename));
    if(file_exists)
        MCDS = read_MultiCellDS_xml(filename,results_folder);
    
        indDead = MCDS.discrete_cells.dead_cells;
        indCD8 = setdiff(find(MCDS.discrete_cells.metadata.type==type_CD8),indDead);
        indTumour = setdiff(find(MCDS.discrete_cells.metadata.type==type_GBM),indDead);
        indTAMs = setdiff(find(MCDS.discrete_cells.metadata.type==type_TAM),indDead);
        indStroma = setdiff(find(MCDS.discrete_cells.metadata.type==type_Stroma),indDead);
    
        %CD8+ T cell analysis
        %%%%%Number of CD8+ T cells
        CD8cells(1,k) = length(indCD8);
        %%%%%CD8+ T cells attached to a tumour cell
        indAttached = find(MCDS.discrete_cells.custom.is_attached==1);
        indCD8Attached = intersect(indCD8,indAttached);
        attachedCD8cells(1,k) = length(indCD8Attached);
        %%%%%Activation levels
        activation_levels(1,k) = mean(MCDS.discrete_cells.custom.activation_level(indCD8));
        %%%%%Number of Ki67+ CD8+ T cells
        indKi67 = find(MCDS.discrete_cells.custom.Ki67pos==1);
        indCD8Ki67pos = intersect(indCD8,indKi67);
        ki67pos(1,k) = length(indCD8Ki67pos);
        
        %Tumour cells
        %%%%%find indexes of dead tumour cells
        indDeadTumourCells = find(MCDS.discrete_cells.custom.is_dead==1);
        indTumour = setdiff(indTumour,indDeadTumourCells);
        %%%%%number of tumour cells alive
        tumourCells(1,k) = length(indTumour);
        %%%%%number of tumour cells attached to a cd8+ t cell
        indAttachedTumourCells = find(MCDS.discrete_cells.custom.is_attached==1);
        indAttachedTumourCells = intersect(indTumour,indAttachedTumourCells);
        attachedtumourCells(1,k) = length(indAttachedTumourCells);
        %%%%%Baseline proliferation rates
        baselineProlif = MCDS.discrete_cells.custom.baseline_proliferation_rate(indTumour);
        %%%%%Actual proliferation rates
        proliferation = MCDS.discrete_cells.custom.proliferation_rate(indTumour);
        prolifRates(1,k) = mean(proliferation);
        baselineProlifRates(1,k) = mean(baselineProlif);
        %%%%%TMZ-induced apoptosis rate
        apoptosis = MCDS.discrete_cells.custom.apoptosis_rate(indTumour);
        apoptosisRates(1,k) = mean(apoptosis);
        %%%%%Net proliferation rate
        net_prolif = MCDS.discrete_cells.custom.net_proliferation_rate(indTumour);
        netprolifRates(1,k) = mean(net_prolif);
        %%%%%Local density
        lc_density = MCDS.discrete_cells.custom.neighborhood_density(indTumour);
        local_density_tumour(1,k) = mean(lc_density);
        %%%%%Number of proliferative cancer cells
        num_proliferative = length(find(proliferation>0));
        proliferative_cells(1,k) = num_proliferative;
    
        %TAMs
        TAMphenotype = MCDS.discrete_cells.custom.phenotype(indTAMs);
        indM1TAMs = intersect(find(MCDS.discrete_cells.custom.phenotype==1),indTAMs);
        indM2TAMs = intersect(find(MCDS.discrete_cells.custom.phenotype==2),indTAMs);
        nResident = length(find(TAMphenotype==0));
        nM1 = length(find(TAMphenotype==1));
        nM2 = length(find(TAMphenotype==2));
        allActivatedTAMs(1,k) = nM1+nM2;
        residentTAMs(1,k) = nResident;
        M1TAMs(1,k) = nM1;
        M2TAMs(1,k) = nM2;
    
        %Stroma cells
        %%%%%Number of stroma cells
        stromaCells(1,k) = length(indStroma);
    
        %TMZ
        TMZdensity = MCDS.continuum_variables(type_TMZ).data;
        x = MCDS.discrete_cells.state.position(:,1);
        indAlive = setdiff([1:size(x,1)],indDead);
        x = x(indAlive);
        y = MCDS.discrete_cells.state.position(indAlive,2);
        tumourRegionRadius = max(sqrt(x.^2+y.^2));
        W = ceil(2*tumourRegionRadius./20);
        T = size(TMZdensity,1);
        if(mod((T-W),2)==1) 
            W = W+1;
        end
        %%%%%Get TMZ density in tumour region
        try
            TMZdensity = TMZdensity((((T-W)/2)+1):(T-((T-W)/2)),(((T-W)/2)+1):(T-((T-W)/2)));
        catch
            TMZdensity = TMZdensity;
        end
        TMZ(1,k) = mean(TMZdensity,"all");
    
        %%%%%Save (x,y) positions of cells, their ID and their type
        cellID = MCDS.discrete_cells.custom.cell_id;
        cellID = cellID';
        types = zeros(length(cellID),1);
        types(indCD8,1) = 1;
        types(indTumour,1) = 2;
        types(indStroma,1) = 3;
        types(indTAMs,1) = 4;
        types(indM1TAMs,1) = 5;
        types(indM2TAMs,1) = 6;
        pos_x = MCDS.discrete_cells.state.position(:,1);
        pos_y = MCDS.discrete_cells.state.position(:,2);
        pos = [cellID,pos_x,pos_y,types];
        positions(k).pos = pos;
    else
        %break out of for loop
        k=nOutput+1;
        cancerCellsKilledByCd8_cumulative(1,end) = [];
        cancerCellsKilledByCd8_discrete(1,end) = [];
    end
end

%save data
cd(outputMatlabFolder)

% switch patientNumber
%     case 0
%         px = 'patient42_homogeneous_';
%     case 1
%         px = 'patient42_heterogeneous_';
%     otherwise
%         px = 'Other';
% end

px = patients(patientNumber+1);
tx = treatments(treatmentNumber+1);

% switch treatmentNumber
%     case 0
%         tx = 'None';
%     case 1
%         tx = 'TMZ';
%     otherwise
%         tx = 'Other';
% end

patient_output_folder = strcat(outputMatlabFolder,'/',px,'/',tx,'/rep',num2str(replicateNumber));
mkdir(patient_output_folder)
cd(patient_output_folder)
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_cancerCellsKilledByCd8_cumulative','.mat'),'cancerCellsKilledByCd8_cumulative');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_cancerCellsKilledByCd8_discrete','.mat'),'cancerCellsKilledByCd8_discrete');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_CD8cells','.mat'),'CD8cells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_attachedCD8cells','.mat'),'attachedCD8cells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_ki67pos','.mat'),'ki67pos');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_activation_levels','.mat'),'activation_levels');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_tumourCells','.mat'),'tumourCells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_prolifRates','.mat'),'prolifRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_baselineProlifRates','.mat'),'baselineProlifRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_apoptosisRates','.mat'),'apoptosisRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_residentTAMs','.mat'),'residentTAMs');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_M1TAMs','.mat'),'M1TAMs');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_M2TAMs','.mat'),'M2TAMs');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_allActivatedTAMs','.mat'),'allActivatedTAMs');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_TMZ','.mat'),'TMZ');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_positions','.mat'),'positions');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_netprolifRates','.mat'),'netprolifRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_attachedtumourCells','.mat'),'attachedtumourCells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_local_density_tumour','.mat'),'local_density_tumour');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_proliferative_cells','.mat'),'proliferative_cells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_stroma_cells','.mat'),'stromaCells');

disp('All structures saved.')

cd(matlab_folder)
%%
% disp('coucou0')
% 
% try
%     disp('coucou1')
%     matlab_folder = cd('..');
%     outputInformation = readmatrix('outputInformation.csv');
%     patientNumber = outputInformation(end,1)
%     treatmentNumber = outputInformation(end,2)
%     replicateNumber = outputInformation(end,3)
%     %treatmentNumber = 1;
%     %replicateNumber = 0;
% 
%     patients = ["Diagnostic_test"];%["patient96","patient102","patient146"];%["Diagnostic_Convergence"];%
%     treatments = ["None"];
% 
%     main_folder = cd('outputMatlab/');
%     outputMatlabFolder = cd('../output/');%cd('../output_TMZ/');%
%     cellsCreated = readmatrix('cellcounts.csv');
%     deadCells = readmatrix('deadcells.csv');
%     results_folder = cd(matlab_folder);
% 
%     %constants
%     time_start = 0;
%     time_end = 72000;%
%     time_interval = 60;
%     nOutput = floor(1+(time_end-time_start)./time_interval);
%     time = [0:nOutput-1].*(time_interval/60);
%     type_CD8 = 1;
%     type_GBM = 2;
%     type_Stroma = 3;
%     type_TAM = 4;
%     type_oxygen = 1;
%     type_TMZ = 2;
%     type_wall = 3;
%     type_chemokine = 4;
% 
%     %CD8 cytotoxicity
%     cancerCellsKilledByCd8_cumulative = deadCells(:,3)';
%     cancerCellsKilledByCd8_discrete = cancerCellsKilledByCd8_cumulative;
%     for nT=2:size(cancerCellsKilledByCd8_cumulative,2)
%         cancerCellsKilledByCd8_discrete(1,nT) = cancerCellsKilledByCd8_cumulative(1,nT)-cancerCellsKilledByCd8_cumulative(1,nT-1);
%     end
% 
%     nOutput = length(cancerCellsKilledByCd8_discrete)
% 
%     %CD8+ T cells
%     CD8cells = zeros(1,nOutput);
%     attachedCD8cells = zeros(1,nOutput);
%     activation_levels = zeros(1,nOutput);
%     ki67pos = zeros(1,nOutput);
% 
%     %Cancer cells
%     tumourCells = zeros(1,nOutput);
%     prolifRates = zeros(1,nOutput);
%     netprolifRates = zeros(1,nOutput);
%     baselineProlifRates = zeros(1,nOutput);
%     apoptosisRates = zeros(1,nOutput);
%     attachedtumourCells = zeros(1,nOutput);
%     local_density_tumour = zeros(1,nOutput);
%     proliferative_cells = zeros(1,nOutput);
% 
%     %TAMs
%     residentTAMs = zeros(1,nOutput);
%     M1TAMs = zeros(1,nOutput);
%     M2TAMs = zeros(1,nOutput);
%     allActivatedTAMs = zeros(1,nOutput);
% 
%     %Stroma Cell
%     stromaCells = zeros(1,nOutput);
% 
%     positions_size = nOutput;  %number of elements
%     positions(positions_size) = struct();
% 
%     %TMZ concentration
%     TMZ = zeros(1,nOutput);
% 
%     %read data
%     for k=1:nOutput
%         output_number = strcat('00000000',num2str(k-1));
%         output_number = output_number(length(output_number)-8+1:end);
%         filename = strcat('output',output_number,'.xml');
% 
%         file_exists = isfile(strcat(results_folder,'/',filename));
%         if(file_exists)
%             k
%             MCDS = read_MultiCellDS_xml(filename,results_folder);
% 
%             indDead = MCDS.discrete_cells.dead_cells;
%             indCD8 = setdiff(find(MCDS.discrete_cells.metadata.type==type_CD8),indDead);
%             indTumour = setdiff(find(MCDS.discrete_cells.metadata.type==type_GBM),indDead);
%             indTAMs = setdiff(find(MCDS.discrete_cells.metadata.type==type_TAM),indDead);
%             indStroma = setdiff(find(MCDS.discrete_cells.metadata.type==type_Stroma),indDead);
% 
%             %CD8+ T cell analysis
%             %%%%%Number of CD8+ T cells
%             CD8cells(1,k) = length(indCD8);
%             %%%%%CD8+ T cells attached to a tumour cell
%             indAttached = find(MCDS.discrete_cells.custom.is_attached==1);
%             indCD8Attached = intersect(indCD8,indAttached);
%             attachedCD8cells(1,k) = length(indCD8Attached);
%             %%%%%Activation levels
%             activation_levels(1,k) = mean(MCDS.discrete_cells.custom.activation_level(indCD8));
%             %%%%%Number of Ki67+ CD8+ T cells
%             indKi67 = find(MCDS.discrete_cells.custom.Ki67pos==1);
%             indCD8Ki67pos = intersect(indCD8,indKi67);
%             ki67pos(1,k) = length(indCD8Ki67pos);
% 
%             %Tumour cells
%             %%%%%find indexes of dead tumour cells
%             indDeadTumourCells = find(MCDS.discrete_cells.custom.is_dead==1);
%             indTumour = setdiff(indTumour,indDeadTumourCells);
%             %%%%%number of tumour cells alive
%             tumourCells(1,k) = length(indTumour);
%             %%%%%number of tumour cells attached to a cd8+ t cell
%             indAttachedTumourCells = find(MCDS.discrete_cells.custom.is_attached==1);
%             indAttachedTumourCells = intersect(indTumour,indAttachedTumourCells);
%             attachedtumourCells(1,k) = length(indAttachedTumourCells);
%             %%%%%Baseline proliferation rates
%             baselineProlif = MCDS.discrete_cells.custom.baseline_proliferation_rate(indTumour);
%             %%%%%Actual proliferation rates
%             proliferation = MCDS.discrete_cells.custom.proliferation_rate(indTumour);
%             prolifRates(1,k) = mean(proliferation);
%             baselineProlifRates(1,k) = mean(baselineProlif);
%             %%%%%TMZ-induced apoptosis rate
%             apoptosis = MCDS.discrete_cells.custom.apoptosis_rate(indTumour);
%             apoptosisRates(1,k) = mean(apoptosis);
%             %%%%%Net proliferation rate
%             net_prolif = MCDS.discrete_cells.custom.net_proliferation_rate(indTumour);
%             netprolifRates(1,k) = mean(net_prolif);
%             %%%%%Local density
%             lc_density = MCDS.discrete_cells.custom.neighborhood_density(indTumour);
%             local_density_tumour(1,k) = mean(lc_density);
%             %%%%%Number of proliferative cancer cells
%             num_proliferative = length(find(proliferation>0));
%             proliferative_cells(1,k) = num_proliferative;
% 
%             %TAMs
%             TAMphenotype = MCDS.discrete_cells.custom.phenotype(indTAMs);
%             indM1TAMs = intersect(find(MCDS.discrete_cells.custom.phenotype==1),indTAMs);
%             indM2TAMs = intersect(find(MCDS.discrete_cells.custom.phenotype==2),indTAMs);
%             nResident = length(find(TAMphenotype==0));
%             nM1 = length(find(TAMphenotype==1));
%             nM2 = length(find(TAMphenotype==2));
%             allActivatedTAMs(1,k) = nM1+nM2;
%             residentTAMs(1,k) = nResident;
%             M1TAMs(1,k) = nM1;
%             M2TAMs(1,k) = nM2;
% 
%             %Stroma cells
%             %%%%%Number of stroma cells
%             stromaCells(1,k) = length(indStroma);
% 
%             %TMZ
%             TMZdensity = MCDS.continuum_variables(type_TMZ).data;
%             x = MCDS.discrete_cells.state.position(:,1);
%             indAlive = setdiff([1:size(x,1)],indDead);
%             x = x(indAlive);
%             y = MCDS.discrete_cells.state.position(indAlive,2);
%             tumourRegionRadius = max(sqrt(x.^2+y.^2));
%             W = ceil(2*tumourRegionRadius./20);
%             T = size(TMZdensity,1);
%             if(mod((T-W),2)==1) 
%                 W = W+1;
%             end
%             %%%%%Get TMZ density in tumour region
%             try
%                 TMZdensity = TMZdensity((((T-W)/2)+1):(T-((T-W)/2)),(((T-W)/2)+1):(T-((T-W)/2)));
%             catch
%                 TMZdensity = TMZdensity;
%             end
%             TMZ(1,k) = mean(TMZdensity,"all");
% 
%             %%%%%Save (x,y) positions of cells, their ID and their type
%             cellID = MCDS.discrete_cells.custom.cell_id;
%             cellID = cellID';
%             types = zeros(length(cellID),1);
%             types(indCD8,1) = 1;
%             types(indTumour,1) = 2;
%             types(indStroma,1) = 3;
%             types(indTAMs,1) = 4;
%             types(indM1TAMs,1) = 5;
%             types(indM2TAMs,1) = 6;
%             pos_x = MCDS.discrete_cells.state.position(:,1);
%             pos_y = MCDS.discrete_cells.state.position(:,2);
%             pos = [cellID,pos_x,pos_y,types];
%             positions(k).pos = pos;
%         else
%             %break out of for loop
%             k=nOutput+1;
%             cancerCellsKilledByCd8_cumulative(1,end) = [];
%             cancerCellsKilledByCd8_discrete(1,end) = [];
%         end
%     end
% 
%     %save data
%     cd(outputMatlabFolder)
% 
%     % switch patientNumber
%     %     case 0
%     %         px = 'patient42_homogeneous_';
%     %     case 1
%     %         px = 'patient42_heterogeneous_';
%     %     otherwise
%     %         px = 'Other';
%     % end
% 
%     px = patients(patientNumber+1);
%     tx = treatments(treatmentNumber+1);
% 
%     % switch treatmentNumber
%     %     case 0
%     %         tx = 'None';
%     %     case 1
%     %         tx = 'TMZ';
%     %     otherwise
%     %         tx = 'Other';
%     % end
% 
%     patient_output_folder = strcat(outputMatlabFolder,'/',px,'/',tx,'/rep',num2str(replicateNumber));
%     mkdir(patient_output_folder)
%     cd(patient_output_folder)
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_cancerCellsKilledByCd8_cumulative','.mat'),'cancerCellsKilledByCd8_cumulative');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_cancerCellsKilledByCd8_discrete','.mat'),'cancerCellsKilledByCd8_discrete');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_CD8cells','.mat'),'CD8cells');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_attachedCD8cells','.mat'),'attachedCD8cells');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_ki67pos','.mat'),'ki67pos');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_activation_levels','.mat'),'activation_levels');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_tumourCells','.mat'),'tumourCells');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_prolifRates','.mat'),'prolifRates');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_baselineProlifRates','.mat'),'baselineProlifRates');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_apoptosisRates','.mat'),'apoptosisRates');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_residentTAMs','.mat'),'residentTAMs');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_M1TAMs','.mat'),'M1TAMs');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_M2TAMs','.mat'),'M2TAMs');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_allActivatedTAMs','.mat'),'allActivatedTAMs');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_TMZ','.mat'),'TMZ');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_positions','.mat'),'positions');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_netprolifRates','.mat'),'netprolifRates');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_attachedtumourCells','.mat'),'attachedtumourCells');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_local_density_tumour','.mat'),'local_density_tumour');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_proliferative_cells','.mat'),'proliferative_cells');
%     save(strcat(px,tx,'_rep',num2str(replicateNumber),'_stroma_cells','.mat'),'stromaCells');
% 
%     disp('All structures saved.')
% 
%     cd(matlab_folder)
% 
% catch
% 
%     disp('There was a problem!')
% end

