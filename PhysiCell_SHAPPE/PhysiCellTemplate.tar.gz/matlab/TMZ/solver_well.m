function sol = solver_well(p)

sol = ode15s(@fullmodel,p.tspan,p.initialcondition);

function dydt = fullmodel(t,y)

   drug = y(1);
   cells = y(2);
   if(drug<0)
       drug = 0;
   end
   ddrug =  -p.kel*drug;
   dcells = p.beta.*cells-cells.*p.Emax.*(drug.^p.h)./((drug.^p.h)+(p.IC50.^p.h));

   dydt = [ddrug;dcells];

end

end