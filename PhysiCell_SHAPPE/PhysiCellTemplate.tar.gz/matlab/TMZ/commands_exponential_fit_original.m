% fitting exponential growth

%% Load and prepare data for fitter

%load data.mat %use this to load presaved data (instead of manually
%creating vectors for time and data, as below


time = [0 1 2 3 4 5 6 7 8 9]; %time data
data = [10 14 22 32 50 70 101 152 225 330]; %cell count data

%% Initial parameter values
C0 = data(1); %initial number of cells
r_guess = 0.02;

%% Call fitter
[param_fit] = fit_exponential_growth_original(time,data,C0,r_guess); %fitting exponential curve to data

r = param_fit;
t = linspace(time(1),time(end),100);
C = C0.*exp(r.*t);

%% Plot results

figure
hold on 
plot(t,C,'LineWidth',2)
plot(time,data,'o:','LineWidth',1)
xlabel('Time')
ylabel('Cells')



    