%%
close all
clearvars

%% colors

%%%%% Shades - 1st row = lightest, last row = darkest
dark_reds = [hex2rgb('#D1B9BC');
    hex2rgb('#AE858A');
    hex2rgb('#8B5058');
    hex2rgb('#6F4046');
    hex2rgb('#533035')];
dark_blues = [hex2rgb('#BABDCA');
    hex2rgb('#868CA2');
    hex2rgb('#525B7A');
    hex2rgb('#424962');
    hex2rgb('#313749')];
oranges = [hex2rgb('#F6D7C7');
    hex2rgb('#F0B99E');
    hex2rgb('#EC9F79');
    hex2rgb('#BA7C5D');
    hex2rgb('#8C5D46')];
purples = [hex2rgb('#DCCDDA');
    hex2rgb('#C1A7BE');
    hex2rgb('#A781A2');
    hex2rgb('#866782');
    hex2rgb('#644D61')];
light_blues = [hex2rgb('#D9E7EB');
    hex2rgb('#BCD4DB');
    hex2rgb('#9FC2CC');
    hex2rgb('#7F9BA3');
    hex2rgb('#5F747A')];
pinks = [hex2rgb('#F0C5BF');
    hex2rgb('#E59A8E');
    hex2rgb('#D17466');
    hex2rgb('#AE594B');
    hex2rgb('#834338')]; 

%%%%% Categorical colors
dark_red = dark_reds(3,:);
dark_blue = dark_blues(3,:);
orange = oranges(3,:);
purple = purples(3,:);
light_blue = light_blues(3,:);
pink = pinks(3,:);
gray = hex2rgb('#C9C3C1');
accent_yellow = hex2rgb('#FCC737');

%%%%% Categorical Sequential Colorscales (1st row: darkest, last row: lightest)
sequential_colorful = [hex2rgb('#05172C');
    hex2rgb('#0E2C49');
    hex2rgb('#224163');
    hex2rgb('#455779');
    hex2rgb('#5B5C78');
    hex2rgb('#715F74');
    hex2rgb('#88616E');
    hex2rgb('#A06268');
    hex2rgb('#BB6461');
    hex2rgb('#D57262');
    hex2rgb('#E58165');
    hex2rgb('#E79A75');
    hex2rgb('#E8B087');
    hex2rgb('#EDD1AA');
    hex2rgb('#FCF2D5')];

sequential_cool = [hex2rgb('#08090c');
    hex2rgb('#17191f');
    hex2rgb('#222630');
    hex2rgb('#2e3343');
    hex2rgb('#3a4156');
    hex2rgb('#474f6a');
    hex2rgb('#555e7d');
    hex2rgb('#616f8a');
    hex2rgb('#6f8098');
    hex2rgb('#7d91a5');
    hex2rgb('#8ca2b3');
    hex2rgb('#9db3c1');
    hex2rgb('#aec5cf');
    hex2rgb('#c2d6dd');
    hex2rgb('#d9e7eb')];

sequential_warm = [hex2rgb('#211415');
    hex2rgb('#311e1f');
    hex2rgb('#422829');
    hex2rgb('#543234');
    hex2rgb('#663d3e');
    hex2rgb('#7a4848');
    hex2rgb('#8e5352');
    hex2rgb('#a25e5c');
    hex2rgb('#b86a64');
    hex2rgb('#ce756b');
    hex2rgb('#e08475');
    hex2rgb('#e6988c');
    hex2rgb('#ecaca2');
    hex2rgb('#f0c0b9');
    hex2rgb('#f4d4cf')];

%%%%% Categorical Diverging Colorscales (1-7: blues/purples, 9-15: reds/oranges)
diverging_black = [hex2rgb('#d9e7eb');
    hex2rgb('#aec5cf');
    hex2rgb('#8ca2b3');
    hex2rgb('#6f8098');
    hex2rgb('#555e7d');
    hex2rgb('#3a4156');
    hex2rgb('#222630');
    hex2rgb('#08090c');
    hex2rgb('#441917');
    hex2rgb('#6e2e29');
    hex2rgb('#964940');
    hex2rgb('#bd675b');
    hex2rgb('#de8a7d');
    hex2rgb('#efb5ac');
    hex2rgb('#ffdfda')];

diverging_white = [hex2rgb('#292f40');
    hex2rgb('#3e475d');
    hex2rgb('#556177');
    hex2rgb('#6d7d91');
    hex2rgb('#8699ab');
    hex2rgb('#a1b7c4');
    hex2rgb('#c0d5dd');
    hex2rgb('#f6ebe3');
    hex2rgb('#eec6bd');
    hex2rgb('#dda49a');
    hex2rgb('#c6857a');
    hex2rgb('#ab675e');
    hex2rgb('#8f4c45');
    hex2rgb('#72332e');
    hex2rgb('#551b19')];

diverging_other = [hex2rgb('#6c4e65');
    hex2rgb('#81627b');
    hex2rgb('#997792');
    hex2rgb('#b08da7');
    hex2rgb('#c7a4bb');
    hex2rgb('#ddbccc');
    hex2rgb('#f0d7d8');
    hex2rgb('#fdf5da');
    hex2rgb('#f7d7ba');
    hex2rgb('#edba9c');
    hex2rgb('#dd9f81');
    hex2rgb('#c9866a');
    hex2rgb('#b36e57');
    hex2rgb('#9b5847');
    hex2rgb('#834338')];

%%%%% Continuous Colorscales (1-127: blues/purples [diverging] or darkest [sequential],
% 129-255: reds/oranges [diverging] or lighest [sequential])
load_colorscales;

%Figure constants
plot_linewidth = 1.2;
axis_linewidth = 0.5;
axis_fontname = 'Tahoma';
legend_fontsize = 8;
axis_fontsize = 9;
box_color = '#3B3B3B';
marker_size = 3;

%% Get folders
folder_codeTMZ = pwd;
folder_matlab = fileparts(pwd);
folder_physicell = fileparts(folder_matlab);
folder_cellCSV = fullfile(folder_physicell,'patientsCSV/');
folder_cellplacementcode = fullfile(folder_matlab,"cellPlacementCode/");
folder_finaloutput = fullfile(fileparts(folder_physicell),'finalOutput/');
folder_figures = fullfile(fileparts(folder_physicell),'figures','TMZPKPD');
folder_main = fileparts(folder_physicell);
folder_ode = fullfile(folder_main,'Code','ODEmodel');

%% Constants
um_to_cm = 10.^(-4);
um_to_mm = 10.^(-3);
GBMradius = 10.75; % um

%% Generate a configuration to replicate cell viability assays from Lo Dico et al.
celldensity = 10000; % cells/cm2
fraction_area_cell = (celldensity.*pi.*(GBMradius.*um_to_cm).^2)./1; % unit-less
abmArea = (1/um_to_cm)*(1/um_to_cm); % um2
Ncells = celldensity.*(um_to_cm.^2).*abmArea;


% for nconfig=2:5
%     cd(folder_cellplacementcode)
%     [cellViabilityAssayConfiguration, augmentedRadius] = randomConfigurationGenerator(Ncells,1,fraction_area_cell,10.75,'square');
%     cd(folder_codeTMZ)
% 
%     figure
%     scatter(cellViabilityAssayConfiguration(:,1),cellViabilityAssayConfiguration(:,2),10,'filled')
%     xlim([-(1/um_to_cm)/2 (1/um_to_cm)/2])
%     ylim([-(1/um_to_cm)/2 (1/um_to_cm)/2])
% 
%     cellViabilityAssayConfiguration(:,end) = 2;
% 
%     filename = "cellViabilityAssayInitialisation_config"+num2str(nconfig)+".csv";
%     % writematrix(cellViabilityAssayConfiguration,fullfile(folder_cellCSV,filename))
% end

%% TMZ Cell viability from Lo Dico et al.

load("lodicoDataTransformed.mat");
C = exp(lodicoDataTransformed(:,1));%lodicoDataTransformed(:,1) was the natural logarithm of the concentrations
effect = lodicoDataTransformed(:,2);

folder_LoDicoData = fullfile(pwd,"LoDicoCI");
nData = 25;
effectReplicates = zeros(size(effect,1),nData);
for k=1:nData
    datafile = fullfile(folder_LoDicoData,"LoDico2018_data_curve"+num2str(k)+".csv");
    data = readmatrix(datafile,'NumHeaderLines',1,'DecimalSeparator', ',');
    effectReplicates(:,k) = 100-data(:,2);
end

%% Get concentrations of TMZ every 10 minutes for 72hours (72 hours = 4320 min)
figure
hold on
for nc=1:size(C,1)
    p.concentration = C(nc);%0.0019;%initial drug concentration (single admin)
    
    p.halflife = 30; % TMZ Half life (min)
    p.kel = log(2)./p.halflife;%drug elimination rate
    
    p.initialcondition = [p.concentration];%set initial conditions
    p.tspan = [0 4320];%set timespan for simulations
    
    %Call ODE solver function
    sol = solver_exponentialTMZ(p);
    time = linspace(0,4320,(4320/10)+1);
    TMZ = deval(sol,time);
    
    % figure
    plot(time,TMZ)
    filename = "TMZCellViability_"+num2str(nc)+".bin";
    fileID = fopen(filename,'w');
    fwrite(fileID,TMZ,'double');
end

%% Get ODE predictions in well

p.concentration = 0.0019;%initial drug concentration (single admin)
p.G0 = 10000;
p.halflife = 30; % TMZ Half life (min)
p.kel = log(2)./p.halflife;%drug elimination rate
p.Emax = 0.7/(60);
p.IC50 = 0.0011;
p.h = 0.5682;
p.beta = log(2)/(28*60);

p.initialcondition = [p.concentration p.G0];%set initial conditions
p.tspan = [0 4320];%set timespan for simulations

%Call ODE solver function
sol = solver_well(p);
time = linspace(0,4320,(4320/10)+1);
TMZ = deval(sol,time,1);
G = deval(sol,time,2);

p.initialcondition = [0 p.G0];%set initial conditions
p.tspan = [0 4320];%set timespan for simulations

%Call ODE solver function
sol = solver_well(p);
time = linspace(0,4320,(4320/10)+1);
TMZ_noTreatment = deval(sol,time,1);
G_noTreatment = deval(sol,time,2);

fig = figure;
tiledlayout(1,3)
nexttile
hold on
plot(time./(60.*24),TMZ,'LineWidth',1.5)
plot(time./(60.*24),TMZ_noTreatment,'LineWidth',1.5)
legend(["Treated","Control"])
title("TMZ")

nexttile
hold on
plot(time./(60.*24),G./G(1),'LineWidth',1.5)
plot(time./(60.*24),G_noTreatment./G_noTreatment(1),'LineWidth',1.5)
legend(["Treated","Control"])
title("Cancer cells")

nexttile
hold on
plot(time./(60.*24),100.*G./G_noTreatment,'LineWidth',1.5)
title("Cell Viability")


%% Cell viability after three days vs maximal daily effect

configurations = ["cellViabilityAssayInitialisation_config1","cellViabilityAssayInitialisation_config2",...
    "cellViabilityAssayInitialisation_config3","cellViabilityAssayInitialisation_config4","cellViabilityAssayInitialisation_config5"];
nReplicates = 6;
nConfigurations = 5;
tumourCellCounts = nan.*ones(nReplicates*nConfigurations,11);

for k=1:11
    if(k==1)
        treatment = "TMZ";
        treatmentFile = "Control";
    else
        treatment = "TMZ";
        TMZefficacy = "TMZefficacy"+num2str((k-1).*10);
        treatmentFile = treatment+"/"+TMZefficacy;
    end
    % Loop through configurations
    for i=1:nConfigurations
        % Loop through replicates
        for j=0:(nReplicates-1)
            idx = (i-1)*nReplicates+j+1;
            % Retrieve tumour cell file
            px = "cellViabilityAssayInitialisation_config"+num2str(i);
            tumourCellFilename = strcat(px,treatment,'_rep',num2str(j),'_tumourCells','.mat');
            tumourCellFilenamePath = fullfile(folder_finaloutput,px,treatmentFile,"/rep"+num2str(j),tumourCellFilename);
            if(isfile(tumourCellFilenamePath))
                load(tumourCellFilenamePath)
                if(tumourCells(end)>0)
                    tumourCellCounts(idx,k) = tumourCells(end);
                else
                    disp("You need to rerun replicate "+num2str(j)+" for configuration "+num2str(i)+"."+newline)
                end
            end
        end
    end
end

avgCellcounts = mean(tumourCellCounts,1,'omitnan');
stdCellcounts = std(tumourCellCounts,1,'omitnan');
cellViability = avgCellcounts./avgCellcounts(1);
stdCellViability = zeros(size(cellViability));
mu2 = avgCellcounts(1);
sigma2 = stdCellcounts(1);
for i=2:size(cellViability,2)
    mu1 = avgCellcounts(i);
    sigma1 = stdCellcounts(i);
    sigmaCV = (mu1./mu2).*sqrt((sigma1./mu1).^2+(sigma2./mu2).^2);%sqrt((sigma1./mu2).^2+((mu1.*sigma2)./(mu2.^2)).^2);
    stdCellViability(1,i) = sigmaCV;
end

efficacy = [0:10]./10;
figure
% plot(efficacy,cellViability,'Marker','o','MarkerFaceColor','blue')
errorbar(efficacy,cellViability,stdCellViability,'Marker','o','MarkerFaceColor','blue')
xlim([efficacy(1) efficacy(end)])

%% Fit exponential curve

C0 = 1;
r0 = 1.1;
r = fit_exponential_curve(efficacy(2:end),cellViability(2:end),C0,r0);
CVexp = C0.*exp(-r.*efficacy);

a0 = 2;
a = fit_linear_curve(efficacy(2:end),cellViability(2:end),C0,a0);
CVlin = -a.*efficacy+C0;

w_cm = 5.33; % Width in centimeters
h_cm = 4.55; % Height in centimeters
w_in = w_cm / 2.54;
h_in = h_cm / 2.54;
fig1 = figure;
hold on
set(fig1, 'Units', 'inches','Position', [1 1 w_in h_in]);
errorbar(efficacy,cellViability,stdCellViability,'Marker','o','MarkerSize',marker_size,...
    'MarkerFaceColor',dark_blue,'Color',dark_blue,'LineWidth',0.75.*plot_linewidth,'LineStyle','none')
plot(efficacy,CVexp,'Color',orange,'LineWidth',plot_linewidth)
plot(efficacy,CVlin,'Color',purple,'LineWidth',plot_linewidth)
xlim([efficacy(1) efficacy(end)])
xlabel('Maximal hourly TMZ efficacy')
ylabel('Cell viability after 72 hours')
lgd = legend(["ABM Data","Exponential fit","Linear fit"],'Location','best',...
    'Box','off','FontSize',legend_fontsize,'FontName',axis_fontname);
lgd.AutoUpdate = 'off'; 
lgd.IconColumnWidth = 10;
adjustFigure(fig1,axis_fontsize,axis_linewidth,axis_fontname,box_color,w_in,h_in)
figureFile = fullfile(folder_figures,"CVvsEfficacyFits.pdf");
print(fig1,'-dpdf','-r600',figureFile)

%% Dose Response Curve

configurations = ["cellViabilityAssayInitialisation_config1","cellViabilityAssayInitialisation_config2",...
    "cellViabilityAssayInitialisation_config3","cellViabilityAssayInitialisation_config4","cellViabilityAssayInitialisation_config5"];
nReplicates = 1;
nConfigurations = 5;
tumourCellCountsDoseResponse = nan.*ones(nReplicates*nConfigurations,8);

for k=1:8
    treatment = "TMZ";
    Dose = "Dose"+num2str(k);
    treatmentFile = treatment+"/"+Dose;
    % Loop through configurations
    for i=1:nConfigurations
        % Loop through replicates
        for j=0:(nReplicates-1)
            idx = (i-1)*nReplicates+j+1;
            % Retrieve tumour cell file
            px = "cellViabilityAssayInitialisation_config"+num2str(i);
            tumourCellFilename = strcat(px,treatment,'_rep',num2str(j),'_tumourCells','.mat');
            tumourCellFilenamePath = fullfile(folder_finaloutput,px,treatmentFile,"/rep"+num2str(j),tumourCellFilename);
            if(isfile(tumourCellFilenamePath))
                load(tumourCellFilenamePath)
                tumourCellCountsDoseResponse(idx,k) = tumourCells(end);
            end
        end
    end
end

control = tumourCellCounts(:,1);
avgCellcountsDR = mean(tumourCellCountsDoseResponse,1,'omitnan');
stdCellcountsDR = std(tumourCellCountsDoseResponse,1,'omitnan');
cellViabilityDR = avgCellcountsDR./mean(control,'omitnan');
stdCellViabilityDR = zeros(size(cellViabilityDR));
mu2 = mean(control,'omitnan');
sigma2 = std(control,'omitnan');
for i=1:size(cellViabilityDR,2)
    mu1 = avgCellcountsDR(i);
    sigma1 = stdCellcountsDR(i);
    sigmaCV = (mu1./mu2).*sqrt((sigma1./mu1).^2+(sigma2./mu2).^2);%sqrt((sigma1./mu2).^2+((mu1.*sigma2)./(mu2.^2)).^2);
    stdCellViabilityDR(1,i) = sigmaCV;
end

concentrations = C; % From Lo Dico et al.
w_cm = 5.33; % Width in centimeters
h_cm = 4.55; % Height in centimeters
w_in = w_cm / 2.54;
h_in = h_cm / 2.54;
fig = figure;
hold on
set(fig, 'Units', 'inches','Position', [1 1 w_in h_in]);
hold on
errorbar(concentrations,100.*cellViabilityDR,stdCellViabilityDR,'Marker','o','MarkerSize',marker_size,...
    'MarkerFaceColor',dark_blue,'Color',dark_blue,'LineWidth',0.75.*plot_linewidth)
errorbar(concentrations,mean(100-effectReplicates,2,'omitnan'),std(100-effectReplicates,0,2,'omitnan'),'Marker','o','MarkerSize',marker_size,...
    'MarkerFaceColor',orange,'MarkerEdgeColor',orange,'Color',orange,'LineStyle','none','LineWidth',0.75.*plot_linewidth)
% plot(C,100-effect,'Marker','o','MarkerFaceColor',orange,'MarkerEdgeColor',orange,...
%     'MarkerSize',marker_size,'LineStyle','none')
xlabel('Dose (mg/ml)','FontSize',axis_fontsize,'FontName',axis_fontname)
xscale('log')
ylim([0 100])
ylabel('Cell Viability (%)','FontSize',axis_fontsize,'FontName',axis_fontname)
lgd = legend(["ABM Data","Experimental Data"],'Location','best',...
    'Box','off','FontSize',legend_fontsize,'FontName',axis_fontname);
lgd.AutoUpdate = 'off'; 
lgd.IconColumnWidth = 10;
adjustFigure(fig,axis_fontsize,axis_linewidth,axis_fontname,box_color,w_in,h_in)
figureFile = fullfile(folder_figures,"DoseResponseCurveABM.pdf");
print(fig,'-dpdf','-r600',figureFile)

%% Get concentrations every 10 minutes for final model

cd(folder_ode)
    clear p;
    set_patients;
    set_treatment;

    p.initialcondition = [p.T0,p.G0,p.M00,p.M10,p.M20,p.Dd0,p.A10,p.A20,p.A30];
    p.tspan = [0 10080];%set timespan for simulations
    timeTMZ = 0:10:p.tspan(end);
    [sol,~] = solver_ode(p);
    A3 = deval(sol,timeTMZ,9);
    TMZ = A3./p.Vp;
    
    % figure
    plot(timeTMZ,TMZ)
    % filename = "TMZCellViability_"+num2str(nc)+".bin";
    % fileID = fopen(filename,'w');
    % fwrite(fileID,TMZ,'double');

cd(folder_codeTMZ)