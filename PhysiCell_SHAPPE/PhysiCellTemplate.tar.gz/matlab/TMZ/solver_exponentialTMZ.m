function sol = solver_exponentialTMZ(p)

sol = ode15s(@fullmodel,p.tspan,p.initialcondition);

function dydt = fullmodel(t,y)

   drug = y(1);
   
   ddrug=  -p.kel*drug;

   dydt = [ddrug];

end

end