function [param_fit] = fit_linear_curve(time,data,C0,parameter_guess) %fitting exponential curve to data

options = optimoptions(@lsqnonlin,'Algorithm', 'trust-region-reflective','MaxFunEval',5000,'display','iter');%load options for solved

r_lb = 0;%lower bound for parameter value being fit
r_ub = Inf;%upper bound for parameter value being fit
[param_fit,resnorm,residual,exitflag,output,lambda,jacobian] = lsqnonlin(@residualsfunction, parameter_guess, r_lb, r_ub, options);  % can use fmincon

a = param_fit;

%------------------------------------------------------------------------
function val = residualsfunction(param)

    a = param;
    
    val = (-a*time+C0)-data; %difference between the model at the sampled time points AND the data

    %in fmincon val will be squared sum of this vector as opposed to a
    %vector of values
    
end
%------------------------------------------------------------------------
end