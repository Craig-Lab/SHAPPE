clearvars
close all

%% Read output file
CCfolder = '/Users/morgancraig/Documents/GBMs/ProjectABMODE/PhysiCell_TargetingTAMs/matlab/carryingCapacityDensity';
MCDS = read_MultiCellDS_xml('output00000001.xml',CCfolder);

%% Analyse

type_CD8 = 1;
type_GBM = 2;
type_Stroma = 3;
type_TAM = 4;

indDead = MCDS.discrete_cells.dead_cells;
indCD8 = setdiff(find(MCDS.discrete_cells.metadata.type==type_CD8),indDead);
indTumour = setdiff(find(MCDS.discrete_cells.metadata.type==type_GBM),indDead);
indTAMs = setdiff(find(MCDS.discrete_cells.metadata.type==type_TAM),indDead);
indStroma = setdiff(find(MCDS.discrete_cells.metadata.type==type_Stroma),indDead);

lc_density = MCDS.discrete_cells.custom.neighborhood_density(indTumour);
