
matlab_folder = cd('..');
%You're now in PhysiCelln folder
outputInformation = readmatrix('outputInformation.csv');
patientNumber = outputInformation(end,1);
treatmentNumber = outputInformation(end,2);
replicateNumber = outputInformation(end,3);
listNumber = outputInformation(end,4);


%You're now in PhysiCellTargetingTAMs folder
patients = ["cellViabilityAssayInitialisation_config1","cellViabilityAssayInitialisation_config2",...
    "cellViabilityAssayInitialisation_config3","cellViabilityAssayInitialisation_config4","cellViabilityAssayInitialisation_config5"];

%cd(current_PhysiCellFolder)
%You're now in PhysiCelln folder

treatments = ["TMZ"];
TMZefficacy = "Dose"+num2str(listNumber);

main_folder = cd('outputMatlab/');
outputMatlabFolder = cd('../output/');%
% cellsCreated = readmatrix('cellcounts.csv');
% deadCells = readmatrix('deadcells.csv');
% persistence_times_go = readmatrix('pers_time_go.csv');
% persistence_times_stop = readmatrix('pers_time_stop.csv');
% tam_regions_m2m1ratio = readmatrix('tam_regions_m2m1ratio.csv');
results_folder = cd(matlab_folder);

%constants
time_start = 0;
time_end = 4320;%
time_interval = 120;
nOutput = floor(1+(time_end-time_start)./time_interval);
time = [0:nOutput-1].*(time_interval/60);

type_GBM = 2;

%Cancer cells
tumourCells = zeros(1,nOutput);
prolifRates = zeros(1,nOutput);
netprolifRates = zeros(1,nOutput);
baselineProlifRates = zeros(1,nOutput);
apoptosisRates = zeros(1,nOutput);

%read data
Ncpu = 7;
validIndexes = zeros(1,nOutput);
parfor(k=1:nOutput,Ncpu)
    output_number = strcat('00000000',num2str(k-1));
    output_number = output_number(length(output_number)-8+1:end);
    filename = strcat('output',output_number,'_cells.mat');
    full_file_path = strcat(results_folder,'/',filename);
    file_exists = isfile(full_file_path);
    if(file_exists)
        %MCDS = read_MultiCellDS_xml(filename,results_folder);
        current_cells = load(strcat(results_folder,'/',filename));
        cells = current_cells.cells;
        indDead = unique([find(cells(7,:)==100),find(cells(194,:)==1)]);
        
        indTumour = setdiff(find(cells(6,:)==type_GBM),indDead);       
        %Tumour cells
        %%%%%find indexes of dead tumour cells
        indDeadTumourCells = find(cells(194,:)==1);
        indTumour = setdiff(indTumour,indDeadTumourCells);
        %%%%%number of tumour cells alive
        tumourCells(1,k) = length(indTumour);
        %%%%%Baseline proliferation rates
        baselineProlif = cells(185,indTumour);
        %%%%%Actual proliferation rates
        proliferation = cells(183,indTumour);
        prolifRates(1,k) = mean(proliferation);
        baselineProlifRates(1,k) = mean(baselineProlif);
        %%%%%TMZ-induced apoptosis rate
        apoptosis = cells(197,indTumour);
        apoptosisRates(1,k) = mean(apoptosis);
        %%%%%Net proliferation rate
        net_prolif = cells(184,indTumour);
        netprolifRates(1,k) = mean(net_prolif);
    else
        %break out of for loop
        validIndexes(1,k) = 1;
    end
end

stopIndex = find(validIndexes(1,:)==1,1,'first');

%save data
cd(outputMatlabFolder)

px = patients(patientNumber+1);
tx = treatments(treatmentNumber+1);
patient_output_folder = strcat(outputMatlabFolder,'/',px,'/',tx,'/',TMZefficacy,'/rep',num2str(replicateNumber));
mkdir(patient_output_folder)
cd(patient_output_folder)
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_tumourCells','.mat'),'tumourCells');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_prolifRates','.mat'),'prolifRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_baselineProlifRates','.mat'),'baselineProlifRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_apoptosisRates','.mat'),'apoptosisRates');
save(strcat(px,tx,'_rep',num2str(replicateNumber),'_netprolifRates','.mat'),'netprolifRates');

disp('All structures saved.')

cd(matlab_folder)