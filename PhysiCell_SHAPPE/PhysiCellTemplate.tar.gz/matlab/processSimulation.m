function processSimulation(pxName,treatment,repNumber,PhysicellOutputFolder,ProcessedOutputFolder)

    DataIndexes = set_data_indexes;

    warning('off','all')

    patientOutputDirectory = fullfile(ProcessedOutputFolder,pxName,treatment,"Rep"+string(repNumber));
    if(~isfolder(patientOutputDirectory))
        mkdir(patientOutputDirectory)
    end

    deadCells = readmatrix(fullfile(PhysicellOutputFolder,'deadcells.csv'));
    persistence_times_go = readmatrix(fullfile(PhysicellOutputFolder,'pers_time_go.csv'));
    persistence_times_stop = readmatrix(fullfile(PhysicellOutputFolder,'pers_time_stop.csv'));
    tam_regions_m2m1ratio = readmatrix(fullfile(PhysicellOutputFolder,'tam_regions_m2m1ratio.csv'));
    tumourRadius = readmatrix(fullfile(PhysicellOutputFolder,'tumourRadius.csv'));
    
    type_CD8 = 1;
    type_GBM = 2;
    type_Stroma = 3;
    type_TAM = 4;
    
    %CD8 cytotoxicity
    cancerCellsKilledByCd8_cumulative = deadCells(:,3)';
    cancerCellsKilledByCd8_discrete = cancerCellsKilledByCd8_cumulative;
    for nT=2:size(cancerCellsKilledByCd8_cumulative,2)
        cancerCellsKilledByCd8_discrete(1,nT) = cancerCellsKilledByCd8_cumulative(1,nT)-cancerCellsKilledByCd8_cumulative(1,nT-1);
    end
    
    % Average M2:M1 ratio in specific regions
    M2frequency_tamRegions = mean(tam_regions_m2m1ratio,2,'omitnan')';
    % Number of TAM regions without any TAMs
    number_regions_without_tams = sum(isnan(tam_regions_m2m1ratio),2);
    % Number of TAM regions with a M1 frequency higher than average 
    number_regions_higher_M1_frequency = zeros(length(M2frequency_tamRegions),1);
    for nt=1:size(tam_regions_m2m1ratio,1)
        temp = tam_regions_m2m1ratio(nt,:);
        number_regions_higher_M1_frequency(nt,1) = length(find(temp<M2frequency_tamRegions(nt)))./(length(temp)-sum(isnan(temp)));
    end
    
    nOutput = length(cancerCellsKilledByCd8_discrete);
    
    % CD8+ T cells
    CD8cells = zeros(1,nOutput);
    attachedCD8cells = zeros(1,nOutput);
    activation_levels = zeros(1,nOutput);
    
    % Cancer cells
    tumourCells = zeros(1,nOutput);
    prolifRates = zeros(1,nOutput);
    netprolifRates = zeros(1,nOutput);
    baselineProlifRates = zeros(1,nOutput);
    apoptosisRates = zeros(1,nOutput);
    attachedtumourCells = zeros(1,nOutput);
    local_density_tumour = zeros(1,nOutput);
    proliferative_cells = zeros(1,nOutput);
    
    % TAMs
    residentTAMs = zeros(1,nOutput);
    M1TAMs = zeros(1,nOutput);
    M2TAMs = zeros(1,nOutput);
    allActivatedTAMs = zeros(1,nOutput);
    
    % Stroma Cell
    stromaCells = zeros(1,nOutput);
    
    % General
    deadcellscounts = zeros(1,nOutput);
    
    positions_size = nOutput;  %number of elements
    positions(positions_size) = struct();
        
    % Read data
    Ncpu = 12;
    validIndexes = ones(1,nOutput);
    parfor(k=1:nOutput,Ncpu)
        output_number = strcat('00000000',num2str(k-1));
        output_number = output_number(length(output_number)-8+1:end);
        filename = strcat('output',output_number,'_cells.mat');
        full_file_path = fullfile(PhysicellOutputFolder,filename);
        file_exists = isfile(full_file_path);
        if(file_exists)
            current_cells = load(full_file_path);
            cells = current_cells.cells;
            
            indDead = unique([find(cells(DataIndexes.PhysicellData.dead_status,:)==1),...
                find(cells(DataIndexes.PhysicellData.cycle_model,:)==100),...
                find(cells(DataIndexes.CustomData.is_dead,:)==1)]);

            % Find indexes of cells of each cell type
            indCD8 = setdiff(find(cells(DataIndexes.PhysicellData.type,:)==type_CD8),indDead);
            indTumour = setdiff(find(cells(DataIndexes.PhysicellData.type,:)==type_GBM),indDead);
            indTAMs = setdiff(find(cells(DataIndexes.PhysicellData.type,:)==type_TAM),indDead);
            indStroma = setdiff(find(cells(DataIndexes.PhysicellData.type,:)==type_Stroma),indDead);

            % Save the number of dead tumour cells
            deadcellscounts(1,k) = length(intersect(find(cells(DataIndexes.PhysicellData.type,:)==type_GBM),indDead));
        
            % CD8+ T cell analysis
            %%%%% Number of CD8+ T cells
            CD8cells(1,k) = length(indCD8);
            %%%%% CD8+ T cells attached to a tumour cell
            indAttached = find(cells(DataIndexes.CustomData.is_attached,:)==1);
            indCD8Attached = intersect(indCD8,indAttached);
            attachedCD8cells(1,k) = length(indCD8Attached);
            %%%%% Activation levels
            activation_levels(1,k) = mean(cells(DataIndexes.CustomData.activation_level,indCD8));
            
            % Tumour cells analysis
            %%%%% Number of tumour cells alive
            tumourCells(1,k) = length(indTumour);
            %%%%% Number of tumour cells attached to a cd8+ t cell
            indAttachedTumourCells = intersect(indTumour,indAttached);
            attachedtumourCells(1,k) = length(indAttachedTumourCells);
            %%%%% Baseline proliferation rates
            baselineProlif = cells(DataIndexes.CustomData.baseline_proliferation_rate,indTumour);
            %%%%% Actual proliferation rates
            proliferation = cells(DataIndexes.CustomData.proliferation_rate,indTumour);
            prolifRates(1,k) = mean(proliferation);
            baselineProlifRates(1,k) = mean(baselineProlif);
            %%%%%TMZ-induced apoptosis rate
            apoptosis = cells(DataIndexes.CustomData.apoptosis_rate,indTumour);
            apoptosisRates(1,k) = mean(apoptosis);
            %%%%% Net proliferation rate
            net_prolif = cells(DataIndexes.CustomData.net_proliferation_rate,indTumour);
            netprolifRates(1,k) = mean(net_prolif);
            %%%%% Local density
            lc_density = cells(DataIndexes.CustomData.neighborhood_density,indTumour);
            local_density_tumour(1,k) = mean(lc_density);
            %%%%% Number of proliferative cancer cells
            num_proliferative = length(find(proliferation>0));
            proliferative_cells(1,k) = num_proliferative;
        
            % TAMs analysis
            TAMphenotype = cells(DataIndexes.CustomData.phenotype,indTAMs);
            indM1TAMs = intersect(find(cells(DataIndexes.CustomData.phenotype,:)==1),indTAMs);
            indM2TAMs = intersect(find(cells(DataIndexes.CustomData.phenotype,:)==2),indTAMs);
            nResident = length(find(TAMphenotype==0));
            nM1 = length(find(TAMphenotype==1));
            nM2 = length(find(TAMphenotype==2));
            allActivatedTAMs(1,k) = nM1+nM2;
            residentTAMs(1,k) = nResident;
            M1TAMs(1,k) = nM1;
            M2TAMs(1,k) = nM2;
        
            % Stroma cells analysis
            %%%%% Number of stroma cells
            stromaCells(1,k) = length(indStroma);
        
            %%%%% Save (x,y) positions of cells, their ID and their type
            cellID = cells(DataIndexes.CustomData.cell_ID,:);
            cellID = cellID';
            types = zeros(length(cellID),1);
            types(indCD8,1) = 1;
            types(indTumour,1) = 2;
            types(indStroma,1) = 3;
            types(indTAMs,1) = 4;
            types(indM1TAMs,1) = 5;
            types(indM2TAMs,1) = 6;
            pos_x = cells(DataIndexes.PhysicellData.position_x,:)';
            pos_y = cells(DataIndexes.PhysicellData.position_y,:)';
            pos = [cellID,pos_x,pos_y,types];
            % Remove dead cells
            pos(indDead,:) = [];
            positions(k).pos = pos;
        else
            % Break out of for loop
            validIndexes(1,k) = 0;
        end
    end
    
    stopIndex = find(validIndexes(1,:)==0,1,'first');
    if(isempty(stopIndex))
        lastValid = nOutput;
    else
        lastValid = stopIndex - 1;
    end
    cancerCellsKilledByCd8_cumulative = cancerCellsKilledByCd8_cumulative(1, 1:lastValid);
    cancerCellsKilledByCd8_discrete   = cancerCellsKilledByCd8_discrete(1, 1:lastValid);
    
    % Save data
    save(fullfile(patientOutputDirectory,"deadcellscounts.mat"),'deadcellscounts');
    save(fullfile(patientOutputDirectory,"cancerCellsKilledByCd8_cumulative.mat"),'cancerCellsKilledByCd8_cumulative');
    save(fullfile(patientOutputDirectory,"cancerCellsKilledByCd8_discrete.mat"),'cancerCellsKilledByCd8_discrete');
    save(fullfile(patientOutputDirectory,"CD8cells.mat"),'CD8cells');
    save(fullfile(patientOutputDirectory,"attachedCD8cells.mat"),'attachedCD8cells');
    save(fullfile(patientOutputDirectory,"activation_levels.mat"),'activation_levels');
    save(fullfile(patientOutputDirectory,"tumourCells.mat"),'tumourCells');
    save(fullfile(patientOutputDirectory,"prolifRates.mat"),'prolifRates');
    save(fullfile(patientOutputDirectory,"baselineProlifRates.mat"),'baselineProlifRates');
    save(fullfile(patientOutputDirectory,"apoptosisRates.mat"),'apoptosisRates');
    save(fullfile(patientOutputDirectory,"residentTAMs.mat"),'residentTAMs');
    save(fullfile(patientOutputDirectory,"M1TAMs.mat"),'M1TAMs');
    save(fullfile(patientOutputDirectory,"M2TAMs.mat"),'M2TAMs');
    save(fullfile(patientOutputDirectory,"allActivatedTAMs.mat"),'allActivatedTAMs');
    save(fullfile(patientOutputDirectory,"tam_regions_m2m1ratio.mat"),'tam_regions_m2m1ratio');
    save(fullfile(patientOutputDirectory,"M2frequency_tamRegions.mat"),'M2frequency_tamRegions');
    save(fullfile(patientOutputDirectory,"number_regions_without_tams.mat"),'number_regions_without_tams');
    save(fullfile(patientOutputDirectory,"number_regions_higher_M1_frequency.mat"),'number_regions_higher_M1_frequency');
    save(fullfile(patientOutputDirectory,"positions.mat"),'positions');
    save(fullfile(patientOutputDirectory,"netprolifRates.mat"),'netprolifRates');
    save(fullfile(patientOutputDirectory,"attachedtumourCells.mat"),'attachedtumourCells');
    save(fullfile(patientOutputDirectory,"local_density_tumour.mat"),'local_density_tumour');
    save(fullfile(patientOutputDirectory,"proliferative_cells.mat"),'proliferative_cells');
    save(fullfile(patientOutputDirectory,"stroma_cells.mat"),'stromaCells');
    save(fullfile(patientOutputDirectory,"persistence_times_go.mat"),'persistence_times_go')
    save(fullfile(patientOutputDirectory,"persistence_times_stop.mat"),'persistence_times_stop')
    save(fullfile(patientOutputDirectory,"tumourRadius.mat"),'tumourRadius')
    
    disp('All structures saved.')
    
end