#include "localRegions.h"
#include "./custom_GBM_TAM.h"
#include "./common.h"
#include "../modules/PhysiCell_settings.h"
#include <cmath>

localRegions::localRegions(double lbRadius, double ubRadius, double lbAngle, double ubAngle){
    innerRadius = lbRadius;
    outerRadius = ubRadius;
    minAngle = lbAngle;
    maxAngle = ubAngle;
    number_of_cells.assign(6,0);
    area = (M_PI*pow(outerRadius,2) - M_PI*pow(innerRadius,2)) * (maxAngle - minAngle) / (2*M_PI);
}

double localRegions::getArea() const {
    return area;
}

int localRegions::recruitCD8cells(double recruitmentRate) {
    int CD8recruited = eventMultipleoccurences(recruitmentRate);
    for(int i = 0 ; i < CD8recruited ; i++) {
        double r = sqrt(pow(innerRadius,2)+(pow(outerRadius,2)-pow(innerRadius,2))*UniformRandom());
        double theta = minAngle+UniformRandom()*(maxAngle-minAngle);
        double x = r*cos(theta);
        double y= r*sin(theta);
        Cell_Definition* pCD = find_cell_definition( 1 );
        Cell* pC = create_cell(*pCD);
        pC->assign_position(x,y,0);
        int target_distances_index = pC->custom_data.find_vector_variable_index( "target_distances" );
        std::vector<double> newTargetDistances = sampleTargetDistances(CD8_targetDistances_distributions);
        pC->custom_data.vector_variables[target_distances_index].value = newTargetDistances;
        cells.push_back(pC);
        number_of_cells[0] += 1;
    }
    return CD8recruited;
}

bool localRegions::is_in_region(Cell* pC) {
    double x = pC->position[0];
    double y = pC->position[1];
    double Rcell = sqrt(pow(x,2)+pow(y,2));
    bool is_inside = false;
    // Check the radius
    if(Rcell>=innerRadius && (Rcell<outerRadius || outerRadius==current_tumour_radius)) {
        //Check the angle
        double angle_pos= atan2(y,x);
        if(angle_pos<0) {
            angle_pos = angle_pos+2*M_PI;
        }
        if(angle_pos>=minAngle && (angle_pos<maxAngle || maxAngle==2*M_PI)) {
            is_inside = true;
        }
    }
    return is_inside;
}