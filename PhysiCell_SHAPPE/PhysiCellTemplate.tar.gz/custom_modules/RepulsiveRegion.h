#ifndef REPULSIVEREGION_H
#define REPULSIVEREGION_H

#include "../core/PhysiCell.h"
#include "../modules/PhysiCell_standard_modules.h"
#include <tuple>

using namespace PhysiCell;

class RepulsiveRegion {
private:
    double radius;
    double x_center;
    double y_center;
    double probAcceptance;
    double capacity;
    double area;

public:
    RepulsiveRegion(double x, double y, double r, double p, double c);
    RepulsiveRegion() = default;
    std::tuple<bool,double>  is_in_region(Cell* pC);


    bool check_for_acceptance(bool is_newborn, Cell* pCell);
    void repulseCell(Cell* pC);

    std::vector<Cell*> potentialOccupants;
    int  number_of_occupants;
};

#endif