#include "./localRegions.h"
#include "./RepulsiveRegion.h"

extern int numCellsCreated;
extern std::vector<int> cellcounts;
extern std::vector<int> deadcells;
extern double current_tumour_radius;
extern std::vector<double> attached_cells;
extern std::vector<int> pers_time_stop_all;
extern std::vector<int> pers_time_go_all;
extern bool plot_voxels;
extern double void_prob;
extern double void_average_CC;
extern double tumour_baseline_proliferation_rate;
extern double cd8_death_rate;
extern double local_regions_radius;
extern std::vector<std::vector<double>> cancer_targetDistances_distributions;
extern std::vector<std::vector<double>> M0_targetDistances_distributions;
extern std::vector<std::vector<double>> M1_targetDistances_distributions;
extern std::vector<std::vector<double>> M2_targetDistances_distributions;
extern std::vector<std::vector<double>> CD8_targetDistances_distributions;
extern std::vector<localRegions> TMELocalRegions;
extern std::vector<RepulsiveRegion> TMERepulsiveRegions;