/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "../core/PhysiCell.h"
#include "../modules/PhysiCell_standard_modules.h"
#include "./nanoflann.hpp"
#include <vector>
#include <map>
#include <memory>


using namespace BioFVM; 
using namespace PhysiCell;

struct CellCloud {
    std::vector<Cell*> cells;
    inline size_t kdtree_get_point_count() const { return cells.size(); }
    inline double kdtree_get_pt(const size_t idx, const size_t dim) const {
        return cells[idx]->position[dim];
    }
    template <class BBOX> bool kdtree_get_bbox(BBOX&) const { return false; }
};

typedef KDTreeSingleIndexAdaptor<
    L2_Simple_Adaptor<double, CellCloud>,
    CellCloud, 2> CellKDTree;

extern std::map<int, CellCloud> g_clouds;
extern std::map<int, std::unique_ptr<CellKDTree>> g_indices;


// setup functions to help us along 
void create_cancer_cells( void );
void create_CD8_cells( void );
void create_stroma_cells( void );
void create_TAMs( void );
void create_cell_types( void );

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// PHYSICELL ////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void phenotype_function( Cell* pCell, Phenotype& phenotype, double dt);
void custom_function( Cell* pCell, Phenotype& phenotype , double dt);
void contact_function( Cell* pMe, Phenotype& phenoMe , Cell* pOther, Phenotype& phenoOther , double dt ); 

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// TAMS ///////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void TAM_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, 
    std::vector<int>& private_deadcells, std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go);
void changePhenotypeVolumeFunction(Cell* pCell, int newP);
void TAMmovement(Cell* pCell);
void TAM_recruitement(double dt);

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// STROMA CELLS ///////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void stroma_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, 
    std::vector<int>& private_deadcells, std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go);
void stroma_recruitment(double innerRadius, double outerRadius);

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// CD8+ T CELLS ///////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void CD8_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, 
    std::vector<int>& private_deadcells, std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go);
void CD8_recruitement(double dt);
void CD8_check_for_attachment(Cell* pCell, std::vector<Cell*>& neighbors);
double CD8ProliferationRate(Cell* pCell, std::vector<Cell*>& neighbors);
void CD8movement(Cell* pCell) ;
float PD1PDL1(Cell* pCell, std::vector<Cell*>& neighbors);
void CD8_attempts_apoptosis(Cell* pCell, Cell* pCattached, double dt, std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts);
void induce_CD8_death(Cell* pCell, double dt,std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts);

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// CANCER CELLS ///////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void cancer_cell_rules( Cell* pCell, Phenotype& phenotype , double dt, std::vector<int>& private_cellcounts, 
    std::vector<int>& private_deadcells, std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go);
void dead_cancer_cell_update( Cell* pCell, Phenotype& phenotype , double dt, std::vector<int>& private_cellcounts, 
    std::vector<int>& private_deadcells, std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go);
int cancer_cell_assign_movement_type(Cell* pC);
double cancer_cell_assign_persistence_time(std::vector<double> cumul_prob,std::vector<double> times);
void TMZeffect(Cell* pC, double dt);
void cancer_cell_movementType_update( Cell* pCell, Phenotype& phenotype, double dt , 
    std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go );
void updateProliferationRate(Cell * pCell,double localCellDensity);
void updateNetProliferationRate(Cell* pCell);
std::vector<double> go_times_cumulative();
std::vector<double> stop_times_cumulative();
std::vector<double> persistance_distribution();
std::vector<double> speed_cumulative();
std::vector<double> speed_distribution();
int update_pers_time_structure(double time);

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////// GENERAL FUNCTIONS ////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
void setup_microenvironment( void ); 
void setup_tissue( void ); 
void killCell(Cell* pCell, double dt, std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts);
void assignLocalRegion(Cell* pCell, std::vector<localRegions>& allRegions);
double get_neighborhood_density( Cell* pCell);
std::vector<Cell*> get_neighbors( Cell* pCell);
void change_to_live_model(Cell* pCell, double prolif_rate);
void mark_cells_in_my_neighborhood(Cell* pCell);
double distance_between_cells(Cell* pC1, Cell* pC2) ;
int eventMultipleoccurences(double rate);
bool eventBinaryOccurence(double prob);
int count_regions_with_TAM();
std::vector<int> randomNumberVector(int n, int a, int b);
std::vector<std::string> my_coloring_function( Cell* );
void update_velocity_oriented( Cell* pCell, Phenotype& phenotype, double dt );
void update_velocity_random( Cell* pCell, Phenotype& phenotype, double dt );
std::vector<double> sampleTargetDistances(std::vector<std::vector<double>> dist);
void build_neighbor_trees( void );

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////// MAIN_GBM_TAM.CPP /////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
double CSF_vals(int indexing_CSF_Vec);
double CSF_conc_to_density(double time);
double newTimeToRadiusIncrease(double R, double b, double k);
double newTimeToRadiusIncrease(double R, double t);
void save_general_info(std::vector<int> cellcounts, std::vector<int> deadcells);
void initializeTAMRegionsRadius();
std::vector<std::vector<double>> loadCSV(const std::string& filename);
loadRepulsiveRegions(const std::string& filename);
void loadTargetDistancesDistributions( void ) ;
void initialiseLocalRegions(void );