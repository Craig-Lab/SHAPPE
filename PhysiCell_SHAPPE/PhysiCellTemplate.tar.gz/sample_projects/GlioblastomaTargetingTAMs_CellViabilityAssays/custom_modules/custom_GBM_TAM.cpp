/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "./custom_GBM_TAM.h"
#include "../modules/PhysiCell_settings.h"
#include "./common.h"

#include <cmath>
#include <iostream>
#include <random>
#include <chrono>
#include <algorithm>
#include <numeric>
#include <string>
//#include <cstdlib>
//#include <ctime>

Cell_Definition* cancer_cell;
Cell_Definition* TAM;
Cell_Definition* stroma_cell;
Cell_Definition* CD8;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// TAM FUNCTIONS /////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_TAMs( void ) {
	
	TAM = find_cell_definition( "TAM" );
	
	// cell morphology
	TAM->phenotype.geometry.radius = parameters.doubles("TAM_radius");
	
	// update phenotype
	TAM->functions.update_phenotype = TAM_update;

	//death model
	// int apoptosis_index = TAM->phenotype.death.find_death_model_index( "apoptosis" ); 
	// TAM->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_resident_TAM"); 

	//secretion
	static int chemokine_m0_index = microenvironment.find_density_index( "chemokine_m0");
	TAM->phenotype.secretion.uptake_rates[chemokine_m0_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	TAM->phenotype.secretion.secretion_rates[chemokine_m0_index] = 0.00637;
	TAM->phenotype.secretion.net_export_rates[chemokine_m0_index] = 0;
	
	return;
}

void TAM_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, std::vector<int>& private_deadcells , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go) {

	return;
}

void changePhenotypeVolumeFunction(Cell* pCell, int newP) {
	double TAMvolume = (4/3)*M_PI*pow(parameters.doubles("TAM_radius"),3);
	double nuclear_M1 = parameters.doubles("nuclear_M1");
	double nuclear_M2 = parameters.doubles("nuclear_M2");
	double newNuclearVolume = 0.0;
	//secretion
	static int chemokine_m0_index = microenvironment.find_density_index( "chemokine_m0");
	static int chemokine_m1_index = microenvironment.find_density_index( "chemokine_m1");
	static int chemokine_m2_index = microenvironment.find_density_index( "chemokine_m2");
	pCell->phenotype.secretion.uptake_rates[chemokine_m0_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	pCell->phenotype.secretion.secretion_rates[chemokine_m0_index] = 0.0;
	pCell->phenotype.secretion.net_export_rates[chemokine_m0_index] = 0;
	pCell->phenotype.secretion.uptake_rates[chemokine_m1_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	pCell->phenotype.secretion.secretion_rates[chemokine_m1_index] = 0.0;
	pCell->phenotype.secretion.net_export_rates[chemokine_m1_index] = 0;
	pCell->phenotype.secretion.uptake_rates[chemokine_m2_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	pCell->phenotype.secretion.secretion_rates[chemokine_m2_index] = 0.0;
	pCell->phenotype.secretion.net_export_rates[chemokine_m2_index] = 0;
	if(newP==1) {
		newNuclearVolume = nuclear_M1;
		//secretion
		pCell->phenotype.secretion.uptake_rates[chemokine_m1_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
		pCell->phenotype.secretion.secretion_rates[chemokine_m1_index] = 0.00637;
		pCell->phenotype.secretion.net_export_rates[chemokine_m1_index] = 0;
	} else {
		newNuclearVolume = nuclear_M2;
		//secretion
		pCell->phenotype.secretion.uptake_rates[chemokine_m2_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
		pCell->phenotype.secretion.secretion_rates[chemokine_m2_index] = 0.00637;
		pCell->phenotype.secretion.net_export_rates[chemokine_m2_index] = 0;
	}
	pCell->phenotype.volume.target_solid_cytoplasmic = (1.0-pCell->phenotype.volume.target_fluid_fraction)*(TAMvolume-newNuclearVolume);
	pCell->phenotype.volume.target_solid_nuclear = (1.0-pCell->phenotype.volume.target_fluid_fraction)*(newNuclearVolume);
	pCell->phenotype.volume.target_cytoplasmic_to_nuclear_ratio = (pCell->phenotype.volume.target_solid_cytoplasmic)/pCell->phenotype.volume.target_solid_nuclear;
	//Change death rate
	// int apoptosis_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
	// pCell->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
	return;
}

void TAMmovement(Cell* pCell) {
	
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	std::vector<double> ae_ini(3);
    	
	if( wall_amount<3 ) {
		
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
		pCell->phenotype.motility.migration_speed = 4;
		return;
		
	} else {
		
		if(parameters.bools("Oriented_Movement")) {
			std::string TAMtype = "M0";
			int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
			int TAMphenotype = pCell->custom_data.variables[phenotype_index].value;
			double initialTAMcount = parameters.doubles("M0_0");
			if(TAMphenotype==1) {
				TAMtype = "M1";
				initialTAMcount = parameters.doubles("M1_0");
			} else if (TAMphenotype==2) {
				TAMtype = "M2";
				initialTAMcount = parameters.doubles("M2_0");
			}
			if(initialTAMcount>4) {
				//Retrieve movement bias towards cancer cells
				double bcancer = parameters.doubles(TAMtype+"_bias_cancer");
				//Retrieve movement bias towards cd8 cells
				double bcd8 = parameters.doubles(TAMtype+"_bias_cd8");
				//Retrieve movement bias towards stroma cells
				double bstroma = parameters.doubles(TAMtype+"_bias_stroma");
				//Retrieve movement bias towards M0 TAMs
				double bM0 = parameters.doubles(TAMtype+"_bias_M0");
				//Retrieve movement bias towards M1 TAMs
				double bM1 = parameters.doubles(TAMtype+"_bias_M1");
				//Retrieve movement bias towards M2 TAMs
				double bM2 = parameters.doubles(TAMtype+"_bias_M2");
				//Put biases together
				std::vector<double> biases = {bcancer,bcd8,bstroma,bM0,bM1,bM2};
				//Get total bias 
				double totalBias = std::accumulate(biases.begin(), biases.end(), 0.0);
				//If totalBias==0, then orientedMovement is not executed and movement will be as in our average model.
				pCell->phenotype.motility.migration_speed = 4;
				orientedMovement(pCell,biases);
				return;
			}
		} 
		// sample chemotaxis gradient and random walk in that direction
		pCell->phenotype.motility.migration_speed = 4;
		pCell->phenotype.motility.migration_bias = 0;
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(wall_index);
		//normalize( &(pCell->phenotype.motility.migration_bias_direction));
		return; 
	}
	
	return;
}

void TAM_recruitement(double dt) {
	
	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// STROMA CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_stroma_cells( void ) {
	
	stroma_cell = find_cell_definition( "stroma cell" );
	
	// cell morphology
	stroma_cell->phenotype.geometry.radius = parameters.doubles("Stroma_radius");
	
	// update phenotype
	stroma_cell->functions.update_phenotype = stroma_update;
	
	return;
}

void stroma_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, std::vector<int>& private_deadcells , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go ) {

	return;
}

void stroma_recruitment(double innerRadius, double outerRadius) {
	return ;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// CD8+ T CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_CD8_cells( void ) {
	CD8 = find_cell_definition( "CD8" );

	//cell morphology
	CD8->phenotype.geometry.radius = parameters.doubles("CD8_radius");

	//death model
	//int apoptosis_index = CD8->phenotype.death.find_death_model_index( "apoptosis" ); 
	//CD8->phenotype.death.rates[apoptosis_index] = parameters.doubles("CD8_death_rate"); 

	// cell update phenotype		
	CD8->functions.update_phenotype = CD8_update;

	return;
}

//Recruitment of CD8+ T cells by TAMs
void CD8_recruitement(double dt) {
	
	return;
}

void CD8_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, std::vector<int>& private_deadcells , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go) {

	return;
}

void CD8_check_for_attachment(Cell* pCell) {
	// loop through cells in its neighborhood	
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//if(pCell->state.neighbors.size()>0) {
	if(neighbors.size()>0) {
		for( int i=0; i < neighbors.size() ; i++ )
		{
			Cell* pNeighbor = neighbors[i];
			int type_neighbor = pNeighbor->type;
			double max_distance = parameters.doubles("max_attachment_distance");
			double d = distance_between_cells(pCell, pNeighbor); 
			int ind_attached = pNeighbor->custom_data.find_variable_index("is_attached");
			bool Neighbor_attached = pNeighbor->custom_data.variables[ind_attached].value;
			//neighbor is an unattached cancer cell within distance 
			int ind_activation = pCell->custom_data.find_variable_index("activation_level");
			double pb = pCell->custom_data.variables[ind_activation].value;
			bool can_attach = eventBinaryOccurence(pb);
			if(type_neighbor==2 && d<=max_distance && !Neighbor_attached && can_attach) {
				attach_cells_as_spring(pCell,pNeighbor);
				pCell->custom_data.variables[ind_attached].value = true;
				pNeighbor->custom_data.variables[ind_attached].value = true;
				int ind_time_attachment = pCell->custom_data.find_variable_index("attachment_time");
				pCell->custom_data.variables[ind_time_attachment].value = PhysiCell_globals.current_time;
				pNeighbor->custom_data.variables[ind_time_attachment].value = PhysiCell_globals.current_time;

				pCell->phenotype.motility.is_motile = false;
				pNeighbor->phenotype.motility.is_motile = false;

				// break out of the for loop
				i = neighbors.size();

				/*
				// XXX Useful if we want to keep track of two cells that are attached
				attached_cells[0] += (double) 1;
				int ind_ID = pCell->custom_data.find_variable_index("cell_id");
				attached_cells[1] = (double) pCell->custom_data.variables[ind_ID].value;
				attached_cells[2] = (double) pNeighbor->custom_data.variables[ind_ID].value;
				attached_cells[3] = PhysiCell_globals.current_time;
				*/
			}
		}
	}
	return;
}

double CD8ProliferationRate(Cell* pCell) {
	double proliferationRate = 0;
	int nCancerCells = 0; //number of cancer cells in it's neighborhood 
	//loop through cells in its neighborhood
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//for( int n=0; n < pCell->state.neighbors.size(); n++ ) {
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int typeNeighbor = pNeighbor->type; 
		if(typeNeighbor==2) {
			nCancerCells++;
			break;
		}
	}
	if(nCancerCells>0) {
		proliferationRate = parameters.doubles("tumour_mediated_proliferation_rate");
		int ind_time_last_encouter = pCell->custom_data.find_variable_index("time_last_tumour_encounter");
		pCell->custom_data.variables[ind_time_last_encouter].value = PhysiCell_globals.current_time;
		// int ki67pos_index = pCell->custom_data.find_variable_index("Ki67pos");
		// pCell->custom_data.variables[ki67pos_index].value = 1;
		// int deathrate_index = pCell->custom_data.find_variable_index("cd8DeathRate");
		// pCell->custom_data.variables[deathrate_index].value = 0.0;

	}
	return proliferationRate;
}

void CD8movement(Cell* pCell) {
	
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	static int chemokine_index = microenvironment.find_density_index( "chemokine" ); 
	double chemokine_amount = pCell->nearest_density_vector()[chemokine_index];
		
	std::vector<double> ae_ini(3);
    	
	if( wall_amount<3 ) {
		
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		return;
		
	} 
	//Following will only be executed if wall_amount >= 3
	if(parameters.bools("Oriented_Movement")) {
		double initialCD8count = parameters.doubles("T_0");
		if(initialCD8count>4) {
			//Retrieve movement bias towards cancer cells
			double bcancer = parameters.doubles("cd8_bias_cancer");
			//Retrieve movement bias towards cd8 cells
			double bcd8 = parameters.doubles("cd8_bias_cd8");
			//Retrieve movement bias towards stroma cells
			double bstroma = parameters.doubles("cd8_bias_stroma");
			//Retrieve movement bias towards M0 TAMs
			double bM0 = parameters.doubles("cd8_bias_M0");
			//Retrieve movement bias towards M1 TAMs
			double bM1 = parameters.doubles("cd8_bias_M1");
			//Retrieve movement bias towards M2 TAMs
			double bM2 = parameters.doubles("cd8_bias_M2");
			//Put biases together
			std::vector<double> biases = {bcancer,bcd8,bstroma,bM0,bM1,bM2};
			//Get total bias 
			double totalBias = std::accumulate(biases.begin(), biases.end(), 0.0);
			//If totalBias==0, then orientedMovement is not executed and movement will be as in our average model.
			pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(bcancer/totalBias)*(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")/2+chemokine_amount));
			orientedMovement(pCell,biases);
			return;
		}
		// //Retrieve movement bias towards cancer cells
		// double bcancer = parameters.doubles("cd8_bias_cancer");
		// //Retrieve movement bias towards cd8 cells
		// double bcd8 = parameters.doubles("cd8_bias_cd8");
		// //Retrieve movement bias towards stroma cells
		// double bstroma = parameters.doubles("cd8_bias_stroma");
		// //Retrieve movement bias towards M0 TAMs
		// double bM0 = parameters.doubles("cd8_bias_M0");
		// //Retrieve movement bias towards M1 TAMs
		// double bM1 = parameters.doubles("cd8_bias_M1");
		// //Retrieve movement bias towards M2 TAMs
		// double bM2 = parameters.doubles("cd8_bias_M2");
		// //Put biases together
		// std::vector<double> biases = {bcancer,bcd8,bstroma,bM0,bM1,bM2};
		// //Get total bias 
		// double totalBias = std::accumulate(biases.begin(), biases.end(), 0.0)
		// //If totalBias==0, then orientedMovement is not executed and movement will be as in our average model.
		// if(totalBias>0) {
		// 	pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(bcancer/totalBias)*(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")/2+chemokine_amount));
		// 	orientedMovement(pCell,biases);
		// 	return;
		// }	
	}
	//Following will only be executed if CD8+ T cells are not significantly distributed non-randomly or if we are not modeling oriented movement
	if(chemokine_amount>1e-8) {
		// sample chemotaxis gradient and random walk in that direction
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")/2+chemokine_amount));
		pCell->phenotype.motility.migration_bias = parameters.doubles("b_CD8");
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(chemokine_index);
		//normalize( &(pCell->phenotype.motility.migration_bias_direction));
		return; 
	} else {
		pCell->phenotype.motility.migration_bias = 0;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		return;
	}
	
	return;
}

float PD1PDL1(Cell* pCell) {
	int count_CD8 = 0;//cellcounts[1];
	int count_cancer = 0;//cellcounts[2];
	int count_TAM = 0;//cellcounts[4];
	float rhoPD1 = parameters.doubles("rho_PD1");
	float rhoPDL1 = parameters.doubles("rho_PDL1");
	double radius = parameters.doubles("GBM_radius");
	float area = M_PI*pow(4*radius,2);

	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int type_Neighbor = pNeighbor->type;
		if(type_Neighbor==1) {
			count_CD8+=1;
		} else if(type_Neighbor == 2) {
			count_cancer += 1;
		} else if(type_Neighbor == 4) {
			count_TAM += 1;
		}
	}

	float PD1 = rhoPD1*count_CD8/area;//vol;
	float PDL1 = rhoPDL1*(count_cancer+count_TAM)/area;//vol;

	float activation_level = 1/(1+((PD1*PDL1)/parameters.doubles("kYQ")));

	return activation_level;
}

void CD8_attempts_apoptosis(Cell* pCell, Cell* pCattached, double dt, std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts) {
	bool dettach_me = false;
	//cancer cell is already dead
	if( pCattached->phenotype.death.dead == true ) { 
		dettach_me = true;
	} else {
		//pb: probability of killing the cell
		double pb = dt*parameters.doubles("cd8_killing_rate");
		bool kills = eventBinaryOccurence(pb);
		if(kills) {
			static int apoptosis_model_index = pCattached->phenotype.death.find_death_model_index( "apoptosis" );	
			static int TMZ_index = microenvironment.find_density_index( "TMZ" ); 
			pCattached->phenotype.molecular.fraction_released_at_death[TMZ_index] = 0;	
			//XX-13/05/2025
			//pCattached->start_death( apoptosis_model_index );
			killCell(pCattached,dt,private_deadcells,private_cellcounts);
			dettach_me = true;
			//update the number of cancer cells killed by CD8+ T cells
			private_deadcells[2] += 1;
		}
	}
	if(dettach_me) {
		int ind_attached = pCell->custom_data.find_variable_index("is_attached");
		int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
		detach_cells_as_spring(pCell,pCattached);
		//set cell's motility back to true
		pCell->phenotype.motility.is_motile = true; 
		// reset its attachment time and attachment boolean variable
		pCell->custom_data.variables[ind_attached].value = false;
		pCell->custom_data.variables[ind_time_attached].value = (double) 0;
	}

}

bool CD8_check_for_exhaustion(Cell* pCell, double dt) {
	int deathrate_index = pCell->custom_data.find_variable_index("cd8DeathRate");
	double death_rate = parameters.doubles("CD8_death_rate");//pCell->custom_data.variables[deathrate_index].value;//
	//death probability
	double pd = dt*death_rate;
	bool exhausted = eventBinaryOccurence(pd);
	return exhausted;
}

void induce_CD8_death(Cell* pCell,double dt, std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts) {
	int ind_attached = pCell->custom_data.find_variable_index("is_attached");
	bool attached = pCell->custom_data.variables[ind_attached].value;
	if(attached) {
		//dettach the cell from the cell it is attached to 
		int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
		for( int j=0; j < pCell->state.spring_attachments.size(); j++ ) {
			Cell* pCattached = pCell->state.spring_attachments[j]; 
			detach_cells_as_spring(pCell,pCattached);
			//set cell's motility back to true
			pCattached->phenotype.motility.is_motile = true; 
			// reset its attachment time and attachment boolean variable
			pCattached->custom_data.variables[ind_attached].value = false;
			pCell->custom_data.variables[ind_attached].value = false;
			pCattached->custom_data.variables[ind_time_attached].value = (double) 0;
		}
		pCell->state.spring_attachments.clear();
	}
	// static int apoptosis_model_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
	int ind_dead = pCell->custom_data.find_variable_index("is_dead");
	pCell->custom_data.variables[ind_dead].value = true;
	pCell->functions.update_phenotype = NULL; 
	//XX-13/05/2025
	//pCell->start_death( apoptosis_model_index );
	killCell(pCell,dt,private_deadcells,private_cellcounts);
	return;
}

void killCell(Cell* pCell, double dt, std::vector<int>& private_deadcells,std::vector<int>& private_cellcounts) {
	int cell_type = pCell->type;
	if(!(cell_type==2)) {
		int apoptosis_model_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
		pCell->phenotype.death.current_death_model_index = apoptosis_model_index;
		pCell->phenotype.death.dead = true;
		// if so, change the cycle model to the current death model 
		pCell->phenotype.cycle.sync_to_cycle_model( pCell->phenotype.death.current_model() ); 

		// make sure to run the death entry function 
		if( pCell->phenotype.cycle.current_phase().entry_function )
		{
			pCell->phenotype.cycle.current_phase().entry_function( pCell, pCell->phenotype, dt ); 
		}
	}
	
	//Update is_dead status
	int is_dead_index = pCell->custom_data.find_variable_index("is_dead");
	pCell->custom_data.variables[is_dead_index].value = true;

	// also, turn off motility.
	pCell->phenotype.motility.is_motile = false; 
	pCell->phenotype.motility.motility_vector.assign( 3, 0.0 ); 
	pCell->functions.update_migration_bias = NULL;
	
	// turn off secretion, and reduce uptake by a factor of 10 
	pCell->phenotype.secretion.set_all_secretion_to_zero();
	pCell->phenotype.secretion.scale_all_uptake_by_factor( 0.10 );

	//Update the number of cells that died
	
	if(cell_type==1) {
		private_deadcells[0] += 1;
	} else if(cell_type==2) {
		private_deadcells[1] += 1;
	} else if(cell_type==3) {
		private_deadcells[3] +=1;
	} else {
		//TAMs - 
		private_deadcells[4] += 1;
		int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
		int phenotype = pCell->custom_data.variables[phenotype_index].value;
		if(phenotype>0) {
			private_cellcounts[3+phenotype] -= 1;
		}
	}
	
	return;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// CANCER CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_cancer_cells( void )
{
	cancer_cell = find_cell_definition( "cancer cell" ); 
	
	// cell actions
	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	cancer_cell->phenotype.secretion.uptake_rates[TMZ_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	cancer_cell->phenotype.secretion.secretion_rates[TMZ_index] = 0.0;
	//cancer_cell->phenotype.motility.migration_speed = 0.0;
	
	// cell morphology
	cancer_cell->phenotype.geometry.radius = parameters.doubles("GBM_radius");

	// set cell specific functions 
	cancer_cell->functions.update_phenotype = cancer_cell_rules; 

	//death model
	int apoptosis_index = cancer_cell->phenotype.death.find_death_model_index( "apoptosis" ); 
	cancer_cell->phenotype.death.rates[apoptosis_index] = (double) 0; 
	
	return; 
}

void cancer_cell_rules( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, std::vector<int>& private_deadcells , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go )
{ 
	
	int is_dead_index = pCell->custom_data.find_variable_index("is_dead");
	bool is_dead = pCell->custom_data.variables[is_dead_index].value;
	
	if(is_dead) {
		pCell->functions.update_phenotype = dead_cancer_cell_update; 
		return; 
	}

	TMZeffect(pCell, dt);

	//update local density
	int neighborhood_density_index = pCell->custom_data.find_variable_index( "neighborhood_density" );
	double d = get_neighborhood_density(pCell);
	pCell->custom_data.variables[neighborhood_density_index].value = d;
	
	cancer_cell_proliferation_movement(pCell, phenotype, dt , pers_time_stop , pers_time_go);
	updateNetProliferationRate(pCell);
	TAMassignRegion(pCell);

	// Cechk if cell dies due to overcrowding
	static int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
	double newProlifRate = pCell->custom_data.variables[proliferation_index].value;
	if(newProlifRate<0) {
		double probability_death = (-1)*newProlifRate*dt;
		bool dies = eventBinaryOccurence(probability_death);
		if(dies) {
			int ind_attached = pCell->custom_data.find_variable_index("is_attached");
			bool attached = pCell->custom_data.variables[ind_attached].value;
			if(attached) {
				//dettach the cell from the cell it is attached to 
				int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
				for( int j=0; j < pCell->state.spring_attachments.size(); j++ ) {
					Cell* pCattached = pCell->state.spring_attachments[j]; 
					detach_cells_as_spring(pCell,pCattached);
					//set cell's motility back to true
					pCattached->phenotype.motility.is_motile = true; 
					// reset its attachment time and attachment boolean variable
					pCattached->custom_data.variables[ind_attached].value = false;
					pCell->custom_data.variables[ind_attached].value = false;
					pCattached->custom_data.variables[ind_time_attached].value = (double) 0;
				}
				pCell->state.spring_attachments.clear();
			}
			// static int apoptosis_model_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
			int ind_dead = pCell->custom_data.find_variable_index("is_dead");
			pCell->custom_data.variables[ind_dead].value = true;
			pCell->functions.update_phenotype = dead_cancer_cell_update; 
			//XX-13/05/2025
			//pCell->start_death( apoptosis_model_index );
			killCell(pCell,dt, private_deadcells,private_cellcounts);
		}
	}

	return; 
} 

void dead_cancer_cell_update( Cell* pCell, Phenotype& phenotype , double dt , std::vector<int>& private_cellcounts, std::vector<int>& private_deadcells , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go ) {
	// XX Commented out on 21/07/2025
	// // check for natural clearance
	// double prob_clearance = parameters.doubles("natural_clearance_rate");
	// bool cleared = eventBinaryOccurence(prob_clearance);
	// if(cleared) {
	// 	pCell->flag_for_removal();
	// 	return;
	// } 
	
	// //Check for phagocytosis
	// double prob_phagocytosis = parameters.doubles("phagocytosis_probability");
	// bool gets_eaten = false;
	// std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	// for(int i=0 ; i<neighbors.size() ; i++) {
	// 	Cell* pNeighbor = neighbors[i];
	// 	int typeNeighbor = pNeighbor->type;
	// 	//you meet a TAM
	// 	if(typeNeighbor==4) {
	// 		//check for phagocytosis
	// 		gets_eaten = eventBinaryOccurence(prob_phagocytosis);
	// 		if(gets_eaten) {
	// 			//TAM gets busy phagocytosing

	// 			//Dead cell gets removed
	// 			pCell->flag_for_removal();
	// 			//break out of the for loop
	// 			i = neighbors.size();
	// 		}
	// 	}
	// }

	double prob_clearance = dt*parameters.doubles("natural_clearance_rate");
	double prob_phagocytosis = dt*parameters.doubles("phagocytosis_probability");
	double TAMneighbor = 0;
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	for(int i=0 ; i<neighbors.size() ; i++) {
		Cell* pNeighbor = neighbors[i];
		int typeNeighbor = pNeighbor->type;
		//you meet a TAM
		if(typeNeighbor==4) {
			TAMneighbor += 1.0;
		}
	}
	//prob_phagocytosis = TAMneighbor*prob_phagocytosis;
	prob_phagocytosis = 1.0 - pow(1.0 - dt*parameters.doubles("phagocytosis_probability"), TAMneighbor);
	std::vector<double> probabilitesDeadCell = {prob_clearance,prob_phagocytosis,1.0-prob_clearance-prob_phagocytosis};
	int eventDeadCell = choose_event(probabilitesDeadCell);
	if(eventDeadCell<2) {
		pCell->flag_for_removal();
	}

	return;

}

//returns 1 for Go/Not proliferating model, and 2 for Stop/Grow model
int cancer_cell_assign_movement_type(Cell* pC) {
	double new_type_rand = UniformRandom();
	double max_density = parameters.doubles("maximum_cell_density");
	int neighborhood_density_index = pC->custom_data.find_variable_index( "neighborhood_density" );
	double d = pC->custom_data.variables[neighborhood_density_index].value;
	double proba_go = 0.5;//+(1.0-0.5)*(d/max_density);
	if(new_type_rand<=proba_go) {
		return 1;
	} else {
		return 2;
	}
}

double cancer_cell_assign_persistence_time(std::vector<double> cumul_prob,std::vector<double> times) {
	double p = UniformRandom();
	double pers = 0;
	for( int j=0; j<8; )
	{
		if( p> cumul_prob[j] ) {
			j++;
		} else {
			pers = times[j];
			j = 8;
		}
	}
	return pers;
}

std::vector<double>  cancer_cell_proliferation_rate(Cell* pC) {
	double max_density = parameters.doubles("maximum_cell_density");
	int neighborhood_density_index = pC->custom_data.find_variable_index( "neighborhood_density" );
	double d = pC->custom_data.variables[neighborhood_density_index].value;
	
	std::vector<double>  prolifRate(2);
	int baseline_proliferation_index = pC->custom_data.find_variable_index( "baseline_proliferation_rate" );
	double baseline_proliferation_rate = pC->custom_data.variables[baseline_proliferation_index].value;
	//prolifRate[0] = std::max((double) 0,baseline_proliferation_rate*(1-(d/max_density)));	//modify proliferation rate due to local density
	if(d>max_density) {
		prolifRate[0] = baseline_proliferation_rate*(1-d/max_density);//(double) 0;
	} else {
		prolifRate[0] = baseline_proliferation_rate*(1-d/max_density);
	}
	prolifRate[1] = 0;//prolifRateBaseline*(TMZ_effect); //death rate
	return prolifRate;
}

//update baseline proliferate rate and apoptosis rate of a tumour cell
void TMZeffect(Cell* pC, double dt) {
	double EC50 = parameters.doubles("IC50");
	double Emax = dt*parameters.doubles("E_max")/(60);
	double h = parameters.doubles("h");
	static int TMZ_index = microenvironment.find_density_index("TMZ");	
	double TMZ = std::max(pC->nearest_density_vector()[TMZ_index],(double) 0);
	double TMZ_effect = Emax*pow(TMZ,h)/(pow(TMZ,h)+pow(EC50,h));
	//if(!(dt>0)) {
	//	TMZ_effect = (double) 0;
	//}
	if(!parameters.bools("TMZ_tx")) {
		TMZ_effect = (double) 0;
	}
	double prolifRateGBMCellLine = parameters.doubles("GBM_cell_proliferation_rate"); 
	int baseline_proliferation_index = pC->custom_data.find_variable_index( "baseline_proliferation_rate" );
	double old_baseline_proliferation_rate = pC->custom_data.variables[baseline_proliferation_index].value;
	double new_baseline_proliferation_rate = (1.0-TMZ_effect)*old_baseline_proliferation_rate;//(1-TMZ_effect)*old_baseline_proliferation_rate;
	pC->custom_data.variables[baseline_proliferation_index].value = new_baseline_proliferation_rate;
	
	//modify apoptosis rate due to TMZ
	static int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
	int apoptosis_rate_index = pC->custom_data.find_variable_index( "apoptosis_rate" );
	double old_apoptosis_rate = pC->custom_data.variables[apoptosis_rate_index].value;
	double changeApoptosisRate = TMZ_effect*new_baseline_proliferation_rate;//prolifRateGBMCellLine;//prolifRateGBMCellLine*(prolifRateGBMCellLine-new_baseline_proliferation_rate)/prolifRateGBMCellLine;
	double newApoptosisRate = old_apoptosis_rate+changeApoptosisRate;
	pC->phenotype.death.rates[apoptosis_index] = newApoptosisRate;//TMZ_effect*prolifRateGBMCellLine;
	//int apoptosis_rate_index = pC->custom_data.find_variable_index( "apoptosis_rate" );
	pC->custom_data.variables[apoptosis_rate_index].value = newApoptosisRate;
	
}

void cancer_cell_proliferation_movement( Cell* pCell, Phenotype& phenotype, double dt , std::vector<int>& pers_time_stop , std::vector<int>& pers_time_go )
{ 
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	static int persistence_time_index = pCell->custom_data.find_variable_index( "persistence_time" );
	static int cell_motility_type_index = pCell->custom_data.find_variable_index( "cell_motility_type" );
	double persistence_time = pCell->custom_data.variables[persistence_time_index].value;
	double cell_motility_type = pCell->custom_data.variables[cell_motility_type_index].value; 

	static int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	static int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 

	std::vector<double> go_times_cumul(8);
	std::vector<double> stop_times_cumul(8);
	std::vector<double> persistence_times_vec(8);
	std::vector<double> speed_cumul(12);
	std::vector<double> speed_vec(12);
	go_times_cumul = go_times_cumulative();
	stop_times_cumul = stop_times_cumulative();
	persistence_times_vec = persistance_distribution();
	speed_cumul = speed_cumulative();
	speed_vec = speed_distribution();
	static int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
	double newProlifRate = pCell->custom_data.variables[proliferation_index].value;

	if( persistence_time <= PhysiCell_globals.current_time ) // if the cell's persistence time is up
	{
		int previousMovementType = pCell->custom_data.variables[cell_motility_type_index].value;
		int newMovementType = (previousMovementType % 2)+1;//cancer_cell_assign_movement_type(pCell);
		pCell->custom_data.variables[cell_motility_type_index].value = newMovementType;
		double new_persistence_time = (double) 0;
		if(newMovementType==parameters.ints("GoMovementType")) {
			// go movement type
			new_persistence_time = cancer_cell_assign_persistence_time(go_times_cumul,persistence_times_vec);
			double speed_var = UniformRandom();
			for( int k=0; k<12; )
			{
				if( speed_var> speed_cumul[k] )
				{k++;}
				else
				{
					pCell->phenotype.motility.migration_speed = speed_vec[k]; // assign migration speed
					k = 12;
				}
			}
			//newProlifRate = (double) 0;
			//pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate; // no proliferation
		} else {
			new_persistence_time = cancer_cell_assign_persistence_time(stop_times_cumul,persistence_times_vec);
			pCell->phenotype.motility.migration_speed = 0;
			//std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
			// proliferation (1st element)
			//newProlifRate = tempRates[0];
			//pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
		}
		static int effective_time_index = pCell->custom_data.find_variable_index( "effective_persistence_time" );
		if(previousMovementType!=newMovementType) {
			int idx = update_pers_time_structure(pCell->custom_data.variables[effective_time_index].value);
			if(previousMovementType==parameters.ints("GoMovementType")) {
				pers_time_go[idx] += 1;
			} else {
				pers_time_stop[idx] += 1;
			}
			pCell->custom_data.variables[effective_time_index].value = new_persistence_time;
		} else {
			pCell->custom_data.variables[effective_time_index].value += new_persistence_time;
		}
		pCell->custom_data.variables[persistence_time_index].value = new_persistence_time+PhysiCell_globals.current_time; // assign persist time

		//XX-13/05/2025
		// std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
		// // proliferation (1st element)
		// newProlifRate = tempRates[0];
		// pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
		// pCell->custom_data.variables[persistence_time_index].value = new_persistence_time+PhysiCell_globals.current_time; // assign persist time
		// pCell->custom_data.variables[proliferation_index].value = newProlifRate;

	} //else {//} if (cell_motility_type>1) {
	// 	// proliferation (1st element) 
	// 	std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
	// 	newProlifRate = tempRates[0];
	// 	pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
	// 	pCell->custom_data.variables[proliferation_index].value = newProlifRate;

	// }

	std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
	newProlifRate = tempRates[0];
	if(newProlifRate<0) {
		pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = (double) 0;
	} else {
		pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
	}
	pCell->custom_data.variables[proliferation_index].value = newProlifRate;
	std::vector<double> ae_ini(3);
	//outisde migratory domain: set migration speed to 0
	if( wall_amount<3 )
	{
		//pCell->phenotype.motility.migration_speed = 0;
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
	} else {
		pCell->phenotype.motility.migration_bias = 0;
	}
			
	return;

}

void updateNetProliferationRate(Cell* pCell) {
	//Get proliferation rate
	int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
	double proliferation_rate = pCell->custom_data.variables[proliferation_index].value;
	//Get TMZ-induced apoptosis rate
	int apoptosis_index = pCell->custom_data.find_variable_index( "apoptosis_rate" );
	double tmz_apoptosis_rate = pCell->custom_data.variables[apoptosis_index].value;
	//Get CD8-induced apoptosis rate
	double cd8_apoptosis_rate = 0;
	int attached_index = pCell->custom_data.find_variable_index("is_attached");
	bool is_attached = pCell->custom_data.variables[attached_index].value;
	if(is_attached) {
		cd8_apoptosis_rate = parameters.doubles("cd8_killing_rate");
	}
	//Update net proliferation rate
	int net_proliferation_index = pCell->custom_data.find_variable_index( "net_proliferation_rate" );
	pCell->custom_data.variables[net_proliferation_index].value = proliferation_rate-tmz_apoptosis_rate-cd8_apoptosis_rate;
}


std::vector<double> go_times_cumulative()
{
	// setting up distributions for movement and persistance of cells
	std::vector<double> go_times_cumul(8);
    go_times_cumul[0] = 0.01;
	go_times_cumul[1] = 0.962;
	go_times_cumul[2] = 0.9735;
	go_times_cumul[3] = 0.9835;
	go_times_cumul[4] = 0.9935;
	go_times_cumul[5] = 0.9955;
	go_times_cumul[6] = 0.9975;
	go_times_cumul[7] = 1;
	
	return go_times_cumul;
}

std::vector<double> stop_times_cumulative()
{
	// setting up distributions for movement and persistance of cells
	std::vector<double> stop_times_cumul(8);
    stop_times_cumul[0] = 0.021;
	stop_times_cumul[1] = 0.6671;
	stop_times_cumul[2] = 0.8114;
	stop_times_cumul[3] = 0.8952;
	stop_times_cumul[4] = 0.9641;
	stop_times_cumul[5] = 0.9857;
	stop_times_cumul[6] = 0.9941;
	stop_times_cumul[7] = 1;
	
	return stop_times_cumul;
}

std::vector<double> persistance_distribution()
{	
	std::vector<double> persistance_times_vec(8);
    persistance_times_vec[0] = 0;
	persistance_times_vec[1] = 30;
	persistance_times_vec[2] = 60;
	persistance_times_vec[3] = 90;
	persistance_times_vec[4] = 120;
	persistance_times_vec[5] = 150;
	persistance_times_vec[6] = 180;
	persistance_times_vec[7] = 240;
	
	return  persistance_times_vec;
}

std::vector<double> speed_cumulative()
{	
	std::vector<double> speed_cumul(12);
    speed_cumul[0] = 0.0014;
	speed_cumul[1] = 0.0317;
	speed_cumul[2] = 0.2441;
	speed_cumul[3] = 0.5137;
	speed_cumul[4] = 0.7598;
	speed_cumul[5] = 0.8822;
	speed_cumul[6] = 0.9453;
	speed_cumul[7] = 0.9787;
	speed_cumul[8] = 0.9882;
	speed_cumul[9] = 0.9937;
	speed_cumul[10] = 0.9963;
	speed_cumul[11] = 1;

	return speed_cumul;
}

std::vector<double> speed_distribution()	
{	
	std::vector<double> speed_vec(12);
    speed_vec[0] = 0.0833;
	speed_vec[1] = 0.1667;
	speed_vec[2] = 0.25;
	speed_vec[3] = 0.333;
	speed_vec[4] = 0.4167;
	speed_vec[5] = 0.5;
	speed_vec[6] = 0.5833;
	speed_vec[7] = 0.667;
	speed_vec[8] = 0.75;
	speed_vec[9] = 0.833;
	speed_vec[10] = 0.9167;
	speed_vec[11] = 1;
	
	return speed_vec;
}


int update_pers_time_structure(double time) {
	std::vector<double> lim_inf_bins = persistance_distribution();
	int idx = 0;
	for(int i=0; i<lim_inf_bins.size()-1;i++) {
		double a = lim_inf_bins[i];
		double b = lim_inf_bins[i+1];
		if(a<=time && time<b) {
			idx = i;
			break;
		} else if(i==lim_inf_bins.size()-2) {
			if(time==b) {
				idx = lim_inf_bins.size()-1;
			} else {
				idx = lim_inf_bins.size();
			}
		}
	}
	return idx;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////// GENERAL FUNCTIONS ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_cell_types( void )
{
	// set the random seed 
	if (parameters.ints.find_index("random_seed") != -1)
	{
		SeedRandom(parameters.ints("random_seed"));
	}
	
	initialize_default_cell_definition(); 
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment ); 
	cell_defaults.phenotype.molecular.sync_to_microenvironment( &microenvironment );
	
	cell_defaults.functions.volume_update_function = standard_volume_update_function;
	cell_defaults.functions.update_velocity = standard_update_cell_velocity;

	// Make sure we're ready for 2D
	cell_defaults.functions.set_orientation = up_orientation;  
	cell_defaults.phenotype.geometry.polarity = 1.0; 
	cell_defaults.phenotype.motility.restrict_to_2D = true; 

	cell_defaults.functions.update_migration_bias = NULL; 
	cell_defaults.functions.update_phenotype = NULL; // update_cell_and_death_parameters_O2_based; 
	cell_defaults.functions.custom_cell_rule = NULL; 
	cell_defaults.functions.contact_function = NULL; 
	cell_defaults.functions.update_migration_bias = NULL; 
	
	cell_defaults.functions.add_cell_basement_membrane_interactions = NULL; 
	cell_defaults.functions.calculate_distance_to_membrane = NULL; 

	//setting cycle model to live
	cell_defaults.phenotype.cycle.sync_to_cycle_model( live ); 
	
	int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
	
	cell_defaults.phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = 0;
	
	// reduce cell velocity
	cell_defaults.phenotype.motility.migration_speed = 0.0;

	static int wall_index = microenvironment.find_density_index( "wall");
	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	static int chemokine_index = microenvironment.find_density_index( "chemokine");
	static int oxygen_index = microenvironment.find_density_index( "oxygen");
	// turn off secretion from these cells (oxygen)
	cell_defaults.phenotype.secretion.secretion_rates[oxygen_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[oxygen_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[oxygen_index] = 10; 
	
	cell_defaults.phenotype.secretion.secretion_rates[chemokine_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[chemokine_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[chemokine_index] = parameters.ints("chemokine_saturation_density"); 
	cell_defaults.phenotype.molecular.fraction_released_at_death[chemokine_index] = 1;//1;

	cell_defaults.phenotype.molecular.fraction_released_at_death[wall_index] = 1;//1;
	cell_defaults.phenotype.secretion.secretion_rates[wall_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[wall_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[wall_index] = 10; 
	
	cell_defaults.phenotype.secretion.secretion_rates[TMZ_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[TMZ_index] = 0.0;
	cell_defaults.phenotype.secretion.saturation_densities[TMZ_index] = parameters.doubles("TMZ_saturation_density");
	cell_defaults.phenotype.molecular.fraction_released_at_death[TMZ_index] = 0;

	initialize_cell_definitions_from_pugixml(); 

	cell_defaults.functions.update_phenotype = cancer_cell_rules;
	cell_defaults.phenotype.motility.is_motile = true; 

	// create the cell types
	create_cancer_cells();
	create_CD8_cells();
	create_stroma_cells();
	create_TAMs();
		
	build_cell_definitions_maps(); 
	setup_signal_behavior_dictionaries(); 
	display_cell_definitions( std::cout ); 
	
	return; 
}

void setup_microenvironment( void )
{
	// set domain parameters 
	
	// put any custom code to set non-homogeneous initial conditions or 
	// extra Dirichlet nodes here. 

	// make sure not override and go back to 2D 
	if( default_microenvironment_options.simulate_2D == false )
	{
		std::cout << "Warning: overriding XML config option and setting to 2D!" << std::endl; 
		default_microenvironment_options.simulate_2D = true; 
	}
	
	// initialize BioFVM 
	
	initialize_microenvironment(); 	

	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	static int oxygen_index = microenvironment.find_density_index( "oxygen");
	static int wall_index = microenvironment.find_density_index( "wall");
	static int chemokine_index = microenvironment.find_density_index( "chemokine");
	static int chemokine_cancer_index = microenvironment.find_density_index( "chemokine_cancer");
	static int chemokine_cd8_index = microenvironment.find_density_index( "chemokine_cd8");
	static int chemokine_stroma_index = microenvironment.find_density_index( "chemokine_stroma");
	static int chemokine_m0_index = microenvironment.find_density_index( "chemokine_m0");
	static int chemokine_m1_index = microenvironment.find_density_index( "chemokine_m1");
	static int chemokine_m2_index = microenvironment.find_density_index( "chemokine_m2");

	for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
	{	
		std::vector<double> ECMdense = microenvironment.mesh.voxels[n].center; 
		//assign random ECM density to microenvironment voxel

		microenvironment(n)[oxygen_index] = 0;
		microenvironment(n)[TMZ_index] = 0;
		microenvironment(n)[wall_index] = 3.5;
		microenvironment(n)[chemokine_index] = 0;
		microenvironment(n)[chemokine_cancer_index] = 0;
		microenvironment(n)[chemokine_cd8_index] = 0;
		microenvironment(n)[chemokine_stroma_index] = 0;
		microenvironment(n)[chemokine_m0_index] = 0;
		microenvironment(n)[chemokine_m1_index] = 0;
		microenvironment(n)[chemokine_m2_index] = 0;
		
		// if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("tumour_radius")+10)*(parameters.doubles("tumour_radius")+10))
		// {	
		// 	microenvironment(n)[oxygen_index] = 0;
		// 	microenvironment(n)[TMZ_index] = 0;
		// 	microenvironment(n)[wall_index] = 1;
		// 	microenvironment(n)[chemokine_index] = 0;
		// 	microenvironment(n)[chemokine_cancer_index] = 0;
		// 	microenvironment(n)[chemokine_cd8_index] = 0;
		// 	microenvironment(n)[chemokine_stroma_index] = 0;
		// 	microenvironment(n)[chemokine_m0_index] = 0;
		// 	microenvironment(n)[chemokine_m1_index] = 0;
		// 	microenvironment(n)[chemokine_m2_index] = 0;
			
		// }
		// else if(ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("tumour_radius")-10)*(parameters.doubles("tumour_radius")-10))
		// {
			
		// 	microenvironment(n)[oxygen_index] = 0;
		// 	microenvironment(n)[TMZ_index] = 0;
		// 	microenvironment(n)[wall_index] = 3.5;
		// 	microenvironment(n)[chemokine_index] = 0;
		// 	microenvironment(n)[chemokine_cancer_index] = 0;
		// 	microenvironment(n)[chemokine_cd8_index] = 0;
		// 	microenvironment(n)[chemokine_stroma_index] = 0;
		// 	microenvironment(n)[chemokine_m0_index] = 0;
		// 	microenvironment(n)[chemokine_m1_index] = 0;
		// 	microenvironment(n)[chemokine_m2_index] = 0;
		// }
		// else if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>250*250 )
		// {	
		// 	microenvironment(n)[oxygen_index] = 0;
		// 	microenvironment(n)[TMZ_index] = 0;
		// 	microenvironment(n)[wall_index] = 5;
		// 	microenvironment(n)[chemokine_index] = 0;
		// 	microenvironment(n)[chemokine_cancer_index] = 0;
		// 	microenvironment(n)[chemokine_cd8_index] = 0;
		// 	microenvironment(n)[chemokine_stroma_index] = 0;
		// 	microenvironment(n)[chemokine_m0_index] = 0;
		// 	microenvironment(n)[chemokine_m1_index] = 0;
		// 	microenvironment(n)[chemokine_m2_index] = 0;
		// }
		// else
		// {   
		// 	microenvironment(n)[oxygen_index] = 0;
		// 	microenvironment(n)[TMZ_index] = 0;
		// 	microenvironment(n)[wall_index] = 10;
		// 	microenvironment(n)[chemokine_index] = 0;
		// 	microenvironment(n)[chemokine_cancer_index] = 0;
		// 	microenvironment(n)[chemokine_cd8_index] = 0;
		// 	microenvironment(n)[chemokine_stroma_index] = 0;
		// 	microenvironment(n)[chemokine_m0_index] = 0;
		// 	microenvironment(n)[chemokine_m1_index] = 0;
		// 	microenvironment(n)[chemokine_m2_index] = 0;
		// }
			
	}
	
	return; 
}

void setup_tissue( void )
{
	double Radius = parameters.doubles("tumour_radius");
	
	double x = 0.0;
	double y = 0.0;
	
	// load cells from your CSV file (if enabled)
	load_cells_from_pugixml();
	
	#pragma omp parallel for schedule(dynamic,10)
	for( int n=0; n < (*all_cells).size(); n++ )
	{
		
		Cell* pC = (*all_cells)[n]; 
		int neighborhood_density_index = pC->custom_data.find_variable_index( "neighborhood_density" );
		double d = get_neighborhood_density(pC);
		pC->custom_data.variables[neighborhood_density_index].value = d;
		int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
		if(pC->type ==2) {
			int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
			int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
			//int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
			std::vector<double> tempRates = cancer_cell_proliferation_rate(pC);
			pC->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = tempRates[0];
			
			int persistence_time_index = pC->custom_data.find_variable_index( "persistence_time" );
			int effective_persistence_time_index = pC->custom_data.find_variable_index( "effective_persistence_time" );
			int cell_motility_type_index = pC->custom_data.find_variable_index( "cell_motility_type" );
			// std::vector<double> go_times_cumul(8);
			// std::vector<double> stop_times_cumul(8);
			// std::vector<double> persistence_times_vec(12);
			// std::vector<double> speed_cumul(12);
			// std::vector<double> speed_vec(12);
			std::vector<double> go_times_cumul = go_times_cumulative();
			std::vector<double> stop_times_cumul = stop_times_cumulative();
			std::vector<double> persistence_times_vec = persistance_distribution();
			std::vector<double> speed_cumul = speed_cumulative();
			std::vector<double> speed_vec = speed_distribution();
			int movType = cancer_cell_assign_movement_type(pC);
			pC->custom_data.variables[cell_motility_type_index].value = movType;

			double persistence_time = (double) 0;
			double timepassed = (double) 0;
			TMZeffect(pC, timepassed);
			if(movType==parameters.ints("GoMovementType")) {
				// go movement type
				persistence_time = cancer_cell_assign_persistence_time(go_times_cumul,persistence_times_vec);
				double speed_var = UniformRandom();
				for( int k=0; k<12; )
				{
					if( speed_var> speed_cumul[k] )
					{k++;}
					else
					{
						pC->phenotype.motility.migration_speed = speed_vec[k]; // assign migration speed
						k = 12;
					}
				}
			} else {
				persistence_time = cancer_cell_assign_persistence_time(stop_times_cumul,persistence_times_vec);
				pC->phenotype.motility.migration_speed = 0;
			}
			pC->custom_data.variables[persistence_time_index].value = persistence_time; // assign persist time
			pC->custom_data.variables[effective_persistence_time_index].value = persistence_time; // assign persist time
		} else if(pC->type ==1) {
			//int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
			//int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
			//pC->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = CD8ProliferationRate(pC);
		} else if(pC->type == 4) {
			int phenotype_index = pC->custom_data.find_variable_index("phenotype");
			int phenotype = pC->custom_data.variables[phenotype_index].value;
			if(phenotype>0) {
				// pC->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
				changePhenotypeVolumeFunction(pC,phenotype);
			}
		} 
		/*
		else if(pC->type ==4) {
			std::vector<double> pos = pC->position;
			double x_pos = pos[0];
			double y_pos = pos[1];
			double radius_pos = sqrt(pow(x_pos,2)+pow(y_pos,2));

			//find radius of region in which TAM cell is
			bool search_region = true;
			int region_index = 0;
			while(search_region) {
				double lower_radius = TAMregionsRadius[region_index];
				double upper_radius = TAMregionsRadius[region_index+1];
				if((radius_pos>=lower_radius && radius_pos<upper_radius) || (region_index == (TAMregionsRadius.size()-2))) {
					search_region = false;
				} else {
					region_index += 1;
				}
			}
			double angle_pos= atan2(y_pos,x_pos)/M_PI;
			int angle_index = 0;
			if(angle_pos<0) {
				if(angle_pos<-0.5) {
					angle_index = 2;
				} else {
					angle_index = 3;
				}
			} else {
				if(angle_pos<0.5) {
					angle_index = 0;
				} else {
					angle_index = 1;
				}
			}
			int phenotype_index = pC->custom_data.find_variable_index("phenotype");
			int phenotype = pC->custom_data.variables[phenotype_index].value;
			TAMregionsConfigurations[region_index][angle_index][phenotype] += 1;
		}
		*/
		TAMassignRegion(pC);

		
	}

	return; 
}

void TAMassignRegion(Cell* pCell) {
	// std::vector<double> pos = pCell->position;
	// double x_pos = pos[0];
	// double y_pos = pos[1];
	// double radius_pos = sqrt(pow(x_pos,2)+pow(y_pos,2));
	// //find radius of region in which TAM cell is
	// bool search_region = true;
	// int region_index = 0;
	// while(search_region) {
	// 	double lower_radius = TAMregionsRadius[region_index];
	// 	double upper_radius = TAMregionsRadius[region_index+1];
	// 	if((radius_pos>=lower_radius && radius_pos<upper_radius) || (region_index == TAMregionsRadius.size()-2)) {
	// 		search_region = false;
	// 	} else {
	// 		region_index += 1;
	// 	}
	// }
	// double angle_pos= atan2(y_pos,x_pos)/M_PI;
	// int angle_index = 0;
	// if(angle_pos<0) {
	// 	if(angle_pos<-0.5) {
	// 		angle_index = 2;
	// 	} else {
	// 		angle_index = 3;
	// 	}
	// } else {
	// 	if(angle_pos<0.5) {
	// 		angle_index = 0;
	// 	} else {
	// 		angle_index = 1;
	// 	}
	// }
	// if(pCell->type==4) {
	// 	int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
	// 	int phenotype = pCell->custom_data.variables[phenotype_index].value;
	// 	TAMregionsConfigurations[region_index][angle_index][(pCell->type)+phenotype-1] += 1;
	// } else {
	// 	TAMregionsConfigurations[region_index][angle_index][(pCell->type)-1] += 1;
	// }


	//int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
	//int phenotype = pCell->custom_data.variables[phenotype_index].value;
	//TAMregionsConfigurations[region_index][angle_index][phenotype] += 1;

}

double get_neighborhood_density( Cell* pCell) {
	double density = 0.0;
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	if(neighbors.size()>0) {
		for( int i=0; i < neighbors.size() ; i++ )
		{
			Cell* tempNeighbor = neighbors[i];
			density += (tempNeighbor->phenotype.geometry.radius)/10.75;
		}
	}
	return density;
}

void orientedMovement(Cell* pCell, std::vector<double> movementBias ) {

	static int chemokine_cancer_index = microenvironment.find_density_index( "chemokine_cancer" ); 
	static int chemokine_cd8_index = microenvironment.find_density_index( "chemokine_cd8" );
	static int chemokine_stroma_index = microenvironment.find_density_index( "chemokine_stroma" );
	static int chemokine_m0_index = microenvironment.find_density_index( "chemokine_m0" ); 
	static int chemokine_m1_index = microenvironment.find_density_index( "chemokine_m1" ); 
	static int chemokine_m2_index = microenvironment.find_density_index( "chemokine_m2" ); 
	
	double bias_cancer = movementBias[0];
	double bias_cd8 = movementBias[1];
	double bias_stroma = movementBias[2];
	double bias_m0 = movementBias[3];
	double bias_m1 = movementBias[4];
	double bias_m2 = movementBias[5];

	double totalBias = bias_cancer+bias_cd8+bias_stroma+bias_m0+bias_m1+bias_m2;

	pCell->phenotype.motility.migration_bias = totalBias;

	pCell->phenotype.motility.migration_bias_direction = (bias_cancer/totalBias)*pCell->nearest_gradient(chemokine_cancer_index);
	pCell->phenotype.motility.migration_bias_direction += (bias_cd8/totalBias)*pCell->nearest_gradient(chemokine_cd8_index);
	pCell->phenotype.motility.migration_bias_direction += (bias_stroma/totalBias)*pCell->nearest_gradient(chemokine_stroma_index);
	pCell->phenotype.motility.migration_bias_direction += (bias_m0/totalBias)*pCell->nearest_gradient(chemokine_m0_index);
	pCell->phenotype.motility.migration_bias_direction += (bias_m1/totalBias)*pCell->nearest_gradient(chemokine_m1_index);
	pCell->phenotype.motility.migration_bias_direction += (bias_m2/totalBias)*pCell->nearest_gradient(chemokine_m2_index);
	
	return;

}

//set the pCell to the live model with a proliferation rate equal to prolif_rate
void change_to_live_model(Cell* pCell, double prolif_rate) {
	pCell->phenotype.cycle.sync_to_cycle_model( live );	
	int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
	pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = prolif_rate;
	return;
}

void mark_cells_in_my_neighborhood(Cell* pCell) {
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//for( int n=0; n < pCell->state.neighbors.size(); n++ ) {
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int ind_marked = pNeighbor->custom_data.find_variable_index("marked_boolean");
		pNeighbor->custom_data.variables[ind_marked].value = true;
	}
}

double distance_between_cells(Cell* pC1, Cell* pC2) {
	std::vector<double> displacement = pC1->position - pC2->position;
	double distance = norm( displacement ); 
	return distance;
}

int eventMultipleoccurences(double rate) {

    static std::mt19937 rng(std::random_device{}());
    std::poisson_distribution<int> pois(rate);
    return pois(rng);
	
	// int n = 0;//number of occurences
    // double p =  ((double)rand()) / RAND_MAX ; //sample from uniform distribution between 0 and 1

    // bool continueSearch = true;
    // double a = (double) 0;
    // //loop to find number of occurences of event
    // while (continueSearch) {
        
    //     float pn = exp(-rate)*(pow(rate,n))/tgammaf(n+1);
    //     double b = a+pn;
	// 	//std::cout << "pn: " << pn << std::endl;
	// 	//std::cout << "a: " << a << std::endl;
    //     //std::cout << "b: " << b << std::endl;
    //     if ((a <= p) && (p < b)) {
    //         continueSearch = false;
    //     } else {
    //         a = b;
    //         n = n+1;
    //     }
    // }

    // return n;
}

//Function to determine whether an event occurs or note its probability of occurence is prob
bool eventBinaryOccurence(double prob) {

    bool occurs = false;
    double p =  ((double)rand()) / RAND_MAX ; //sample from uniform distribution between 0 and 1
    if(p<prob) {
        occurs = true;
    }

    return occurs;
}

void empty_TAM_region_array() {
	for(int i=0;i<TAMregionsConfigurations.size();i++){
		for(int j=0;j<TAMregionsConfigurations[i].size();j++) {
		    std::fill(TAMregionsConfigurations[i][j].begin(),TAMregionsConfigurations[i][j].end(),0);
		}
	}
}

//Generate a vector with n random integers between a and b
std::vector<int> randomNumberVector(int n, int a, int b) {
	//seed the random number generator so we don't always get the same numbers
	unsigned seed = time(0);
    // Seed the random number generator.
    srand(seed);
	std::vector<int> myVector(n, 0);
	for(int i=0; i<n; i++) {
		bool keep_searching = true;
		int ri = 0;
		while(keep_searching) {
			//generate random integer
			ri = (rand()%(b-a)) + a;
			if(i==0) {
				keep_searching = false;
			} else {
				//check if integer was already picked
				int it = std::count(myVector.begin(), myVector.end(), ri);
				//In that case ri was not found in myVector and you can stop searching for an integer
				if(it==0) {
					keep_searching = false;
				}
			}
		}
		myVector[i] = ri;
	}
	return myVector;
}

std::vector<std::string> my_coloring_function( Cell* pCell )
{ 
	std::vector< std::string > output( 4, "darkgrey" ); 
	static int ind_attached = pCell->custom_data.find_variable_index( "is_attached" );
	bool attached = pCell->custom_data.variables[ind_attached].value;
	static int ind_ID = pCell->custom_data.find_variable_index( "cell_id" );
	double ID = (double) pCell->custom_data.variables[ind_ID].value;
	static int ind_marked = pCell->custom_data.find_variable_index( "marked_boolean" );
	bool marked = pCell->custom_data.variables[ind_marked].value;

	//dead
	if(pCell->phenotype.death.dead == true)
	{

		output[0] = "rgb(217,217,217)";//"light grey
		output[1] = "rgb(217,217,217)";
		output[2] = "rgb(217,217,217)";
		output[3] = "rgb(217,217,217)";
		
		return output; 
	}
	else if( pCell->type == 1) //CD8+ T cell cell
	{	
		output[0] = "rgb(255,223,191)";//"blue
		output[1] = "rgb(244,122,0)";
		output[2] = "rgb(244,122,0)";
		output[3] = "rgb(244,122,0)";

		return output; 
	}	
	else if( pCell->type == 2) //Cancer cell
	{	
		static int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
		int cell_motility_type_index = pCell->custom_data.find_variable_index( "cell_motility_type" );
		int movType = pCell->custom_data.variables[cell_motility_type_index].value;
		output[0] = "rgb(250,200,196)";//"red
		output[1] = "rgb(211,31,17)";
		output[2] = "rgb(211,31,17)";
		output[3] = "rgb(211,31,17)";
		return output; 
	} else if( pCell->type == 3) //Stroma cell
	{	
		output[0] = "rgb(201, 229, 182)";//green
		output[1] = "rgb(100, 154, 63)";
		output[2] = "rgb(100, 154, 63)";
		output[3] = "rgb(100, 154, 63)";
		return output; 
	}
	else if( pCell->type == 4) //TAM 
	{	
		int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
		int TAMphenotype = pCell->custom_data.variables[phenotype_index].value;
		if(TAMphenotype==0) {
			output[0] = "rgb(255,191,249)";//purple
			output[1] = "rgb(128,0,116)";
			output[2] = "rgb(128,0,116)";
			output[3] = "rgb(128,0,116)";
		} else if (TAMphenotype==1) {
			output[0] = "rgb(205,238,241)";//light blue
			output[1] = "rgb(98,200,211)";
			output[2] = "rgb(98,200,211)";
			output[3] = "rgb(98,200,211)";
		} else {
			output[0] = "rgb(191,241,255)";//dark blue
			output[1] = "rgb(0,113,145)";
			output[2] = "rgb(0,113,145)";
			output[3] = "rgb(0,113,145)";
		}
		
		return output; 
	}
	
	return output;	
}

// ************************************ UNUSED FUNCTIONS ********************************************************

