/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "../core/PhysiCell.h"
#include "../modules/PhysiCell_standard_modules.h" 

using namespace BioFVM; 
using namespace PhysiCell;

// setup functions to help us along 
void create_cancer_cells( void );
void create_CD8_cells( void );
void create_stroma_cells( void );
void create_TAMs( void );
void create_cell_types( void );
void setup_tissue( void ); 

// set up the BioFVM microenvironment 
void setup_microenvironment( void ); 

// custom pathology coloring function 

std::vector<std::string> my_coloring_function( Cell* );

// custom functions can go here 

void phenotype_function( Cell* pCell, Phenotype& phenotype, double dt);
void custom_function( Cell* pCell, Phenotype& phenotype , double dt);

void contact_function( Cell* pMe, Phenotype& phenoMe , Cell* pOther, Phenotype& phenoOther , double dt ); 

void TMZeffect(Cell* pC, double dt);
void cancer_cell_proliferation_movement( Cell* pCell, Phenotype& phenotype, double dt );
void cancer_cell_rules( Cell* pCell, Phenotype& phenotype , double dt );
int cancer_cell_assign_movement_type();
double cancer_cell_assign_persistence_time(std::vector<double> cumul_prob,std::vector<double> times) ;
std::vector<double>  cancer_cell_proliferation_rate(Cell* pC) ;

void CD8_update( Cell* pCell, Phenotype& phenotype , double dt);
void CD8_check_for_attachment(Cell* pCell);

void stroma_update( Cell* pCell, Phenotype& phenotype , double dt);
void stroma_recruitment(double innerRadius, double outerRadius);

void TAM_update( Cell* pCell, Phenotype& phenotype , double dt);
void changePhenotypeVolumeFunction(Cell* pCell, int newP);
void TAMassignRegion(Cell* pCell);
void TAMmovement(Cell* pCell);
void TAM_recruitement(double dt);

void CD8_recruitement(double dt);

double get_neighborhood_density( Cell* pCell);

double CD8ProliferationRate(Cell* pCell);
void CD8movement(Cell* pCell) ;
float PD1PDL1(Cell* pCell);
void CD8_attempts_apoptosis(Cell* pCell, Cell* pCattached, double dt);
bool CD8_check_for_exhaustion(Cell* pCell, double dt);
void induce_CD8_death(Cell* pCell, double dt);
void updateNetProliferationRate(Cell* pCell);
void killCell(Cell* pCell, double dt);
void change_to_live_model(Cell* pCell, double prolif_rate);

void mark_cells_in_my_neighborhood(Cell* pCell);
double distance_between_cells(Cell* pC1, Cell* pC2) ;

int eventMultipleoccurences(double rate);
bool eventBinaryOccurence(double prob);

std::vector<double> go_times_cumulative();
std::vector<double> stop_times_cumulative();
std::vector<double> persistance_distribution();
std::vector<double> speed_cumulative();
std::vector<double> speed_distribution();
void empty_TAM_region_array();
std::vector<int> randomNumberVector(int n, int a, int b);

//functions in main_GBM_TAM.cpp
double CSF_vals(int indexing_CSF_Vec);
double CSF_conc_to_density(double time);
double newTimeToRadiusIncrease(double R, double b, double k);
void save_general_info(std::vector<int> cellcounts, std::vector<int> deadcells);
void initializeTAMRegionsRadius();