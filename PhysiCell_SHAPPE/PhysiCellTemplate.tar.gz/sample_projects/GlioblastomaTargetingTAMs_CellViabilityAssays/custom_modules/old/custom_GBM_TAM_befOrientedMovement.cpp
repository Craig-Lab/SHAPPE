/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "./custom_GBM_TAM.h"
#include "../modules/PhysiCell_settings.h"
#include "./common.h"

#include <cmath>
#include <iostream>
#include <random>
#include <chrono>
#include <algorithm>
//#include <cstdlib>
//#include <ctime>

Cell_Definition* cancer_cell;
Cell_Definition* TAM;
Cell_Definition* stroma_cell;
Cell_Definition* CD8;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// TAM FUNCTIONS /////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_TAMs( void ) {
	
	TAM = find_cell_definition( "TAM" );
	
	// cell morphology
	TAM->phenotype.geometry.radius = parameters.doubles("TAM_radius");
	
	// update phenotype
	TAM->functions.update_phenotype = TAM_update;

	//death model
	int apoptosis_index = TAM->phenotype.death.find_death_model_index( "apoptosis" ); 
	TAM->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_resident_TAM"); 
	
	return;
}

void TAM_update( Cell* pCell, Phenotype& phenotype , double dt) {
	
	if( pCell->phenotype.death.dead == true ) {
		pCell->functions.update_phenotype = NULL;
		pCell->functions.custom_cell_rule = NULL; 
		return; 
	}

	//update direction if cell is out of wall index
	TAMmovement(pCell);

	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);

	//check for activation or change of phenotype
	int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
	int TAMphenotype = pCell->custom_data.variables[phenotype_index].value;
	int newPhenotype = TAMphenotype;

	int time_stimulation_tam_index = pCell->custom_data.find_variable_index("time_since_stimulation_by_tam");
	int time_stimulation_dead_index = pCell->custom_data.find_variable_index("time_since_stimulation_by_dead_cell");

	double pM1M2TAMs = parameters.doubles("probability_activation_M1M2TAMs");
	double pDeadCells = parameters.doubles("probability_activation_deadCells");
	double pM2phenotype = parameters.doubles("M2_probability");
	double muM1 = parameters.doubles("muM1");
	double muM2 = parameters.doubles("muM2");
	if(TAMphenotype==0) {
		//check for activation -- loop through all cells in the neighborhood of resident TAM
		for(int i=0 ; i<neighbors.size() ; i++) {
			Cell* pNeighbor = neighbors[i];
			int typeNeighbor = pNeighbor->type;
			int phenotypeNeighbor = pNeighbor->custom_data.variables[phenotype_index].value;
			bool deadNeighbor = pNeighbor->phenotype.death.dead;
			//double pActivation = (double) 0;
			if(typeNeighbor==4 && deadNeighbor==false && phenotypeNeighbor>0) {
				//activated and alive TAM
				//pActivation = pM1M2TAMs*dt;
				pCell->custom_data.variables[time_stimulation_tam_index].value = PhysiCell_globals.current_time;
			} else if (typeNeighbor==2 && deadNeighbor==true) {
				//dead tumour cells
				//pActivation = pDeadCells*dt;
				pCell->custom_data.variables[time_stimulation_dead_index].value = PhysiCell_globals.current_time;
			}
			/*
			double p1 = UniformRandom();
			//you get activated
			if(p1<pActivation) {
				//check to see what phenotype the newly activated residentTAM acquires
				double p2 = UniformRandom();
				if(p2<pM2phenotype) {
					newPhenotype = 2;
				} else {
					newPhenotype = 1;
				}
				//stop looking for activation
				i=neighbors.size();
				cellcounts[3+newPhenotype] += 1;
				int apoptosis_index = TAM->phenotype.death.find_death_model_index( "apoptosis" ); 
				pCell->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
			}
			*/
		}
		
		double time_since_tam_stimulation = pCell->custom_data.variables[time_stimulation_tam_index].value - PhysiCell_globals.current_time;
		double time_since_dead_stimulation = pCell->custom_data.variables[time_stimulation_dead_index].value - PhysiCell_globals.current_time;
		double exhaustionStimulation = 10*dt;
		double pActivation = (double) 0;
		//probability of activation is that of the closest interaction 
		if(time_since_tam_stimulation < exhaustionStimulation) {
			if(time_since_dead_stimulation<time_since_tam_stimulation) {
				pActivation = pDeadCells*dt;
			} else {
				pActivation = pM1M2TAMs*dt;
			}
		} else if(time_since_dead_stimulation<exhaustionStimulation) {
			pActivation = pDeadCells*dt;
		} 
		double p1 = UniformRandom();
		//you get activated
		if(p1<pActivation) {
			//check to see what phenotype the newly activated residentTAM acquires
			double p2 = UniformRandom();
			if(p2<pM2phenotype) {
				newPhenotype = 2;
			} else {
				newPhenotype = 1;
			}
			//stop looking for activation
			//i=neighbors.size();
			cellcounts[3+newPhenotype] += 1;
			int apoptosis_index = TAM->phenotype.death.find_death_model_index( "apoptosis" ); 
			pCell->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
		}
		
	} else {
		//check for phenotype switch
		if(TAMphenotype==1) {
			bool changePhenotype = eventBinaryOccurence(dt*muM1);
			if(changePhenotype) {
				newPhenotype = 2;
				cellcounts[5] += 1;
				cellcounts[4] -= 1;
			}
		} else {
			bool changePhenotype = eventBinaryOccurence(dt*muM2);
			if(changePhenotype) {
				newPhenotype = 1;
				cellcounts[4] += 1;
				cellcounts[5] -= 1;
			}
		}
	}

	//change phenotype if newPhenotype != oldPhenotype (oldPhenotype=phenotype)
	if(!(newPhenotype==TAMphenotype)) {
		pCell->custom_data.variables[phenotype_index].value = newPhenotype;
		changePhenotypeVolumeFunction(pCell,newPhenotype);
	}

	//check for phagocytosis
	int time_next_phagocytosis_index = pCell->custom_data.find_variable_index("time_to_next_phagocytosis");
	double time_next_phagocytosis = pCell->custom_data.variables[time_next_phagocytosis_index].value;
	double material_internalisation_rate = parameters.doubles("material_internalisation_rate");

	//TAM is ready to ingest a cell
	if(!(time_next_phagocytosis>PhysiCell_globals.current_time)) {
		for(int i=0 ; i<neighbors.size() ; i++) {
			Cell* pNeighbor = neighbors[i];
			int typeNeighbor = pNeighbor->type;
			bool deadNeighbor = pNeighbor->phenotype.death.dead;
			if(typeNeighbor==2 && deadNeighbor == true) {
				double volume_to_ingest = pNeighbor->phenotype.volume.total;
				double time_to_ingest = volume_to_ingest*material_internalisation_rate;
				//update the next time will be able to phagocytose a cell
				pCell->custom_data.variables[time_next_phagocytosis_index].value = PhysiCell_globals.current_time+time_to_ingest;
				pCell->ingest_cell(pNeighbor);
				i = neighbors.size();
			}
		}
	}

	TAMassignRegion(pCell);

	return;
}

void changePhenotypeVolumeFunction(Cell* pCell, int newP) {
	double TAMvolume = (4/3)*M_PI*pow(parameters.doubles("TAM_radius"),3);
	double nuclear_M1 = parameters.doubles("nuclear_M1");
	double nuclear_M2 = parameters.doubles("nuclear_M2");
	double newNuclearVolume = 0.0;
	if(newP==1) {
		newNuclearVolume = nuclear_M1;
	} else {
		newNuclearVolume = nuclear_M2;
	}
	pCell->phenotype.volume.target_solid_cytoplasmic = (1.0-pCell->phenotype.volume.target_fluid_fraction)*(TAMvolume-newNuclearVolume);
	pCell->phenotype.volume.target_solid_nuclear = (1.0-pCell->phenotype.volume.target_fluid_fraction)*(newNuclearVolume);
	pCell->phenotype.volume.target_cytoplasmic_to_nuclear_ratio = (pCell->phenotype.volume.target_solid_cytoplasmic)/pCell->phenotype.volume.target_solid_nuclear;
	//Change death rate
	int apoptosis_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
	pCell->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
	return;
}

void TAMmovement(Cell* pCell) {
	
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	std::vector<double> ae_ini(3);
    	
	if( wall_amount<3 ) {

		
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
		pCell->phenotype.motility.migration_speed = 4;
		return;
		
	} else {
		// sample chemotaxis gradient and random walk in that direction
		pCell->phenotype.motility.migration_speed = 4;
		pCell->phenotype.motility.migration_bias = 0;//0.5;
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(wall_index);
		//normalize( &(pCell->phenotype.motility.migration_bias_direction));
		return; 
	}
	
	return;
}

void TAM_recruitement(double dt) {

	int count_resident_TAMs = (cellcounts[3]-deadcells[4])-cellcounts[4]-cellcounts[5];
	double lambdaODE = parameters.doubles("baseline_constant_source");
	double deathrate_M0 = parameters.doubles("death_rate_resident_TAM");
	double deathrate_M1M2 = parameters.doubles("death_rate_activated_TAM");
	double Mstar = parameters.doubles("MstarODE");
	double M0_initial = parameters.doubles("M0_0");
	double M1_initial = parameters.doubles("M1_0");
	double M2_initial = parameters.doubles("M2_0");
	double TAM_initial = M0_initial+M1_initial+M2_initial;
	double carryingCapacityRecruitment = parameters.doubles("TAM_recruitment_IC50");
	double Cancercounts = cellcounts[1]-deadcells[1];
	//double recruitmentRate = dt*lambdaODE*(((double) TAM_initial)/Mstar);
	double recruitmentRate = dt*(deathrate_M1M2*(M1_initial+M2_initial)+deathrate_M0*M0_initial); //XX 06/02/2025

	//How many TAMs are recruited
	int TAMrecruited = eventMultipleoccurences(recruitmentRate);
	//std::cout << "Recruiting " << TAMrecruited << " resident TAMs." << std::endl;
	
	//Number of recruited TAMs that are M1
	int numberM1 = TAMrecruited*(M1_initial/TAM_initial)*(Cancercounts/(carryingCapacityRecruitment+Cancercounts));
	//std::cout << "Recruiting " << numberM1 << " M1 TAMs." << std::endl;
	//Number of recruited TAMs that are M2
	int numberM2 = TAMrecruited*(M2_initial/TAM_initial)*(Cancercounts/(carryingCapacityRecruitment+Cancercounts));
	//std::cout << "Recruiting " << numberM2 << " M2 TAMs." << std::endl;
	//Number of recruited TAMs that are M0
	int numberM0 = TAMrecruited-numberM1-numberM2;
	//std::cout << "Recruiting " << numberM0 << " M0 TAMs." << std::endl;

	//XX-13/055/2025
	double rmin = 0;//current_tumour_radius-10.0;
	double rmax = current_tumour_radius+10.0;
	for(int i = 0 ; i < TAMrecruited ; i++) {
		// double rmin = current_tumour_radius-10.0;
		// double rmax = current_tumour_radius+10.0;
		double r = sqrt(pow(rmin,2)+(pow(rmax,2)-pow(rmin,2))*UniformRandom());
		double theta = UniformRandom()*2*M_PI;
		double x = r*cos(theta);
		double y= r*sin(theta);
		Cell_Definition* pCD = find_cell_definition( 4 );
		Cell* pC = create_cell(*pCD);
		pC->assign_position(x,y,0);
		int phenotype_index = pC->custom_data.find_variable_index("phenotype");
		if(i<numberM1) {
			pC->custom_data.variables[phenotype_index].value = 1;
			changePhenotypeVolumeFunction(pC,1);
			cellcounts[4] += 1;
		} else if (i<(numberM1+numberM2)) {
			pC->custom_data.variables[phenotype_index].value = 2;
			changePhenotypeVolumeFunction(pC,2);
			cellcounts[5] += 1;
		}
		
		TAMassignRegion(pC); //XX 06/02/2025
	}
	
	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// STROMA CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_stroma_cells( void ) {
	
	stroma_cell = find_cell_definition( "stroma cell" );
	
	// cell morphology
	stroma_cell->phenotype.geometry.radius = parameters.doubles("Stroma_radius");
	
	// update phenotype
	stroma_cell->functions.update_phenotype = stroma_update;
	
	return;
}

void stroma_update( Cell* pCell, Phenotype& phenotype , double dt ) {
	//update local density
	int neighborhood_density_index = pCell->custom_data.find_variable_index( "neighborhood_density" );
	double d = get_neighborhood_density(pCell);
	pCell->custom_data.variables[neighborhood_density_index].value = d;
	TAMassignRegion(pCell);
	return;
}

void stroma_recruitment(double innerRadius, double outerRadius) {
	double area = M_PI*pow(outerRadius,2)-M_PI*pow(innerRadius,2);
	double initalTumourRadius = parameters.doubles("tumour_radius_initial");
	double S0 = parameters.doubles("S0");
	//Density of stroma cells
	double StromalDensity = S0/(M_PI*pow(initalTumourRadius,2));
	int numStromaCells =  (int) round(StromalDensity*area);
	if(numStromaCells>0) {
		//Find indexes of the stromal cells chosen to recruit
		int StromaCount = cellcounts[2];
		std::vector<int> stromal_indexes = randomNumberVector(numStromaCells,0,StromaCount);
		int current_stroma_index = 0;
		int recruited_stroma_cell = 0;
		//Parse through cells
		for( int n=0; n < (*all_cells).size(); n++ )
		{
			Cell* pC = (*all_cells)[n];
			//If cell is a stroma cell
			if(pC->type==3) {
				//find if stroma cell is chosen
				int it = std::count(stromal_indexes.begin(), stromal_indexes.end(), current_stroma_index);
				//current_stroma_index was found in stromal_indexes
				if(it>0) {
					//find position of stroma cell
					double x = pC->position[0];
					double y = pC->position[1];
					//generate random radius between innerRadius and outerRadius
					double r = ((double) rand() / (RAND_MAX));
					double radius = innerRadius + (outerRadius-innerRadius)*r;
					//Find position of new cell
					double theta = atan2(y,x);
					double new_x = cos(theta)*radius;
					double new_y = sin(theta)*radius;
					//Create new cell
					Cell_Definition* pCD = find_cell_definition( 3 );
					Cell* pC_new = create_cell(*pCD);
					pC_new->assign_position(new_x,new_y,0);
					TAMassignRegion(pC_new); 
					recruited_stroma_cell += 1;
					//you have recruited all needed stroma cells
					if(recruited_stroma_cell>=numStromaCells) {
						std::cout << "Recruited" << numStromaCells << " stroma cells." << std::endl;
						break;
					}
				}
				current_stroma_index += 1;
			}
		}
	} else {
		std::cout << "Recruited no stroma cells." << std::endl;
	}
	return ;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// CD8+ T CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_CD8_cells( void ) {
	CD8 = find_cell_definition( "CD8" );

	//cell morphology
	CD8->phenotype.geometry.radius = parameters.doubles("CD8_radius");

	//death model
	//int apoptosis_index = CD8->phenotype.death.find_death_model_index( "apoptosis" ); 
	//CD8->phenotype.death.rates[apoptosis_index] = parameters.doubles("CD8_death_rate"); 

	// cell update phenotype		
	CD8->functions.update_phenotype = CD8_update;

	return;
}

//Recruitment of CD8+ T cells by TAMs
void CD8_recruitement(double dt) {
	
	double Tstar = parameters.doubles("Tstar");
	double eta1 = parameters.doubles("baseline_eta_1");

	double deathrateCD8 = parameters.doubles("CD8_death_rate");
	double prolifrateCD8 = parameters.doubles("tumour_mediated_proliferation_rate");
	double kYQ = parameters.doubles("kYQ");
	float rhoPD1 = parameters.doubles("rho_PD1");
	float rhoPDL1 = parameters.doubles("rho_PDL1");
	double eta2 = parameters.doubles("eta_2");
	double T0 = parameters.doubles("T_0");
	double M0_0 = parameters.doubles("M0_0");
	double M1_0 = parameters.doubles("M1_0");
	double M2_0 = parameters.doubles("M2_0");
	double G_0 = parameters.doubles("G0");
	double initial_tumour_radius = parameters.doubles("tumour_radius_initial");
	double area_0 = M_PI*pow(initial_tumour_radius,2);
	double PD1_0 = rhoPD1*(T0)/area_0;
	double PDL1_0 = rhoPDL1*(M0_0+M1_0+M2_0+G_0)/area_0;
	double inh_0 = 1/(1+(PD1_0*PDL1_0)/kYQ);

	//double max_rate = eta1*(T0/Tstar)/(4*TAMregionsConfigurations.size());
	//Calculated at tumour homeostasis
	double max_rate = (((deathrateCD8-prolifrateCD8*inh_0)*T0*(eta2+(M2_0/(M1_0+M2_0))))/(inh_0*(M1_0/(M1_0+M2_0))))/(4*TAMregionsConfigurations.size());
	
	int number_cd8 = 0;

	int count_CD8 = cellcounts[0];
	int count_Cancer = cellcounts[1];
	int count_TAMs = cellcounts[3]+cellcounts[4]+cellcounts[5];
	float area = M_PI*pow(current_tumour_radius,2);
	float PD1 = rhoPD1*count_CD8/area;//vol;
	float PDL1 = rhoPDL1*(count_Cancer+count_TAMs)/area;//vol;
	float activation_level = 1/(1+((PD1*PDL1)/parameters.doubles("kYQ")));
	// std::cout << "Activation levels in entire tumour area is "+std::to_string(activation_level)+" .\n";
	
	//loop through regions
	for(int nR=0; nR<TAMregionsConfigurations.size() ; nR++) {
		for(int nA=0;nA<TAMregionsConfigurations[0].size(); nA++) {
			std::vector<int> regionCounts = TAMregionsConfigurations[nR][nA];
			int M1 = regionCounts[4];
			int M2 = regionCounts[5];
			if((M1+M2)>0) {
				double M1ratio = ((double)M1)/((double)M1+(double)M2);
				double M2ratio = ((double)M2)/((double)M1+(double)M2);
				// int count_CD8 = regionCounts[0];
				// int count_Cancer = regionCounts[1];
				// int count_M0 = regionCounts[3];
				// int count_TAMs = M1+M2+count_M0;
				double rmin = TAMregionsRadius[nR];
				double rmax = TAMregionsRadius[nR+1];
				// float area = (M_PI*pow(rmax,2)-M_PI*pow(rmin,2))/TAMregionsConfigurations[nR].size();
				// float PD1 = rhoPD1*count_CD8/area;//vol;
				// float PDL1 = rhoPDL1*(count_Cancer+count_TAMs)/area;//vol;
				// float activation_level = 1/(1+((PD1*PDL1)/parameters.doubles("kYQ")));
				double recruitmentrate = activation_level*dt*max_rate*(M1ratio/(M2ratio+eta2));
				//std::cout<<"Recruitment rate:"+std::to_string(recruitmentrate)+"\n";
				int CD8recruited = eventMultipleoccurences(recruitmentrate);
				number_cd8 += CD8recruited;
				for(int i = 0 ; i < CD8recruited ; i++) {
					//double rmin = TAMregionsRadius[nR];
					//double rmax = TAMregionsRadius[nR+1];
					double r = sqrt(pow(rmin,2)+(pow(rmax,2)-pow(rmin,2))*UniformRandom());
					double angle_min = nA*M_PI/2;
					double angle_max = (nA+1)*M_PI/2;
					double theta = angle_min+UniformRandom()*(angle_max-angle_min);
					double x = r*cos(theta);
					double y= r*sin(theta);
					Cell_Definition* pCD = find_cell_definition( 1 );
					Cell* pC = create_cell(*pCD);
					pC->assign_position(x,y,0);
					TAMassignRegion(pC); //XX 06/02/2025
					//XX 06/04/2025
					//int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
					//int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
					//pC->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = CD8ProliferationRate(pC);
				}
			}
		}
	}
	// std::cout << "Current physicell time "+std::to_string(PhysiCell_globals.current_time)+" .\n";
	// std::cout << "There were "+std::to_string(number_cd8)+" CD8+ T cells recruited by TAMs.\n";
	/*
	int M1 = cellcounts[4];
	int M2 = cellcounts[5];
	double M1ratio = ((double)M1)/((double)M1+(double)M2);
	double M2ratio = ((double)M2)/((double)M1+(double)M2);
	double recruitmentrate = max_rate*(M1ratio/(M2ratio+eta2));

	//find PD-1 concentration
	int CD8count = cellcounts[0]-deadcells[0];
	int GBMcount = cellcounts[1]-deadcells[1];
	int TAMcount = cellcounts[3]-deadcells[4];
	double rhoPD1 = parameters.doubles("rho_PD1");
	double rhoPDL1 = parameters.doubles("rho_PDL1");
	double area = M_PI*pow(current_tumour_radius,2);
	double PD1 = rhoPD1*CD8count/area;//vol;
	double PDL1 = rhoPDL1*(GBMcount+TAMcount)/area;//vol;
	double activation_level = 1/(1+((PD1*PDL1)/parameters.doubles("kYQ")));
	std::cout<<"Activation level:"+std::to_string(activation_level)+"\n";
	recruitmentrate = dt*recruitmentrate*activation_level;
	std::cout<<"Recruitment rate:"+std::to_string(recruitmentrate)+"\n";
	int CD8recruited = eventMultipleoccurences(recruitmentrate);
	 
	for(int i = 0 ; i < CD8recruited ; i++) {
		double rmin = current_tumour_radius-10.0;
		double rmax = current_tumour_radius+10.0;
		double r = sqrt(pow(rmin,2)+(pow(rmax,2)-pow(rmin,2))*UniformRandom());
		double theta = UniformRandom()*2*M_PI;
		double x = r*cos(theta);
		double y= r*sin(theta);
		Cell_Definition* pCD = find_cell_definition( 1 );
		Cell* pC = create_cell(*pCD);
		pC->assign_position(x,y,0);
		int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
		int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
		pC->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = CD8ProliferationRate(pC);
	}
	std::cout << "There were "+std::to_string(CD8recruited)+" CD8+ T cells recruited by TAMs.\n";
	*/
	return;
}

void CD8_update( Cell* pCell, Phenotype& phenotype , double dt ) {

	if( phenotype.death.dead == true )
	{
		pCell->functions.update_phenotype = NULL; 
		return; 
	}

	//update activation level due to PD-1/PDL-1 complexes
	int ind_activation = pCell->custom_data.find_variable_index("activation_level");
	double activation_level = PD1PDL1(pCell);
	pCell->custom_data.variables[ind_activation].value = activation_level;

	//update glioblastoma cell induced proliferation rate
	// int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
	// int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
	// pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = activation_level*CD8ProliferationRate(pCell);
	
	//Check for glioblastoma induced proliferation
	double prolif_rate = activation_level*CD8ProliferationRate(pCell);
	double pd = dt*prolif_rate;
	bool proliferating = eventBinaryOccurence(pd);
	if(proliferating) {
		pCell->flag_for_division();
	} else {
		bool exhausted = CD8_check_for_exhaustion(pCell, dt);
		if(exhausted) {
			induce_CD8_death(pCell,dt);
		}
	}


	// int current_phase_index = pCell->phenotype.cycle.current_phase_index();
	// if(current_phase_index==cycle_end_index) {
	// 	int ki67pos_index = pCell->custom_data.find_variable_index("Ki67pos");
	// 	pCell->custom_data.variables[ki67pos_index].value = 1;
	// 	int deathrate_index = pCell->custom_data.find_variable_index("cd8DeathRate");
	// 	pCell->custom_data.variables[deathrate_index].value = 0.0;
	// }

	//find if the cell is already attached and if so for how long it's been attached
	static int ind_attached = pCell->custom_data.find_variable_index("is_attached");
	bool attached = pCell->custom_data.variables[ind_attached].value;
	static int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
	double attachment_time = PhysiCell_globals.current_time - pCell->custom_data.variables[ind_time_attached].value;
	double max_attachment_time = parameters.doubles("max_attachment_time");

	//update chemotaxis movement
	CD8movement(pCell);
	
	if(!attached) { //&& attached_cells[0]<1) {
		CD8_check_for_attachment(pCell);
	} else if (attached) { 
		
		// && attachment_time>max_attachment_time) {
		//detach the cell from the cell it is attached to
		/*
		for( int j=0; j < pCell->state.spring_attachments.size(); j++ ) {
			Cell* pCattached = pCell->state.spring_attachments[j]; 
			detach_cells_as_spring(pCell,pCattached);
			//set both cells' motility back to true
			pCell->phenotype.motility.is_motile = true; 
			pCattached->phenotype.motility.is_motile = true; 
			// reset their attachment time and attachment boolean variable
			pCell->custom_data.variables[ind_attached].value = false;
			pCell->custom_data.variables[ind_time_attached].value = (double) 0;
			pCattached->custom_data.variables[ind_attached].value = false;
			pCattached->custom_data.variables[ind_time_attached].value = (double) 0;
		}
		*/
		
		//CD8+ T cell is attached and attempts to kill the cancer cell it is attached to
		for( int j=0; j < pCell->state.spring_attachments.size(); j++ ) {
			Cell* pCattached = pCell->state.spring_attachments[j]; 
			CD8_attempts_apoptosis(pCell, pCattached, dt);
		}
	}

	/*
	int ind_ID = pCell->custom_data.find_variable_index("cell_id");
	int ID = pCell->custom_data.variables[ind_ID].value;
	if(ID==678) {
		mark_cells_in_my_neighborhood(pCell);
	}
	*/
	TAMassignRegion(pCell);
	
	return;
}

void CD8_check_for_attachment(Cell* pCell) {
	// loop through cells in its neighborhood
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//if(pCell->state.neighbors.size()>0) {
	if(neighbors.size()>0) {
		for( int i=0; i < neighbors.size() ; i++ )
		{
			Cell* pNeighbor = neighbors[i];
			int type_neighbor = pNeighbor->type;
			double max_distance = parameters.doubles("max_attachment_distance");
			double d = distance_between_cells(pCell, pNeighbor); 
			int ind_attached = pNeighbor->custom_data.find_variable_index("is_attached");
			bool Neighbor_attached = pNeighbor->custom_data.variables[ind_attached].value;
			//neighbor is an unattached cancer cell within distance 
			int ind_activation = pCell->custom_data.find_variable_index("activation_level");
			double pb = pCell->custom_data.variables[ind_activation].value;
			bool can_attach = eventBinaryOccurence(pb);
			if(type_neighbor==2 && d<=max_distance && !Neighbor_attached && can_attach) {
				attach_cells_as_spring(pCell,pNeighbor);
				pCell->custom_data.variables[ind_attached].value = true;
				pNeighbor->custom_data.variables[ind_attached].value = true;
				int ind_time_attachment = pCell->custom_data.find_variable_index("attachment_time");
				pCell->custom_data.variables[ind_time_attachment].value = PhysiCell_globals.current_time;
				pNeighbor->custom_data.variables[ind_time_attachment].value = PhysiCell_globals.current_time;

				pCell->phenotype.motility.is_motile = false;
				pNeighbor->phenotype.motility.is_motile = false;

				// break out of the for loop
				i = neighbors.size();

				/*
				// XXX Useful if we want to keep track of two cells that are attached
				attached_cells[0] += (double) 1;
				int ind_ID = pCell->custom_data.find_variable_index("cell_id");
				attached_cells[1] = (double) pCell->custom_data.variables[ind_ID].value;
				attached_cells[2] = (double) pNeighbor->custom_data.variables[ind_ID].value;
				attached_cells[3] = PhysiCell_globals.current_time;
				*/
			}
		}
	}
	return;
}

double CD8ProliferationRate(Cell* pCell) {
	double proliferationRate = 0;
	int nCancerCells = 0; //number of cancer cells in it's neighborhood 
	//loop through cells in its neighborhood
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//for( int n=0; n < pCell->state.neighbors.size(); n++ ) {
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int typeNeighbor = pNeighbor->type; 
		if(typeNeighbor==2) {
			nCancerCells++;
			break;
		}
	}
	if(nCancerCells>0) {
		proliferationRate = parameters.doubles("tumour_mediated_proliferation_rate");
		int ind_time_last_encouter = pCell->custom_data.find_variable_index("time_last_tumour_encounter");
		pCell->custom_data.variables[ind_time_last_encouter].value = PhysiCell_globals.current_time;
		// int ki67pos_index = pCell->custom_data.find_variable_index("Ki67pos");
		// pCell->custom_data.variables[ki67pos_index].value = 1;
		// int deathrate_index = pCell->custom_data.find_variable_index("cd8DeathRate");
		// pCell->custom_data.variables[deathrate_index].value = 0.0;

	}
	return proliferationRate;
}

void CD8movement(Cell* pCell) {
	
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	static int chemokine_index = microenvironment.find_density_index( "chemokine" ); 
	double chemokine_amount = pCell->nearest_density_vector()[chemokine_index];
	
	int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
	int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
	
	std::vector<double> ae_ini(3);
    	
	if( wall_amount<3 ) {
		
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		return;
		
	} else if(chemokine_amount>1e-8) {
		// sample chemotaxis gradient and random walk in that direction
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")/2+chemokine_amount));
		pCell->phenotype.motility.migration_bias = parameters.doubles("b_CD8");
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(chemokine_index);
		//normalize( &(pCell->phenotype.motility.migration_bias_direction));
		return; 
	} else {
		pCell->phenotype.motility.migration_bias = 0;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		return;
	}
	
	return;
}

float PD1PDL1(Cell* pCell) {
	int count_CD8 = 0;//cellcounts[1];
	int count_cancer = 0;//cellcounts[2];
	int count_TAM = 0;//cellcounts[4];
	float rhoPD1 = parameters.doubles("rho_PD1");
	float rhoPDL1 = parameters.doubles("rho_PDL1");
	double radius = parameters.doubles("GBM_radius");
	float area = M_PI*pow(4*radius,2);

	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int type_Neighbor = pNeighbor->type;
		if(type_Neighbor==1) {
			count_CD8+=1;
		} else if(type_Neighbor == 2) {
			count_cancer += 1;
		} else if(type_Neighbor == 4) {
			count_TAM += 1;
		}
	}

	float PD1 = rhoPD1*count_CD8/area;//vol;
	float PDL1 = rhoPDL1*(count_cancer+count_TAM)/area;//vol;

	float activation_level = 1/(1+((PD1*PDL1)/parameters.doubles("kYQ")));

	return activation_level;
}

void CD8_attempts_apoptosis(Cell* pCell, Cell* pCattached, double dt) {
	bool dettach_me = false;
	//cancer cell is already dead
	if( pCattached->phenotype.death.dead == true ) { 
		dettach_me = true;
	} else {
		//pb: probability of killing the cell
		double pb = dt*parameters.doubles("cd8_killing_rate");
		bool kills = eventBinaryOccurence(pb);
		if(kills) {
			static int apoptosis_model_index = pCattached->phenotype.death.find_death_model_index( "apoptosis" );	
			static int TMZ_index = microenvironment.find_density_index( "TMZ" ); 
			pCattached->phenotype.molecular.fraction_released_at_death[TMZ_index] = 0;	
			//XX-13/05/2025
			//pCattached->start_death( apoptosis_model_index );
			killCell(pCattached,dt);
			dettach_me = true;
			//update the number of cancer cells killed by CD8+ T cells
			deadcells[2] += 1;
		}
	}
	if(dettach_me) {
		int ind_attached = pCell->custom_data.find_variable_index("is_attached");
		int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
		detach_cells_as_spring(pCell,pCattached);
		//set cell's motility back to true
		pCell->phenotype.motility.is_motile = true; 
		// reset its attachment time and attachment boolean variable
		pCell->custom_data.variables[ind_attached].value = false;
		pCell->custom_data.variables[ind_time_attached].value = (double) 0;
	}

}

bool CD8_check_for_exhaustion(Cell* pCell, double dt) {
	int deathrate_index = pCell->custom_data.find_variable_index("cd8DeathRate");
	double death_rate = parameters.doubles("CD8_death_rate");//pCell->custom_data.variables[deathrate_index].value;//
	//death probability
	double pd = dt*death_rate;
	bool exhausted = eventBinaryOccurence(pd);
	return exhausted;
}

void induce_CD8_death(Cell* pCell,double dt) {
	int ind_attached = pCell->custom_data.find_variable_index("is_attached");
	bool attached = pCell->custom_data.variables[ind_attached].value;
	if(attached) {
		//dettach the cell from the cell it is attached to 
		int ind_time_attached = pCell->custom_data.find_variable_index("attachment_time");
		for( int j=0; j < pCell->state.spring_attachments.size(); j++ ) {
			Cell* pCattached = pCell->state.spring_attachments[j]; 
			detach_cells_as_spring(pCell,pCattached);
			//set cell's motility back to true
			pCattached->phenotype.motility.is_motile = true; 
			// reset its attachment time and attachment boolean variable
			pCattached->custom_data.variables[ind_attached].value = false;
			pCell->custom_data.variables[ind_attached].value = false;
			pCattached->custom_data.variables[ind_time_attached].value = (double) 0;
		}
		pCell->state.spring_attachments.clear();
	}
	// static int apoptosis_model_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
	int ind_dead = pCell->custom_data.find_variable_index("is_dead");
	pCell->custom_data.variables[ind_dead].value = true;
	pCell->functions.update_phenotype = NULL; 
	//XX-13/05/2025
	//pCell->start_death( apoptosis_model_index );
	killCell(pCell,dt);
	return;
}

void killCell(Cell* pCell, double dt) {
	int apoptosis_model_index = pCell->phenotype.death.find_death_model_index( "apoptosis" );
	pCell->phenotype.death.current_death_model_index = apoptosis_model_index;
	pCell->phenotype.death.dead = true;
	// if so, change the cycle model to the current death model 
	pCell->phenotype.cycle.sync_to_cycle_model( pCell->phenotype.death.current_model() ); 
	
	// also, turn off motility.
	
	pCell->phenotype.motility.is_motile = false; 
	pCell->phenotype.motility.motility_vector.assign( 3, 0.0 ); 
	pCell->functions.update_migration_bias = NULL;
	
	// turn off secretion, and reduce uptake by a factor of 10 
	pCell->phenotype.secretion.set_all_secretion_to_zero();
	pCell->phenotype.secretion.scale_all_uptake_by_factor( 0.10 );
	
	// make sure to run the death entry function 
	if( pCell->phenotype.cycle.current_phase().entry_function )
	{
		pCell->phenotype.cycle.current_phase().entry_function( pCell, pCell->phenotype, dt ); 
	}

	//Update the number of cells that died
	int cell_type = pCell->type;
	if(cell_type==1) {
		deadcells[0] += 1;
	} else if(cell_type==2) {
		deadcells[1] += 1;
	} else if(cell_type==3) {
		deadcells[3] +=1;
	} else {
		//TAMs - 
		deadcells[4] += 1;
		int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
		int phenotype = pCell->custom_data.variables[phenotype_index].value;
		if(phenotype>0) {
			cellcounts[3+phenotype] -= 1;
		}
	}
	
	return;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// CANCER CELL FUNCTIONS /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_cancer_cells( void )
{
	cancer_cell = find_cell_definition( "cancer cell" ); 
	
	// cell actions
	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	cancer_cell->phenotype.secretion.uptake_rates[TMZ_index] = 0;//parameters.doubles("cell_TMZ_uptake_rate"); 
	cancer_cell->phenotype.secretion.secretion_rates[TMZ_index] = 0.0;
	//cancer_cell->phenotype.motility.migration_speed = 0.0;
	
	// cell morphology
	cancer_cell->phenotype.geometry.radius = parameters.doubles("GBM_radius");

	// set cell specific functions 
	cancer_cell->functions.update_phenotype = cancer_cell_rules; 

	//death model
	int apoptosis_index = cancer_cell->phenotype.death.find_death_model_index( "apoptosis" ); 
	cancer_cell->phenotype.death.rates[apoptosis_index] = (double) 0; 
	
	return; 
}

void cancer_cell_rules( Cell* pCell, Phenotype& phenotype , double dt )
{ 
	if(phenotype.death.dead==true) {
		pCell->functions.update_phenotype = NULL; 
		return; 
	}

	TMZeffect(pCell, dt);

	//update local density
	int neighborhood_density_index = pCell->custom_data.find_variable_index( "neighborhood_density" );
	double d = get_neighborhood_density(pCell);
	pCell->custom_data.variables[neighborhood_density_index].value = d;
	
	cancer_cell_proliferation_movement(pCell, phenotype, dt);
	updateNetProliferationRate(pCell);
	TAMassignRegion(pCell);
	return; 
} 

//returns 1 for Go/Not proliferating model, and 2 for Stop/Grow model
int cancer_cell_assign_movement_type() {
	double new_type_rand = UniformRandom();
	if(new_type_rand<=0.5) {
		return 1;
	} else {
		return 2;
	}
}

double cancer_cell_assign_persistence_time(std::vector<double> cumul_prob,std::vector<double> times) {
	double p = UniformRandom();
	double pers = 0;
	for( int j=0; j<8; )
	{
		if( p> cumul_prob[j] ) {
			j++;
		} else {
			pers = times[j];
			j = 8;
		}
	}
	return pers;
}

std::vector<double>  cancer_cell_proliferation_rate(Cell* pC) {
	double max_density = parameters.doubles("maximum_cell_density");
	int neighborhood_density_index = pC->custom_data.find_variable_index( "neighborhood_density" );
	double d = pC->custom_data.variables[neighborhood_density_index].value;
	
	std::vector<double>  prolifRate(2);
	int baseline_proliferation_index = pC->custom_data.find_variable_index( "baseline_proliferation_rate" );
	double baseline_proliferation_rate = pC->custom_data.variables[baseline_proliferation_index].value;
	//prolifRate[0] = std::max((double) 0,baseline_proliferation_rate*(1-(d/max_density)));	//modify proliferation rate due to local density
	if(d>max_density) {
		prolifRate[0] = (double) 0;
	} else {
		prolifRate[0] = baseline_proliferation_rate;
	}
	prolifRate[1] = 0;//prolifRateBaseline*(TMZ_effect); //death rate
	return prolifRate;
}

//update baseline proliferate rate and apoptosis rate of a tumour cell
void TMZeffect(Cell* pC, double dt) {
	double EC50 = parameters.doubles("IC50");
	double Emax = dt*parameters.doubles("E_max")/(24*60);
	double h = parameters.doubles("h");
	static int TMZ_index = microenvironment.find_density_index("TMZ");	
	double TMZ = std::max(pC->nearest_density_vector()[TMZ_index],(double) 0);
	double TMZ_effect = Emax*pow(TMZ,h)/(pow(TMZ,h)+pow(EC50,h));
	//if(!(dt>0)) {
	//	TMZ_effect = (double) 0;
	//}
	if(!parameters.bools("TMZ_tx")) {
		TMZ_effect = (double) 0;
	}
	double prolifRateGBMCellLine = parameters.doubles("GBM_cell_proliferation_rate"); 
	int baseline_proliferation_index = pC->custom_data.find_variable_index( "baseline_proliferation_rate" );
	double old_baseline_proliferation_rate = pC->custom_data.variables[baseline_proliferation_index].value;
	double new_baseline_proliferation_rate = (1.0-TMZ_effect)*old_baseline_proliferation_rate;//(1-TMZ_effect)*old_baseline_proliferation_rate;
	pC->custom_data.variables[baseline_proliferation_index].value = new_baseline_proliferation_rate;
	
	//modify apoptosis rate due to TMZ
	static int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
	int apoptosis_rate_index = pC->custom_data.find_variable_index( "apoptosis_rate" );
	double old_apoptosis_rate = pC->custom_data.variables[apoptosis_rate_index].value;
	double changeApoptosisRate = TMZ_effect*new_baseline_proliferation_rate;//prolifRateGBMCellLine;//prolifRateGBMCellLine*(prolifRateGBMCellLine-new_baseline_proliferation_rate)/prolifRateGBMCellLine;
	double newApoptosisRate = old_apoptosis_rate+changeApoptosisRate;
	pC->phenotype.death.rates[apoptosis_index] = newApoptosisRate;//TMZ_effect*prolifRateGBMCellLine;
	//int apoptosis_rate_index = pC->custom_data.find_variable_index( "apoptosis_rate" );
	pC->custom_data.variables[apoptosis_rate_index].value = newApoptosisRate;
	
}

void cancer_cell_proliferation_movement( Cell* pCell, Phenotype& phenotype, double dt )
{ 
	static int wall_index = microenvironment.find_density_index( "wall" ); 
	double wall_amount = pCell->nearest_density_vector()[wall_index];
	
	static int persistence_time_index = pCell->custom_data.find_variable_index( "persistence_time" );
	static int cell_motility_type_index = pCell->custom_data.find_variable_index( "cell_motility_type" );
	double persistence_time = pCell->custom_data.variables[persistence_time_index].value;
	double cell_motility_type = pCell->custom_data.variables[cell_motility_type_index].value; 

	static int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	static int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 

	std::vector<double> go_times_cumul(8);
	std::vector<double> stop_times_cumul(8);
	std::vector<double> persistence_times_vec(12);
	std::vector<double> speed_cumul(12);
	std::vector<double> speed_vec(12);
	go_times_cumul = go_times_cumulative();
	stop_times_cumul = stop_times_cumulative();
	persistence_times_vec = persistance_distribution();
	speed_cumul = speed_cumulative();
	speed_vec = speed_distribution();
	static int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
	double newProlifRate = pCell->custom_data.variables[proliferation_index].value;

	if( persistence_time <= PhysiCell_globals.current_time ) // if the cell's persistence time is up
	{
		int newMovementType = cancer_cell_assign_movement_type();
		pCell->custom_data.variables[cell_motility_type_index].value = newMovementType;
		double new_persistence_time = (double) 0;
		if(newMovementType==parameters.ints("GoMovementType")) {
			// go movement type
			new_persistence_time = cancer_cell_assign_persistence_time(go_times_cumul,persistence_times_vec);
			double speed_var = UniformRandom();
			for( int k=0; k<12; )
			{
				if( speed_var> speed_cumul[k] )
				{k++;}
				else
				{
					pCell->phenotype.motility.migration_speed = speed_vec[k]; // assign migration speed
					k = 12;
				}
			}
			//newProlifRate = (double) 0;
			//pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate; // no proliferation
		} else {
			new_persistence_time = cancer_cell_assign_persistence_time(stop_times_cumul,persistence_times_vec);
			pCell->phenotype.motility.migration_speed = 0;
			//std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
			// proliferation (1st element)
			//newProlifRate = tempRates[0];
			//pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
		}
		pCell->custom_data.variables[persistence_time_index].value = new_persistence_time+PhysiCell_globals.current_time; // assign persist time
		//XX-13/05/2025
		// std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
		// // proliferation (1st element)
		// newProlifRate = tempRates[0];
		// pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
		// pCell->custom_data.variables[persistence_time_index].value = new_persistence_time+PhysiCell_globals.current_time; // assign persist time
		// pCell->custom_data.variables[proliferation_index].value = newProlifRate;

	} //else {//} if (cell_motility_type>1) {
	// 	// proliferation (1st element) 
	// 	std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
	// 	newProlifRate = tempRates[0];
	// 	pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
	// 	pCell->custom_data.variables[proliferation_index].value = newProlifRate;

	// }

	std::vector<double> tempRates = cancer_cell_proliferation_rate(pCell);
	newProlifRate = tempRates[0];
	pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = newProlifRate;
	pCell->custom_data.variables[proliferation_index].value = newProlifRate;
	std::vector<double> ae_ini(3);
	//outisde migratory domain: set migration speed to 0
	if( wall_amount<3 )
	{
		//pCell->phenotype.motility.migration_speed = 0;
		pCell->phenotype.motility.migration_bias = 1;
		ae_ini = -1*pCell->position;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;
	} else {
		pCell->phenotype.motility.migration_bias = 0;
	}
			
	return;

}

void updateNetProliferationRate(Cell* pCell) {
	//Get proliferation rate
	int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
	double proliferation_rate = pCell->custom_data.variables[proliferation_index].value;
	//Get TMZ-induced apoptosis rate
	int apoptosis_index = pCell->custom_data.find_variable_index( "apoptosis_rate" );
	double tmz_apoptosis_rate = pCell->custom_data.variables[apoptosis_index].value;
	//Get CD8-induced apoptosis rate
	double cd8_apoptosis_rate = 0;
	int attached_index = pCell->custom_data.find_variable_index("is_attached");
	bool is_attached = pCell->custom_data.variables[attached_index].value;
	if(is_attached) {
		cd8_apoptosis_rate = parameters.doubles("cd8_killing_rate");
	}
	//Update net proliferation rate
	int net_proliferation_index = pCell->custom_data.find_variable_index( "net_proliferation_rate" );
	pCell->custom_data.variables[net_proliferation_index].value = proliferation_rate-tmz_apoptosis_rate-cd8_apoptosis_rate;
}

std::vector<double> go_times_cumulative()
{
	// setting up distributions for movement and persistance of cells
	std::vector<double> go_times_cumul(8);
    go_times_cumul[0] = 0.01;
	go_times_cumul[1] = 0.962;
	go_times_cumul[2] = 0.9735;
	go_times_cumul[3] = 0.9835;
	go_times_cumul[4] = 0.9935;
	go_times_cumul[5] = 0.9955;
	go_times_cumul[6] = 0.9975;
	go_times_cumul[7] = 1;
	
	return go_times_cumul;
}

std::vector<double> stop_times_cumulative()
{
	// setting up distributions for movement and persistance of cells
	std::vector<double> stop_times_cumul(8);
    stop_times_cumul[0] = 0.021;
	stop_times_cumul[1] = 0.6671;
	stop_times_cumul[2] = 0.8114;
	stop_times_cumul[3] = 0.8952;
	stop_times_cumul[4] = 0.9641;
	stop_times_cumul[5] = 0.9857;
	stop_times_cumul[6] = 0.9941;
	stop_times_cumul[7] = 1;
	
	return stop_times_cumul;
}

std::vector<double> persistance_distribution()
{	
	std::vector<double> persistance_times_vec(8);
    persistance_times_vec[0] = 0;
	persistance_times_vec[1] = 30;
	persistance_times_vec[2] = 60;
	persistance_times_vec[3] = 90;
	persistance_times_vec[4] = 120;
	persistance_times_vec[5] = 150;
	persistance_times_vec[6] = 180;
	persistance_times_vec[7] = 240;
	
	return  persistance_times_vec;
}

std::vector<double> speed_cumulative()
{	
	std::vector<double> speed_cumul(12);
    speed_cumul[0] = 0.0014;
	speed_cumul[1] = 0.0317;
	speed_cumul[2] = 0.2441;
	speed_cumul[3] = 0.5137;
	speed_cumul[4] = 0.7598;
	speed_cumul[5] = 0.8822;
	speed_cumul[6] = 0.9453;
	speed_cumul[7] = 0.9787;
	speed_cumul[8] = 0.9882;
	speed_cumul[9] = 0.9937;
	speed_cumul[10] = 0.9963;
	speed_cumul[11] = 1;

	return speed_cumul;
}

std::vector<double> speed_distribution()	
{	
	std::vector<double> speed_vec(12);
    speed_vec[0] = 0.0833;
	speed_vec[1] = 0.1667;
	speed_vec[2] = 0.25;
	speed_vec[3] = 0.333;
	speed_vec[4] = 0.4167;
	speed_vec[5] = 0.5;
	speed_vec[6] = 0.5833;
	speed_vec[7] = 0.667;
	speed_vec[8] = 0.75;
	speed_vec[9] = 0.833;
	speed_vec[10] = 0.9167;
	speed_vec[11] = 1;
	
	return speed_vec;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////// GENERAL FUNCTIONS ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void create_cell_types( void )
{
	// set the random seed 
	if (parameters.ints.find_index("random_seed") != -1)
	{
		SeedRandom(parameters.ints("random_seed"));
	}
	
	initialize_default_cell_definition(); 
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment ); 
	cell_defaults.phenotype.molecular.sync_to_microenvironment( &microenvironment );
	
	cell_defaults.functions.volume_update_function = standard_volume_update_function;
	cell_defaults.functions.update_velocity = standard_update_cell_velocity;

	// Make sure we're ready for 2D
	cell_defaults.functions.set_orientation = up_orientation;  
	cell_defaults.phenotype.geometry.polarity = 1.0; 
	cell_defaults.phenotype.motility.restrict_to_2D = true; 

	cell_defaults.functions.update_migration_bias = NULL; 
	cell_defaults.functions.update_phenotype = NULL; // update_cell_and_death_parameters_O2_based; 
	cell_defaults.functions.custom_cell_rule = NULL; 
	cell_defaults.functions.contact_function = NULL; 
	cell_defaults.functions.update_migration_bias = NULL; 
	
	cell_defaults.functions.add_cell_basement_membrane_interactions = NULL; 
	cell_defaults.functions.calculate_distance_to_membrane = NULL; 

	//setting cycle model to live
	cell_defaults.phenotype.cycle.sync_to_cycle_model( live ); 
	
	int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
	
	cell_defaults.phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = 0;
	
	// reduce cell velocity
	cell_defaults.phenotype.motility.migration_speed = 0.0;

	static int wall_index = microenvironment.find_density_index( "wall");
	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	static int chemokine_index = microenvironment.find_density_index( "chemokine");
	static int oxygen_index = microenvironment.find_density_index( "oxygen");
	// turn off secretion from these cells (oxygen)
	cell_defaults.phenotype.secretion.secretion_rates[oxygen_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[oxygen_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[oxygen_index] = 10; 
	
	cell_defaults.phenotype.secretion.secretion_rates[chemokine_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[chemokine_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[chemokine_index] = parameters.ints("chemokine_saturation_density"); 
	cell_defaults.phenotype.molecular.fraction_released_at_death[chemokine_index] = 1;//1;

	cell_defaults.phenotype.molecular.fraction_released_at_death[wall_index] = 1;//1;
	cell_defaults.phenotype.secretion.secretion_rates[wall_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[wall_index] = 0;
	cell_defaults.phenotype.secretion.saturation_densities[wall_index] = 10; 
	
	cell_defaults.phenotype.secretion.secretion_rates[TMZ_index] = 0;
	cell_defaults.phenotype.secretion.uptake_rates[TMZ_index] = 0.0;
	cell_defaults.phenotype.secretion.saturation_densities[TMZ_index] = parameters.doubles("TMZ_saturation_density");
	cell_defaults.phenotype.molecular.fraction_released_at_death[TMZ_index] = 0;

	initialize_cell_definitions_from_pugixml(); 

	cell_defaults.functions.update_phenotype = cancer_cell_proliferation_movement;
	cell_defaults.phenotype.motility.is_motile = true; 

	// create the cell types
	create_cancer_cells();
	create_CD8_cells();
	create_stroma_cells();
	create_TAMs();
		
	build_cell_definitions_maps(); 
	setup_signal_behavior_dictionaries(); 
	display_cell_definitions( std::cout ); 
	
	return; 
}

void setup_microenvironment( void )
{
	// set domain parameters 
	
	// put any custom code to set non-homogeneous initial conditions or 
	// extra Dirichlet nodes here. 

	// make sure not override and go back to 2D 
	if( default_microenvironment_options.simulate_2D == false )
	{
		std::cout << "Warning: overriding XML config option and setting to 2D!" << std::endl; 
		default_microenvironment_options.simulate_2D = true; 
	}
	
	// initialize BioFVM 
	
	initialize_microenvironment(); 	

	static int TMZ_index = microenvironment.find_density_index( "TMZ");
	static int oxygen_index = microenvironment.find_density_index( "oxygen");
	static int wall_index = microenvironment.find_density_index( "wall");
	static int chemokine_index = microenvironment.find_density_index( "chemokine");

	for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
	{	
		std::vector<double> ECMdense = microenvironment.mesh.voxels[n].center; 
		//assign random ECM density to microenvironment voxel
		
		if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("tumour_radius")+10)*(parameters.doubles("tumour_radius")+10))
		{	
			microenvironment(n)[oxygen_index] = 0;
			microenvironment(n)[TMZ_index] = 0;
			microenvironment(n)[wall_index] = 1;
			microenvironment(n)[chemokine_index] = 0;
			
		}
		else if(ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("tumour_radius")-10)*(parameters.doubles("tumour_radius")-10))
		{
			
			microenvironment(n)[oxygen_index] = 0;
			microenvironment(n)[TMZ_index] = 0;
			microenvironment(n)[wall_index] = 3.5;
			microenvironment(n)[chemokine_index] = 0;
		}
		else if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>250*250 )
		{	
			microenvironment(n)[oxygen_index] = 0;
			microenvironment(n)[TMZ_index] = 0;
			microenvironment(n)[wall_index] = 5;
			microenvironment(n)[chemokine_index] = 0;
		}
		else
		{   
			microenvironment(n)[oxygen_index] = 0;
			microenvironment(n)[TMZ_index] = 0;
			microenvironment(n)[wall_index] = 10;
			microenvironment(n)[chemokine_index] = 0;
		}
			
	}
	
	return; 
}

void setup_tissue( void )
{
	double Radius = parameters.doubles("tumour_radius");
	
	double x = 0.0;
	double y = 0.0;
	
	// load cells from your CSV file (if enabled)
	load_cells_from_pugixml();
	
	#pragma omp parallel for
	for( int n=0; n < (*all_cells).size(); n++ )
	{
		
		Cell* pC = (*all_cells)[n]; 
		int neighborhood_density_index = pC->custom_data.find_variable_index( "neighborhood_density" );
		double d = get_neighborhood_density(pC);
		pC->custom_data.variables[neighborhood_density_index].value = d;
		int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
		if(pC->type ==2) {
			int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
			int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
			//int apoptosis_index = pC->phenotype.death.find_death_model_index( "apoptosis" );
			int persistence_time_index = pC->custom_data.find_variable_index( "persistence_time" );
			int cell_motility_type_index = pC->custom_data.find_variable_index( "cell_motility_type" );
			std::vector<double> go_times_cumul(8);
			std::vector<double> stop_times_cumul(8);
			std::vector<double> persistence_times_vec(12);
			std::vector<double> speed_cumul(12);
			std::vector<double> speed_vec(12);
			go_times_cumul = go_times_cumulative();
			stop_times_cumul = stop_times_cumulative();
			persistence_times_vec = persistance_distribution();
			speed_cumul = speed_cumulative();
			speed_vec = speed_distribution();
			int movType = cancer_cell_assign_movement_type();
			pC->custom_data.variables[cell_motility_type_index].value = movType;

			double persistence_time = (double) 0;
			double timepassed = (double) 0;
			TMZeffect(pC, timepassed);
			if(movType==parameters.ints("GoMovementType")) {
				// go movement type
				persistence_time = cancer_cell_assign_persistence_time(go_times_cumul,persistence_times_vec);
				double speed_var = UniformRandom();
				for( int k=0; k<12; )
				{
					if( speed_var> speed_cumul[k] )
					{k++;}
					else
					{
						pC->phenotype.motility.migration_speed = speed_vec[k]; // assign migration speed
						k = 12;
					}
				}
				//pC->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = 0; // no proliferation
			} else {
				persistence_time = cancer_cell_assign_persistence_time(stop_times_cumul,persistence_times_vec);
				pC->phenotype.motility.migration_speed = 0;
				// proliferation (1st element) and death (second element) rates
				//std::vector<double> tempRates = cancer_cell_proliferation_rate(pC);
				//pC->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = tempRates[0];
			}
			// proliferation (1st element) and death (second element) rates
			std::vector<double> tempRates = cancer_cell_proliferation_rate(pC);
			pC->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = tempRates[0];
			pC->custom_data.variables[persistence_time_index].value = persistence_time; // assign persist time
		} else if(pC->type ==1) {
			//int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative ); 
			//int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive ); 
			//pC->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = CD8ProliferationRate(pC);
		} else if(pC->type == 4) {
			int phenotype_index = pC->custom_data.find_variable_index("phenotype");
			int phenotype = pC->custom_data.variables[phenotype_index].value;
			if(phenotype>0) {
				pC->phenotype.death.rates[apoptosis_index] = parameters.doubles("death_rate_activated_TAM"); 
			}
		} 
		/*
		else if(pC->type ==4) {
			std::vector<double> pos = pC->position;
			double x_pos = pos[0];
			double y_pos = pos[1];
			double radius_pos = sqrt(pow(x_pos,2)+pow(y_pos,2));

			//find radius of region in which TAM cell is
			bool search_region = true;
			int region_index = 0;
			while(search_region) {
				double lower_radius = TAMregionsRadius[region_index];
				double upper_radius = TAMregionsRadius[region_index+1];
				if((radius_pos>=lower_radius && radius_pos<upper_radius) || (region_index == (TAMregionsRadius.size()-2))) {
					search_region = false;
				} else {
					region_index += 1;
				}
			}
			double angle_pos= atan2(y_pos,x_pos)/M_PI;
			int angle_index = 0;
			if(angle_pos<0) {
				if(angle_pos<-0.5) {
					angle_index = 2;
				} else {
					angle_index = 3;
				}
			} else {
				if(angle_pos<0.5) {
					angle_index = 0;
				} else {
					angle_index = 1;
				}
			}
			int phenotype_index = pC->custom_data.find_variable_index("phenotype");
			int phenotype = pC->custom_data.variables[phenotype_index].value;
			TAMregionsConfigurations[region_index][angle_index][phenotype] += 1;
		}
		*/
		TAMassignRegion(pC);

		
	}

	return; 
}

void TAMassignRegion(Cell* pCell) {
	std::vector<double> pos = pCell->position;
	double x_pos = pos[0];
	double y_pos = pos[1];
	double radius_pos = sqrt(pow(x_pos,2)+pow(y_pos,2));
	//find radius of region in which TAM cell is
	bool search_region = true;
	int region_index = 0;
	while(search_region) {
		double lower_radius = TAMregionsRadius[region_index];
		double upper_radius = TAMregionsRadius[region_index+1];
		if((radius_pos>=lower_radius && radius_pos<upper_radius) || (region_index == TAMregionsRadius.size()-2)) {
			search_region = false;
		} else {
			region_index += 1;
		}
	}
	double angle_pos= atan2(y_pos,x_pos)/M_PI;
	int angle_index = 0;
	if(angle_pos<0) {
		if(angle_pos<-0.5) {
			angle_index = 2;
		} else {
			angle_index = 3;
		}
	} else {
		if(angle_pos<0.5) {
			angle_index = 0;
		} else {
			angle_index = 1;
		}
	}
	if(pCell->type==4) {
		int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
		int phenotype = pCell->custom_data.variables[phenotype_index].value;
		TAMregionsConfigurations[region_index][angle_index][(pCell->type)+phenotype-1] += 1;
	} else {
		TAMregionsConfigurations[region_index][angle_index][(pCell->type)-1] += 1;
	}
	//int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
	//int phenotype = pCell->custom_data.variables[phenotype_index].value;
	//TAMregionsConfigurations[region_index][angle_index][phenotype] += 1;

}

double get_neighborhood_density( Cell* pCell) {
	double density = 0.0;
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	if(neighbors.size()>0) {
		for( int i=0; i < neighbors.size() ; i++ )
		{
			Cell* tempNeighbor = neighbors[i];
			density += (tempNeighbor->phenotype.geometry.radius)/10.75;
		}
	}
	return density;
}

//set the pCell to the live model with a proliferation rate equal to prolif_rate
void change_to_live_model(Cell* pCell, double prolif_rate) {
	pCell->phenotype.cycle.sync_to_cycle_model( live );	
	int cycle_start_index = live.find_phase_index( PhysiCell_constants::live ); 
	int cycle_end_index = live.find_phase_index( PhysiCell_constants::live ); 
	pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = prolif_rate;
	return;
}

void mark_cells_in_my_neighborhood(Cell* pCell) {
	std::vector<Cell*> neighbors = find_nearby_interacting_cells(pCell);
	//for( int n=0; n < pCell->state.neighbors.size(); n++ ) {
	for( int n=0; n < neighbors.size(); n++ ) {
		Cell* pNeighbor = neighbors[n]; 
		int ind_marked = pNeighbor->custom_data.find_variable_index("marked_boolean");
		pNeighbor->custom_data.variables[ind_marked].value = true;
	}
}

double distance_between_cells(Cell* pC1, Cell* pC2) {
	std::vector<double> displacement = pC1->position - pC2->position;
	double distance = norm( displacement ); 
	return distance;
}

int eventMultipleoccurences(double rate) {

    int n = 0;//number of occurences
    double p =  ((double)rand()) / RAND_MAX ; //sample from uniform distribution between 0 and 1

    bool continueSearch = true;
    double a = (double) 0;
    //loop to find number of occurences of event
    while (continueSearch) {
        
        float pn = exp(-rate)*(pow(rate,n))/tgammaf(n+1);
        double b = a+pn;
		//std::cout << "pn: " << pn << std::endl;
		//std::cout << "a: " << a << std::endl;
        //std::cout << "b: " << b << std::endl;
        if ((a <= p) && (p < b)) {
            continueSearch = false;
        } else {
            a = b;
            n = n+1;
        }
    }

    return n;
}

//Function to determine whether an event occurs or note its probability of occurence is prob
bool eventBinaryOccurence(double prob) {

    bool occurs = false;
    double p =  ((double)rand()) / RAND_MAX ; //sample from uniform distribution between 0 and 1
    if(p<prob) {
        occurs = true;
    }

    return occurs;
}

void empty_TAM_region_array() {
	for(int i=0;i<TAMregionsConfigurations.size();i++){
		for(int j=0;j<TAMregionsConfigurations[i].size();j++) {
		    std::fill(TAMregionsConfigurations[i][j].begin(),TAMregionsConfigurations[i][j].end(),0);
		}
	}
}

//Generate a vector with n random integers between a and b
std::vector<int> randomNumberVector(int n, int a, int b) {
	//seed the random number generator so we don't always get the same numbers
	unsigned seed = time(0);
    // Seed the random number generator.
    srand(seed);
	std::vector<int> myVector(n, 0);
	for(int i=0; i<n; i++) {
		bool keep_searching = true;
		int ri = 0;
		while(keep_searching) {
			//generate random integer
			ri = (rand()%(b-a)) + a;
			if(i==0) {
				keep_searching = false;
			} else {
				//check if integer was already picked
				int it = std::count(myVector.begin(), myVector.end(), ri);
				//In that case ri was not found in myVector and you can stop searching for an integer
				if(it==0) {
					keep_searching = false;
				}
			}
		}
		myVector[i] = ri;
	}
	return myVector;
}


std::vector<std::string> my_coloring_function( Cell* pCell )
{ 
	std::vector< std::string > output( 4, "darkgrey" ); 
	static int ind_attached = pCell->custom_data.find_variable_index( "is_attached" );
	bool attached = pCell->custom_data.variables[ind_attached].value;
	static int ind_ID = pCell->custom_data.find_variable_index( "cell_id" );
	double ID = (double) pCell->custom_data.variables[ind_ID].value;
	static int ind_marked = pCell->custom_data.find_variable_index( "marked_boolean" );
	bool marked = pCell->custom_data.variables[ind_marked].value;

	//dead
	if(pCell->phenotype.death.dead == true)
	{

		output[0] = "rgb(217,217,217)";//"light grey
		output[1] = "rgb(217,217,217)";
		output[2] = "rgb(217,217,217)";
		output[3] = "rgb(217,217,217)";
		
		return output; 
	}
	else if( pCell->type == 1) //CD8+ T cell cell
	{	
		output[0] = "rgb(255,223,191)";//"blue
		output[1] = "rgb(244,122,0)";
		output[2] = "rgb(244,122,0)";
		output[3] = "rgb(244,122,0)";

		return output; 
	}	
	else if( pCell->type == 2) //Cancer cell
	{	
		static int proliferation_index = pCell->custom_data.find_variable_index( "proliferation_rate" );
		int cell_motility_type_index = pCell->custom_data.find_variable_index( "cell_motility_type" );
		int movType = pCell->custom_data.variables[cell_motility_type_index].value;
		output[0] = "rgb(250,200,196)";//"red
		output[1] = "rgb(211,31,17)";
		output[2] = "rgb(211,31,17)";
		output[3] = "rgb(211,31,17)";
		return output; 
	} else if( pCell->type == 3) //Stroma cell
	{	
		output[0] = "rgb(201, 229, 182)";//green
		output[1] = "rgb(100, 154, 63)";
		output[2] = "rgb(100, 154, 63)";
		output[3] = "rgb(100, 154, 63)";
		return output; 
	}
	else if( pCell->type == 4) //TAM 
	{	
		int phenotype_index = pCell->custom_data.find_variable_index("phenotype");
		int TAMphenotype = pCell->custom_data.variables[phenotype_index].value;
		if(TAMphenotype==0) {
			output[0] = "rgb(255,191,249)";//purple
			output[1] = "rgb(128,0,116)";
			output[2] = "rgb(128,0,116)";
			output[3] = "rgb(128,0,116)";
		} else if (TAMphenotype==1) {
			output[0] = "rgb(205,238,241)";//light blue
			output[1] = "rgb(98,200,211)";
			output[2] = "rgb(98,200,211)";
			output[3] = "rgb(98,200,211)";
		} else {
			output[0] = "rgb(191,241,255)";//dark blue
			output[1] = "rgb(0,113,145)";
			output[2] = "rgb(0,113,145)";
			output[3] = "rgb(0,113,145)";
		}
		
		return output; 
	}
	
	return output;	
}

// ************************************ UNUSED FUNCTIONS ********************************************************

