#include "RepulsiveRegion.h"
#include "./custom_GBM_TAM.h"
#include "./common.h"
#include "../modules/PhysiCell_settings.h"
#include <cmath>
#include <tuple>

RepulsiveRegion::RepulsiveRegion(double x, double y, double r, double p, double c){
    x_center = x;
    y_center = y;
    radius = r;
    area = M_PI*pow(radius,2);
    probAcceptance = p;
    capacity = c;
    number_of_occupants = 0;
}


std::tuple<bool,double> RepulsiveRegion::is_in_region(Cell* pC) {
    double x = pC->position[0];
    double y = pC->position[1];
    double d = sqrt(pow(x-x_center,2)+pow(y-y_center,2));
    bool is_inside = false;
    if(d<=radius) {
        is_inside = true;
    }
    return {is_inside,d};
}

void RepulsiveRegion::repulseCell(Cell* pC) {

    double dx = pC->position[0] - x_center;
    double dy = pC->position[1] - y_center;

    double d = sqrt(pow(dx,2)+pow(dy,2));
    double strength = (1.0 - d/radius);

    if(d < 1e-6) {
        // Random unit direction towards the border
        double theta = UniformRandom()*2*M_PI;
        dx = cos(theta);
        dy = sin(theta);
        d = 1.0;
    }
    pC->position[0] += (strength*dx/d);
    pC->position[1] += (strength*dy/d);
}

bool RepulsiveRegion::check_for_acceptance(bool is_newborn, Cell* pCell) {
    bool eligible = false;
    if (is_newborn){
        eligible = true;
    }
    else {
        double d = sqrt(pow(x_center-pCell->position[0],2)+pow(y_center-pCell->position[1],2));
        double dist_to_boundary = radius - d;
        double threshold = 0.1*radius;
        if (dist_to_boundary <= threshold) {
            eligible = true;
        }
    }

    // Reject automatically if not eligible
    if (!eligible){
        return false;
    }

    // Check for acceptance if eligible
    double void_distance_to_border = sqrt(pow(x_center,2) + pow(y_center,2));
    double effectiveArea = area;
    if(void_distance_to_border+radius > current_tumour_radius) {
        effectiveArea = circleIntersectionArea(0, 0, current_tumour_radius,x_center, y_center, radius);
    }
    double occ = double(number_of_occupants)/double(capacity*effectiveArea);

    double p_accept =probAcceptance/(1.0 + exp(3.0 * (occ - 1.0)));

    if (uniform_random() <= p_accept && eligible){
        return true;
    } else {
        return false;
    }
}