#ifndef LOCALREGIONS_H
#define LOCALREGIONS_H

// #include "../core/PhysiCell.h"
// #include "../modules/PhysiCell_standard_modules.h"

// using namespace PhysiCell;

#include <vector>
namespace PhysiCell { class Cell; }
using namespace PhysiCell;

class localRegions {
private:
    double innerRadius;
    double outerRadius;
    double minAngle;
    double maxAngle;
    double area;

public:
    localRegions(double lbRadius, double ubRadius, double lbAngle, double ubAngle);
    localRegions() = default;
    double getArea() const;
    int recruitCD8cells(double recruitmentRate);
    bool is_in_region(Cell* pC);

    std::vector<Cell*> cells;
    std::vector<int>   number_of_cells;
};

#endif